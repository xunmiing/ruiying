/* ==========================================================================
 * 瑞赢 0.1 原型静态检查（离线运行，不依赖浏览器）
 * 用法：node 临时使用/static-check.js
 * 依据：HTML原型设计任务说明 V2.1 §验证要求 + 本轮任务的静态检查清单
 *
 * 说明：检查项区分三档
 *   ERROR —— 确定缺陷，必须修复
 *   WARN  —— 需人工确认（例如互斥分支中的同名静态 id）
 *   INFO  —— 合规声明（例如页面上明确写出「不建设区域公海」属于旧规则术语的
 *            禁用声明，不是残留），仅为可追溯性记录，不计入问题数
 * ========================================================================== */
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
const findings = [];
function add(level, check, file, detail) { findings.push({ level, check, file, detail }); }

const EXCLUDE_DIRS = new Set(['joint-review-rebuild', '临时使用']);
function walk(dir, out) {
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    const rel = path.relative(ROOT, full);
    if (fs.statSync(full).isDirectory()) {
      if (EXCLUDE_DIRS.has(name)) { out.historical.push(rel + '/'); continue; }
      walk(full, out);
    } else if (/\.html?$/i.test(name)) out.html.push(rel);
    else out.other.push(rel);
  }
  return out;
}
const files = walk(ROOT, { html: [], other: [], historical: [] });

/* ------------------------------------------------------------ 1. 清单对照 */
const manifestSrc = fs.readFileSync(path.join(ROOT, 'assets/js/page-manifest.js'), 'utf8');
const sandbox = { window: {}, RY: {} };
sandbox.window.RY = sandbox.RY;
vm.createContext(sandbox);
let M = null;
try {
  vm.runInContext(manifestSrc, sandbox, { filename: 'page-manifest.js' });
  M = sandbox.RY.manifest;
} catch (e) {
  add('ERROR', '清单可执行', 'assets/js/page-manifest.js', '执行失败：' + e.message);
}
if (M) {
  const cmp = M.compare(files.html);
  cmp.missing.forEach(p => add('ERROR', '清单↔文件', p, '清单声明但文件不存在'));
  cmp.extra.forEach(p => add('ERROR', '清单↔文件', p, '文件存在但清单未登记（未登记的正式业务页面）'));
  const v = M.verify();
  if (v.pending > 0) add('ERROR', '清单自检', 'page-manifest.js', `仍有 ${v.pending} 条未生成`);
  v.dup.forEach(p => add('ERROR', '清单自检', p, '路径重复'));
  console.log(`[清单] 共 ${v.total} 条：H5 ${v.h5}｜PC ${v.pc}｜已生成 ${v.generated}｜待生成 ${v.pending}`);
}

/* ------------------------------------------------------------ 2. 禁用构造 */
const BANNED = [
  [/\bfetch\s*\(/, 'fetch('],
  [/<iframe\b/i, '<iframe'],
  [/XMLHttpRequest/, 'XMLHttpRequest'],
  [/\bimport\s*\(/, '动态 import('],
  [/\brequire\s*\(/, 'require('],
  [/cdn\.(jsdelivr|cloudflare|unpkg)|unpkg\.com|cdnjs\./i, 'CDN 引用'],
  [/<script[^>]+src\s*=\s*["']https?:/i, '远程脚本'],
  [/<link[^>]+href\s*=\s*["']https?:/i, '远程样式'],
  [/\b(vue|react|angular|jquery|tailwind)\b/i, '前端框架／库'],
];
/* 0.1 已排除的旧规则（命中时按上下文判断是否为禁用声明） */
const OLD_RULES = [
  ['部分赢单', /部分赢单/], ['阶段跳级', /阶段跳级/], ['免办', /免办/],
  ['自动线索回收', /自动(线索)?回收/], ['区域公海', /区域公海/], ['资方关系', /资方/],
  ['股权关系', /股权/], ['控制关系', /控制关系/], ['商业合作', /商业合作/],
  ['经营优先级', /经营优先级/], ['默认门店', /默认门店/], ['商机金额', /商机金额|预计金额/],
  ['关联产品', /关联产品|产品清单/], ['竞争信息', /竞争对手/],
];
const NEGATION = /(不|非|无|未|没|禁止|排除|放弃|不再|不在 0\.1|不在0\.1|不支持|不建设|不做|不提供|不恢复|不开放|去除|已移除|已删除|而不是|并非|不属于|不设|不能|不含|不展示|不计算|不参与|只有|仅|保留为|后建设|后进入)/;
/* 范围声明：术语出现在「尚待确认／后续版本」语境中，属于范围说明
   （如 architecture.html 逐条引用 system-overview.md §11「当前仍待确认」：
   「股权投资、控制管理、商业合作和资方是否进入后续正式版本；进入前需先验证…」），
   不是 0.1 已生效规则的残留。 */
const SCOPE_DECL = /(后续(正式)?版本|待确认|未确认|尚待|试点前确认|进入前)/;
/* 真实个人信息／生产接口 */
const PII = [
  [/\b1[3-9]\d{9}\b/, '手机号形态数字'],
  [/https?:\/\/(?!www\.w3\.org)[a-z0-9.-]+/i, '绝对外链（疑似生产接口地址）'],
  [/api[_-]?key\s*[:=]|secret\s*[:=]|passwd\s*[:=]|password\s*[:=]|token\s*[:=]/i, '疑似凭据'],
  [/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i, '疑似邮箱'],
  [/\b\d{17}[\dXx]\b/, '疑似身份证号'],
];
/* 内部占位值白名单：示例数据中明确用于演示的号码段（1350000xxxx 等） */
const PII_ALLOW = /1[3-9]0{4}\d{4}/;

const stats = { pages: 0, scripts: 0, links: 0, ids: 0 };
function resolveHref(fromRel, href) {
  const clean = href.split('#')[0].split('?')[0];
  if (!clean) return null;
  return path.relative(ROOT, path.resolve(path.dirname(path.join(ROOT, fromRel)), clean));
}
const pageLocalSelectors = {};

for (const rel of files.html) {
  stats.pages++;
  const src = fs.readFileSync(path.join(ROOT, rel), 'utf8');

  for (const [re, label] of BANNED) {
    const m = src.match(re);
    if (m) add('ERROR', '禁用构造', rel, `${label}（命中：${String(m[0]).slice(0, 40)}）`);
  }
  for (const [label, re] of OLD_RULES) {
    const g = new RegExp(re.source, 'g');
    let m;
    while ((m = g.exec(src))) {
      const pre = src.slice(Math.max(0, m.index - 70), m.index);
      const after = src.slice(m.index + m[0].length, m.index + m[0].length + 80);
      const wide = src.slice(m.index + m[0].length, m.index + m[0].length + 120);
      const post = src.slice(m.index, m.index + m[0].length + 16);
      /* 禁用声明的三种写法：
         (a) 术语前有否定（「0.1 不建设区域公海」）；
         (b) 术语作为小标题出现在「0.1 排除项」清单里，否定在术语之后
             （「<li><b>【部分赢单】：</b>关闭结果仅赢单…不支持部分赢单」）；
         (c) 术语出现在「尚待确认／后续版本」的范围声明里
             （「股权…是否进入后续正式版本；进入前需先验证…」）。 */
      if (NEGATION.test(pre) || NEGATION.test(after) || SCOPE_DECL.test(wide) ||
          /^(不|禁止|排除)的?/.test(post.slice(m[0].length))) {
        add('INFO', '旧规则禁用声明', rel, `${label}（上下文：…${pre.trim()}【${m[0]}】…）`);
      } else {
        add('ERROR', '旧规则残留', rel, `${label}（上下文：…${pre.trim()}【${m[0]}】${post.slice(m[0].length, m[0].length + 12)}…）`);
      }
    }
  }
  for (const [re, label] of PII) {
    const g = new RegExp(re.source, 'g');
    let m;
    while ((m = g.exec(src))) {
      if (label === '手机号形态数字' && PII_ALLOW.test(m[0])) { add('INFO', '示例号码', rel, `${m[0]} 属演示占位号段`); continue; }
      add('ERROR', '真实信息残留', rel, `${label}（${String(m[0]).slice(0, 44)}）`);
    }
  }
  /* 相对资源路径（属性写法不含空格） */
  const resRe = /(?:href|src)=["']([^"']+)["']/g;
  let m;
  while ((m = resRe.exec(src))) {
    const href = m[1];
    if (/^(https?:|mailto:|tel:|javascript:|#|data:|\$|\{)/i.test(href)) continue;
    if (/['"+]/.test(href)) continue;               /* 动态拼接，由运行时校验 */
    stats.links++;
    const target = resolveHref(rel, href);
    if (target && !fs.existsSync(path.join(ROOT, target))) {
      add('ERROR', '相对路径', rel, `目标不存在：${href} → ${target}`);
    }
  }
  /* 入口根 */
  const dr = src.match(/data-root=["']([^"']*)["']/);
  if (dr) {
    const depth = rel.split('/').length - 1;
    const expect = '../'.repeat(depth);
    if (dr[1] !== expect) add('WARN', '入口根', rel, `data-root="${dr[1]}"，层级深度 ${depth} 期望 "${expect}"`);
  }
  /* 内联脚本语法 */
  const scriptRe = /<script(?![^>]*\ssrc=)[^>]*>([\s\S]*?)<\/script>/gi;
  let si = 0;
  while ((m = scriptRe.exec(src))) {
    si++; stats.scripts++;
    try { new vm.Script(m[1], { filename: `${rel}#inline${si}` }); }
    catch (e) { add('ERROR', '脚本语法', rel, `内联脚本 #${si}：${e.message.split('\n')[0]}`); }
  }
  /* 标签闭合（\b 兼容 '<tr' + 的动态拼接写法） */
  for (const tag of ['html', 'head', 'body', 'style', 'script', 'section', 'table', 'thead', 'tbody', 'tr', 'td', 'th', 'ul', 'li', 'div', 'span', 'aside', 'header', 'main', 'nav']) {
    const open = (src.match(new RegExp('<\\b' + tag + '\\b(?![^>]*/>)', 'gi')) || []).length;
    const close = (src.match(new RegExp('</' + tag + '>', 'gi')) || []).length;
    if (open !== close) add(tag === 'div' || tag === 'span' ? 'WARN' : 'ERROR', '标签闭合', rel, `<${tag}> 开 ${open} / 闭 ${close}`);
  }
  /* 静态同名 id（可能是互斥分支，需人工确认） */
  const idRe = /\sid=["']([A-Za-z][\w-]*)["']/g;
  const seen = {};
  while ((m = idRe.exec(src))) {
    stats.ids++;
    seen[m[1]] = (seen[m[1]] || 0) + 1;
  }
  Object.keys(seen).filter(k => seen[k] > 1).forEach(k => {
    add('WARN', '静态同名 id', rel, `id="${k}" 静态出现 ${seen[k]} 次（需确认是否互斥分支）`);
  });
  /* 页面级样式选择器 */
  const styleRe = /<style[^>]*>([\s\S]*?)<\/style>/gi;
  const local = new Set();
  while ((m = styleRe.exec(src))) {
    (m[1].match(/(^|\})\s*([^{}@]+)\{/g) || []).forEach(s => {
      s.replace(/^[}\s]*/, '').replace(/\{$/, '').split(',').forEach(x => {
        const sel = x.trim();
        if (/^\.[A-Za-z]/.test(sel)) local.add(sel);
      });
    });
  }
  pageLocalSelectors[rel] = local;
  if (M && !M.byPath[rel] && rel !== 'architecture.html') add('ERROR', '未登记页面', rel, '不在 page-manifest 清单中');
  if (!/<title>[^<]+<\/title>/.test(src)) add('WARN', '标题', rel, '缺少 <title>');
}
console.log(`[遍历] ${stats.pages} 个 HTML｜内联脚本 ${stats.scripts} 段｜静态 id ${stats.ids} 个｜静态链接 ${stats.links} 处`);

/* ------------------------------------------------------------ 3. 样式冲突 */
const commonSelectors = new Set();
for (const c of ['assets/css/common.css', 'assets/css/h5-common.css', 'assets/css/pc-common.css']) {
  const p = path.join(ROOT, c);
  if (!fs.existsSync(p)) { add('ERROR', '公共样式', c, '文件不存在'); continue; }
  (fs.readFileSync(p, 'utf8').match(/(^|\})\s*([^{}@]+)\{/g) || []).forEach(s => {
    s.replace(/^[}\s]*/, '').replace(/\{$/, '').split(',').forEach(x => {
      const sel = x.trim();
      if (/^\.[A-Za-z]/.test(sel)) commonSelectors.add(sel);
    });
  });
}
for (const rel of Object.keys(pageLocalSelectors)) {
  const dups = [...pageLocalSelectors[rel]].filter(s => commonSelectors.has(s));
  if (dups.length) add('WARN', '公共选择器重复定义', rel, dups.join('、'));
}
console.log(`[样式] 公共选择器 ${commonSelectors.size} 个`);

/* ------------------------------------------------------------ 4. 权限键登记 */
const permSrc = fs.readFileSync(path.join(ROOT, 'assets/js/permissions.js'), 'utf8');
const actionKeys = new Set((permSrc.match(/^\s*'([a-zA-Z][\w.]*)':/gm) || []).map(s => s.trim().replace(/[':]/g, '')));
const capBlock = permSrc.match(/var CAPS = \{([\s\S]*?)\};/);
const capKeys = new Set(capBlock ? (capBlock[1].match(/'([^']+)'\s*:/g) || []).map(s => s.replace(/[':\s]/g, '')) : []);
const navSrc = fs.readFileSync(path.join(ROOT, 'assets/js/navigation.js'), 'utf8');
const navKeys = new Set([]
  .concat((navSrc.match(/key:\s*'([^']+)'/g) || []))
  .concat((permSrc.match(/\{\s*key:\s*'([^']+)'/g) || []))
  .map(s => s.replace(/.*key:\s*'|'/g, '')));
console.log(`[权限] 动作键 ${actionKeys.size} 个｜能力项 ${capKeys.size} 个｜导航键 ${navKeys.size} 个`);
for (const rel of files.html) {
  const src = fs.readFileSync(path.join(ROOT, rel), 'utf8');
  let m;
  const canRe = /P\.can\(\s*'([^']+)'/g;
  while ((m = canRe.exec(src))) {
    if (!actionKeys.has(m[1])) add('ERROR', '未登记动作键', rel, `P.can('${m[1]}') 未登记`);
  }
  const capRe = /P\.cap\(\s*'([^']+)'/g;
  while ((m = capRe.exec(src))) {
    if (!capKeys.has(m[1])) add('ERROR', '未登记能力项', rel, `P.cap('${m[1]}') 未登记`);
  }
  const navRe = /nav:\s*'([^']+)'/g;
  while ((m = navRe.exec(src))) {
    if (!navKeys.has(m[1]) && !/^[a-z]+\.[a-z.]+$/.test(m[1])) {
      add('ERROR', '未登记导航键', rel, `nav='${m[1]}' 不在 navigation.js 导航键中`);
    }
  }
  const pageRe = /^\s*var PAGE = '([^']+)'/gm;
  while ((m = pageRe.exec(src))) {
    if (!permSrc.includes(`'${m[1]}'`)) add('ERROR', '未登记页面键', rel, `PAGE='${m[1]}' 未在 permissions.js 中登记`);
  }
}

/* ------------------------------------------------------------ 5. 存储与公共接口 */
const storeSrc = fs.readFileSync(path.join(ROOT, 'assets/js/prototype-store.js'), 'utf8');
const storeKeys = new Set((storeSrc.slice(storeSrc.lastIndexOf('return {')).match(/([A-Za-z_]\w*)\s*:/g) || []).map(s => s.replace(/[:\s]/g, '')));
const uiSrc = fs.readFileSync(path.join(ROOT, 'assets/js/common-actions.js'), 'utf8');
const uiKeys = new Set((uiSrc.slice(uiSrc.lastIndexOf('return {')).match(/([A-Za-z_]\w*)\s*:/g) || []).map(s => s.replace(/[:\s]/g, '')));
const seedKeys = new Set((fs.readFileSync(path.join(ROOT, 'assets/js/demo-data.js'), 'utf8')
  .slice(0, fs.readFileSync(path.join(ROOT, 'assets/js/demo-data.js'), 'utf8').lastIndexOf('return {'))
  .match(/var\s+([A-Za-z_]\w*)\s*=/g) || []).map(s => s.replace(/var\s+|\s*=/g, '')));
console.log(`[接口] store 导出 ${storeKeys.size} 个｜ui 导出 ${uiKeys.size} 个｜seed 集合 ${seedKeys.size} 个`);
for (const rel of files.html) {
  const src = fs.readFileSync(path.join(ROOT, rel), 'utf8');
  let m;
  const sRe = /\bS\.([A-Za-z_]\w*)\s*\(/g;
  while ((m = sRe.exec(src))) {
    if (!storeKeys.has(m[1])) add('ERROR', '未定义 store 接口', rel, `S.${m[1]}() 不存在`);
  }
  const uRe = /\bui\.([A-Za-z_]\w*)\s*\(/g;
  while ((m = uRe.exec(src))) {
    if (!uiKeys.has(m[1])) add('ERROR', '未定义 ui 接口', rel, `ui.${m[1]}() 不存在`);
  }
  const allRe = /\bS\.all\(\s*'([^']+)'/g;
  while ((m = allRe.exec(src))) {
    if (!seedKeys.has(m[1])) add('ERROR', '未定义 seed 集合', rel, `S.all('${m[1]}') 集合不存在`);
  }
}

/* ------------------------------------------------------------ 6. 汇总 */
const ERRORS = findings.filter(f => f.level === 'ERROR');
const WARNS = findings.filter(f => f.level === 'WARN');
const INFOS = findings.filter(f => f.level === 'INFO');
console.log('\n================ 静态检查结果 ================');
console.log(`ERROR ${ERRORS.length} 项｜WARN ${WARNS.length} 项｜INFO（合规声明，不计入问题）${INFOS.length} 项`);
if (ERRORS.length) {
  console.log('\n--- ERROR ---');
  ERRORS.forEach(f => console.log(`  [${f.check}] ${f.file}：${f.detail}`));
}
if (WARNS.length) {
  console.log('\n--- WARN ---');
  WARNS.forEach(f => console.log(`  [${f.check}] ${f.file}：${f.detail}`));
}
if (process.env.RY_INFO) {
  console.log('\n--- INFO（旧规则禁用声明，抽样 20 条）---');
  INFOS.slice(0, 20).forEach(f => console.log(`  [${f.check}] ${f.file}：${f.detail}`));
}
console.log(`\n历史目录（未纳入检查）：${files.historical.join('、') || '无'}`);
console.log(`非 HTML 资源：${files.other.length} 个`);
process.exit(ERRORS.length ? 1 : 0);
