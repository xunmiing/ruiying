/* ==========================================================================
 * 瑞赢 0.1 原型真实浏览器检查（Chrome + CDP，零依赖）
 * 用法：node 临时使用/browser-check.js [页面路径关键字]
 *
 * 检查的是「页面在真实浏览器里是否可用」，而不是「DOM 里有没有这段文字」：
 *   1. 运行时异常：JS 抛错 / console.error / 浏览器 error 级日志
 *   2. 布局：横向溢出（并给出溢出元素）、内容被裁切、首屏是否有实际内容
 *   3. 渲染脏值：可见文本里出现 undefined / NaN / [object Object] / null
 *   4. 骨架：页头、导航、页面标题是否真实渲染
 *   5. 断链：页面内所有相对链接的目标文件是否存在
 * H5 按 430×900（企微手机），PC 按 1280×800 与 1440×900 两档。
 * ========================================================================== */
'use strict';

const { Browser, sleep } = require('./cdp.js');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
const FILTER = process.argv[2] || '';

/* ------------------------------------------------------------ 清单 */
const sandbox = { window: {}, RY: {} };
sandbox.window.RY = sandbox.RY;
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(ROOT, 'assets/js/page-manifest.js'), 'utf8'), sandbox, { filename: 'page-manifest.js' });
const MANIFEST = sandbox.RY.manifest;
const ROWS = MANIFEST.list.filter(r => !FILTER || r.path.indexOf(FILTER) >= 0);

const H5 = { w: 430, h: 900 };
const PC_WIDE = { w: 1440, h: 900 };
const PC_NARROW = { w: 1280, h: 800 };

const results = [];
function rec(page, vp, kind, detail) {
  results.push({ page, vp: vp ? vp.w + '×' + vp.h : '-', kind, detail });
}

/* 页面内探针：一次性取回全部判定所需的事实 */
const PROBE = `
  var out = {};
  var de = document.documentElement, bd = document.body;
  out.title = document.title || '';
  out.visibleText = (bd.innerText || '').replace(/\\s+/g, ' ').trim();
  out.textLen = out.visibleText.length;
  out.viewport = { w: window.innerWidth, h: window.innerHeight };
  out.docScrollW = de.scrollWidth;
  out.bodyScrollW = bd.scrollWidth;

  /* 溢出元素：右边界超出视口，且不在可横向滚动的祖先里（表格横滚是允许的） */
  function scrollableAncestor(el) {
    var n = el.parentElement;
    while (n && n !== bd) {
      var ox = getComputedStyle(n).overflowX;
      if (ox === 'auto' || ox === 'scroll' || ox === 'hidden') return true;
      n = n.parentElement;
    }
    return false;
  }
  var over = [];
  var all = bd.querySelectorAll('*');
  for (var i = 0; i < all.length; i++) {
    var el = all[i], r = el.getBoundingClientRect();
    if (r.width <= 0 && r.height <= 0) continue;
    if (r.right > window.innerWidth + 2 && !scrollableAncestor(el)) {
      over.push({ tag: el.tagName.toLowerCase(), cls: String(el.className || '').slice(0, 60),
                  right: Math.round(r.right), w: Math.round(r.width),
                  text: (el.innerText || '').replace(/\\s+/g, ' ').slice(0, 40) });
      if (over.length >= 8) break;
    }
  }
  out.overflow = over;

  /* 渲染脏值 */
  var dirty = [];
  ['undefined', 'NaN', '[object Object]', 'null', '\${', '{{'].forEach(function (tok) {
    var idx = out.visibleText.indexOf(tok);
    if (idx >= 0) dirty.push({ token: tok, ctx: out.visibleText.slice(Math.max(0, idx - 40), idx + 40) });
  });
  out.dirty = dirty;

  /* 骨架 */
  out.hasShell = !!document.querySelector('.ry-app, .ry-h5, .ry-side, .ry-top, .h5-app, .h5-top');
  out.h1 = (function () { var e = document.querySelector('h1, .ry-head__t, .ry-title, .h5-head__t'); return e ? (e.innerText || '').slice(0, 60) : ''; })();
  out.deny = !!document.querySelector('.ry-state, .ry-noperm, [data-denied]');
  out.stateCards = (document.querySelectorAll('.ry-state').length);
  out.pageKey = (window.RY && RY.perm && RY.perm.__lastPage) || '';
  return out;
`;

/* 断链检查：页面内相对链接目标是否存在 */
const LINKS = `
  var out = [];
  var as = document.querySelectorAll('a[href]');
  for (var i = 0; i < as.length; i++) {
    var h = as[i].getAttribute('href');
    if (!h || /^(https?:|mailto:|tel:|javascript:|data:|#)/i.test(h)) continue;
    if (/[\\'"+]/.test(h)) continue;
    out.push({ href: h, text: (as[i].innerText || '').replace(/\\s+/g, ' ').slice(0, 30) });
  }
  return out;
`;

function checkLinks(pageRel, links) {
  const bad = [];
  for (const l of links) {
    const clean = l.href.split('#')[0].split('?')[0];
    if (!clean) continue;
    const target = path.resolve(path.dirname(path.join(ROOT, pageRel)), clean);
    if (!fs.existsSync(target)) bad.push(l.href + '（' + l.text + '）');
  }
  return bad;
}

(async () => {
  const browser = await Browser.launch({});
  console.log('浏览器：' + browser.version.Browser + '｜协议 ' + browser.version['Protocol-Version']);
  console.log('待检页面：' + ROWS.length + ' 个\n');

  const page = await browser.newPage();
  await page.enable();

  for (const row of ROWS) {
    const isH5 = row.end === 'H5';
    const vps = isH5 ? [H5] : [PC_NARROW, PC_WIDE];
    const url = 'file://' + path.join(ROOT, row.path);

    for (const vp of vps) {
      await page.viewport(vp.w, vp.h);
      let probe;
      try {
        await page.goto(url, 800);
        probe = await page.evaluate(PROBE.replace(/^/, '').replace(/\n\s*$/, ''));
      } catch (e) {
        rec(row.path, vp, 'ERROR', '页面求值失败：' + e.message);
        continue;
      }
      const errs = page.errors();

      errs.js.forEach(e => rec(row.path, vp, 'ERROR', 'JS 异常：' + String(e.text).split('\n')[0].slice(0, 220)));
      errs.console.forEach(e => rec(row.path, vp, 'ERROR', 'console.error：' + String(e).slice(0, 200)));
      errs.log.forEach(e => rec(row.path, vp, 'ERROR', '浏览器错误日志：' + String(e).slice(0, 200)));

      if (!probe.title) rec(row.path, vp, 'WARN', '缺少页面标题');
      if (!probe.hasShell) rec(row.path, vp, 'ERROR', '页面骨架未渲染（无 .ry-app/.ry-side/.ry-top 等）');
      /* 详情页在缺少标识或对象不可用时只渲染状态卡，这是契约要求的行为，
         不是「内容过少」——只有既无状态卡又几乎无内容才判定为渲染失败。 */
      if (probe.textLen < 120 && !probe.stateCards) {
        rec(row.path, vp, 'ERROR', '可见内容过少且无状态卡（' + probe.textLen + ' 字）：' + probe.visibleText.slice(0, 80));
      }
      probe.dirty.forEach(d => rec(row.path, vp, 'ERROR', '可见文本渲染脏值「' + d.token + '」：…' + d.ctx + '…'));
      if (probe.overflow.length) {
        rec(row.path, vp, 'ERROR', '横向溢出 ' + probe.overflow.length + ' 处：' +
          probe.overflow.map(o => o.tag + '.' + o.cls + '(right=' + o.right + ',w=' + o.w + ')').join('｜'));
      }
      if (probe.docScrollW > probe.viewport.w + 2) {
        rec(row.path, vp, 'WARN', '文档可横向滚动：scrollWidth=' + probe.docScrollW + ' > 视口 ' + probe.viewport.w);
      }
    }

    /* 断链只查一次（视口无关）；页面此刻已是最宽档渲染结果 */
    try {
      const links = await page.evaluate(LINKS);
      const bad = checkLinks(row.path, links);
      if (bad.length) rec(row.path, null, 'ERROR', '断链：' + bad.slice(0, 5).join('；'));
    } catch (e) { /* 页面求值失败已在上面报过 */ }

    process.stdout.write('.');
  }

  await browser.close();

  /* ---------------------------------------------------------- 汇总 */
  const errs = results.filter(r => r.kind === 'ERROR');
  const warns = results.filter(r => r.kind === 'WARN');
  console.log('\n\n================ 浏览器检查结果 ================');
  console.log(`受检页面 ${ROWS.length} 个｜断言记录 ${results.length} 条｜ERROR ${errs.length} 项｜WARN ${warns.length} 项`);
  if (errs.length) {
    console.log('\n--- ERROR ---');
    const seen = new Set();
    errs.forEach(f => {
      const k = f.page + '|' + f.detail.slice(0, 70);
      if (seen.has(k)) return;
      seen.add(k);
      console.log(`  [${f.vp}] ${f.page}：${f.detail}`);
    });
    const uniq = seen.size;
    if (uniq < errs.length) console.log(`  （另有 ${errs.length - uniq} 条为同一问题在其他视口/行为下的重复记录）`);
  }
  if (warns.length) {
    console.log('\n--- WARN ---');
    warns.slice(0, 30).forEach(f => console.log(`  [${f.vp}] ${f.page}：${f.detail}`));
    if (warns.length > 30) console.log(`  （其余 ${warns.length - 30} 条略）`);
  }
  fs.writeFileSync(path.join(__dirname, 'browser-check-result.json'), JSON.stringify({ total: ROWS.length, results }, null, 2));
  console.log('\n明细已写入 临时使用/browser-check-result.json');
  process.exit(errs.length ? 1 : 0);
})().catch(e => { console.error('检���未完成：' + e.message); process.exit(2); });
