/* 定位：某个页面里渲染出来的坏链接，来自哪个元素、什么写法 */
'use strict';
const { Browser } = require('./cdp.js');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const pageRel = process.argv[2];
const suffix = process.argv[3] || '../../list.html';

(async () => {
  const b = await Browser.launch({});
  const p = await b.newPage();
  await p.enable();
  await p.viewport(1440, 900);
  await p.goto('file://' + path.join(ROOT, pageRel), 1200);
  const hits = await p.evaluate(
    "var out = [];" +
    "document.querySelectorAll('a[href]').forEach(function (a) {" +
    "  var h = a.getAttribute('href');" +
    "  if (h && h.indexOf(" + JSON.stringify(suffix) + ") >= 0) {" +
    "    var box = a.closest('.ry-card__head, .ry-crumbs, .ry-head, .ry-objhead, section, div');" +
    "    out.push({ href: h, text: (a.innerText||'').replace(/\\s+/g,' ').slice(0,40), html: a.outerHTML.slice(0,200)," +
    "               near: box ? (box.className||'').toString().slice(0,60) : '' });" +
    "  }" +
    "});" +
    "return out;"
  );
  console.log(JSON.stringify(hits, null, 2));
  await b.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
