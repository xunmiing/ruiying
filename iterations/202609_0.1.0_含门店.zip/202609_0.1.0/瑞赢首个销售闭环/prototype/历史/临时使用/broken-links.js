/* 遍历全部页面，列出「渲染后」的坏链接及其所在容器，供精确修复 */
'use strict';
const { Browser } = require('./cdp.js');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
const sandbox = { window: {}, RY: {} };
sandbox.window.RY = sandbox.RY;
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(ROOT, 'assets/js/page-manifest.js'), 'utf8'), sandbox, { filename: 'pm.js' });
const ROWS = sandbox.RY.manifest.list;

const PROBE = `
  var out = [];
  document.querySelectorAll('a[href]').forEach(function (a) {
    var h = a.getAttribute('href');
    if (!h || /^(https?:|mailto:|tel:|javascript:|data:|#)/i.test(h)) return;
    if (/[\\'"+]/.test(h)) return;
    var clean = h.split('#')[0].split('?')[0];
    if (!clean) return;
    var box = a.closest('.ry-crumbs, .ry-head__actions, .ry-card__head, .ry-objhead, .ry-tabs, .ry-state, .ry-table, .ry-kv, section');
    out.push({ href: h, text: (a.innerText || '').replace(/\\s+/g, ' ').slice(0, 34),
               box: box ? String(box.className || '').split(' ')[0].slice(0, 30) : '(body)' });
  });
  return out;
`;

(async () => {
  const b = await Browser.launch({});
  const p = await b.newPage();
  await p.enable();
  await p.viewport(1440, 900);

  const bad = [];
  for (const row of ROWS) {
    await p.goto('file://' + path.join(ROOT, row.path), 700);
    let links;
    try { links = await p.evaluate(PROBE); } catch (e) { continue; }
    for (const l of links) {
      const clean = l.href.split('#')[0].split('?')[0];
      if (!clean) continue;
      const target = path.resolve(path.dirname(path.join(ROOT, row.path)), clean);
      if (!fs.existsSync(target)) {
        bad.push({ page: row.path, href: l.href, text: l.text, box: l.box,
                   resolved: path.relative(ROOT, target) });
      }
    }
    process.stdout.write('.');
  }
  await b.close();

  console.log('\n\n坏链接共 ' + bad.length + ' 处，涉及页面 ' + new Set(bad.map(x => x.page)).size + ' 个\n');
  const byBox = {};
  bad.forEach(x => { (byBox[x.box] = byBox[x.box] || []).push(x); });
  Object.keys(byBox).forEach(box => {
    console.log('===== 容器：' + box + '（' + byBox[box].length + ' 处）=====');
    byBox[box].forEach(x => {
      console.log('  ' + x.page + '  href="' + x.href + '"  文本「' + x.text + '」  → 解析到 ' + x.resolved);
    });
    console.log('');
  });
  fs.writeFileSync(path.join(__dirname, 'broken-links.json'), JSON.stringify(bad, null, 2));
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
