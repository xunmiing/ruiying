/* 打印指定页面的可交互面：按钮、输入控件、关键容器，便于编写真实交互场景 */
'use strict';
const { Browser } = require('./cdp.js');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');

const PROBE = `
  var out = { buttons: [], inputs: [], rows: 0, tabs: [], heads: [] };
  document.querySelectorAll('button, a.ry-btn, [role=button]').forEach(function (b) {
    if (b.hidden || b.offsetParent === null) return;
    out.buttons.push({ id: b.id || '', text: (b.innerText || '').replace(/\\s+/g, ' ').slice(0, 26),
                       dis: !!b.disabled, attrs: b.getAttributeNames().filter(function (n) { return n.indexOf('data-') === 0; }).join(',') });
  });
  document.querySelectorAll('input, select, textarea').forEach(function (i) {
    out.inputs.push({ tag: i.tagName.toLowerCase(), name: i.name || '', id: i.id || '', type: i.type || '',
                      ph: i.placeholder || '', val: String(i.value || '').slice(0, 26) });
  });
  out.rows = document.querySelectorAll('.ry-table tbody tr, .ry-hrow, .ry-card').length;
  document.querySelectorAll('.ry-tab, [data-tab]').forEach(function (t) {
    out.tabs.push({ key: t.getAttribute('data-tab') || (t.innerText || '').replace(/\\s+/g, ' ').slice(0, 14) });
  });
  document.querySelectorAll('.ry-state').forEach(function (s) {
    out.heads.push('STATE: ' + (s.innerText || '').replace(/\\s+/g, ' ').slice(0, 80));
  });
  return out;
`;

(async () => {
  const b = await Browser.launch({});
  const p = await b.newPage();
  await p.enable();
  const targets = process.argv.slice(2);
  for (const t of targets) {
    const [rel, query] = t.split('?');
    await p.viewport(rel.indexOf('h5/') === 0 ? 430 : 1440, 900);
    await p.goto('file://' + path.join(ROOT, rel) + (query ? '?' + query : ''), 900);
    const s = await p.evaluate(PROBE);
    console.log('\n===== ' + t + ' =====');
    console.log('按钮(' + s.buttons.length + ')：');
    s.buttons.slice(0, 22).forEach(x => console.log('   ' + (x.id ? '#' + x.id : '(无id)') + ' 「' + x.text + '」' + (x.dis ? ' [禁用]' : '') + (x.attrs ? ' {' + x.attrs + '}' : '')));
    console.log('输入(' + s.inputs.length + ')：');
    s.inputs.slice(0, 22).forEach(x => console.log('   <' + x.tag + '> name=' + x.name + (x.id ? ' #' + x.id : '') + (x.type ? ' type=' + x.type : '') + (x.ph ? ' ph=「' + x.ph + '」' : '') + (x.val ? ' val=' + x.val : '')));
    if (s.tabs.length) console.log('Tab：' + s.tabs.map(x => x.key).join('｜'));
    s.heads.forEach(h => console.log('  ' + h));
  }
  await b.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
