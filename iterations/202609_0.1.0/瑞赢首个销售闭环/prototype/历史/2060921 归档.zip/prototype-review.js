(function () {
  'use strict';

  const file = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  const route = () => (location.hash || '#/home/today').slice(1).split('?')[0];
  const state = { open: false, activityMode: 'opportunity' };

  const common = [
    ['版本定位', '这是可点击的评审注释版，用于对齐业务、产品与开发；页面中的演示数据不是真实客户数据。', 'INFO'],
    ['交互边界', '已完成主流程、导航、状态变化和关键异常的演示。小按钮若未进入完整子页，会显示操作说明。', 'DEMO']
  ];

  const notes = {
    index: {
      '/home/today': [
        ['排序逻辑', '今日重点由客户价值、业务线优先级、商机阶段和到期时间等确定性规则排序；AI 只解释原因并给出建议。', 'RULE'],
        ['闭环导航', '顶部步骤是演示导航，可直接跳转，不代表每个销售每天必须依次执行所有步骤。', 'UX'],
        ['角色菜单', '销售和主管共用同一业务工作台。主管身份只增加团队看板、任务验收、日报审阅和拜访复核等授权菜单。', 'PERM']
      ],
      '/customer/list': [
        ['列表职责', '列表同时呈现客户主体、价值分级、业务线经营关系、进行中商机和下次跟进，用于快速判断下一步。', 'DATA'],
        ['公海边界', '客户主档不进公海，公海流转的是“客户—业务线经营权”。', 'RULE']
      ],
      '/customer/detail': [
        ['一页聚合', '基础与工商信息、业务线、联系人、地址、下游映射和动态使用页内分组，不拆成多个孤立页面。', 'UX'],
        ['关系图', '集团成员、多父集团、股权控制和业务关系要分类展示；合资公司可同时属于多个客户组。', 'DATA'],
        ['工商更新', '外部工商变化先生成差异候选，由客户数据管理角色确认，不静默覆盖客户主档。', 'GOV']
      ],
      '/lead/detail': [
        ['线索独立', '线索不强制关联客户。只有姓名、手机号或模糊公司名称时，可先跟进并记录销售活动。', 'RULE'],
        ['转换语义', '转换不是把线索改成客户或商机；源线索保留，新建或关联客户、联系人和 0..N 个商机。', 'RULE'],
        ['首次跟进', '点击“记录跟进”可演示无客户线索的销售活动，系统不会为了满足关联而创建模糊客户。', 'AC-04']
      ],
      '/opp/new': [
        ['客户必填', '商机创建时必须关联主客户；特殊情况使用系统公共占位客户，但进入方案验证前必须替换为实际经营实体。', 'RULE'],
        ['预计成交时间', '创建时允许为空；从“机会确认”推进到“需求确认”或后续阶段前必须补齐，流程模板不能关闭该门槛。', 'OPP-22'],
        ['流程模板', '主业务线＋销售场景唯一匹配已发布模板版本；商机保存当时版本，后续发布不静默改变历史商机。', 'RULE']
      ],
      '/opp/detail': [
        ['五个统一阶段', '机会确认 → 需求确认 → 方案验证 → 报价与审批 → 商务与合同。赢单、输单和终止是关闭结果，不是阶段。', 'STATE'],
        ['一套推进事实', '整条商机只有一套阶段、负责人、预计成交时间和关闭结果。某条业务线需要独立管理时拆为新商机并保留拆分来源。', 'RULE'],
        ['阶段门槛', '预计成交时间在离开机会确认前必填；公共占位或仅集团客户在进入方案验证前必须替换为唯一经营实体。', 'GATE']
      ],
      '/act/new': [
        ['最小关联', '正式销售活动必须至少关联客户、联系人、线索、商机或任务中的一个；什么都不关联时不能保存。', 'WORK-12'],
        ['无客户线索', '关联尚未识别客户的线索时，客户可为空，不得自动生成模糊客户。', 'AC-04'],
        ['商机继承', '关联商机时自动继承并锁定商机主客户；从客户或联系人直接创建时客户必填。', 'RULE']
      ],
      '/task': [
        ['来源与生成方式', '页面展示领导指派、沟通提炼、自建和规则生成；底层另存人工、规则引擎或 Agent 建议等生成方式。', 'DATA'],
        ['条件验收', '仅领导指派、协作型和成果型任务启用待验收；普通任务直接完成。', 'STATE'],
        ['逾期与延期', '逾期是根据 deadline 计算的时间标识，不覆盖主状态；延期是独立申请和审批事件。', 'RULE']
      ],
      '/report/daily': [
        ['一步提交', '日报主状态为草稿、已提交、已退回。“待本人确认”是工作台提醒，不是额外状态和操作。', 'STATE'],
        ['版本保留', '系统分开保存 AI 原始底稿、销售提交版本和退回后重提版本；主管可反馈或退回，不直接改销售原文。', 'RULE']
      ]
    },
    manager: {
      '*': [
        ['不是独立主管端', '此 HTML 是为了静态演示主管扩展视图。正式产品中，主管从统一业务工作台左侧菜单进入。', 'ARCH'],
        ['看板口径', '只统计已确认的业务事实；汇总、下钻、搜索和导出使用同一数据权限。', 'PERM'],
        ['管理边界', '不提供个人排行榜、AI 销售评分或定位异常自动绩效结论。', '0.1']
      ],
      '/report/review': [
        ['主管日报操作', '每名主管独立维护已读／未读并可追加建议；不退回、不重提，主管不能修改销售提交内容。', 'RULE']
      ],
      '/task/acceptance': [
        ['验收队列', '只展示已启用验收的领导指派、协作型和成果型任务；普通任务不进入队列。', 'STATE']
      ]
    },
    admin: {
      '*': [
        ['PC 职责', '配置端承担流程、池、任务、日报、权限、字典、数据质量、集成和审计；不复制销售的高频执行入口。', 'ARCH'],
        ['版本化', '可配置规则先保存草稿，通过校验后发布；已创建业务记录保留原配置快照，不被新版本静默改变。', 'GOV'],
        ['最小权限', '菜单显示只是前端体验；查看明文、修改、导出、发布和高影响操作都由服务端单独鉴权并审计。', 'PERM']
      ],
      '/template': [
        ['模板匹配', '主业务线＋销售场景唯一匹配生效模板，模板内配置详细阶段、统一阶段映射、门槛、免办和自动动作。', 'RULE'],
        ['不可关闭门槛', '预计成交时间在离开机会确认前必填；该统一门槛不得被模板关闭。', 'OPP-22']
      ],
      '/customer-pool': [
        ['多公海池', '可按业务线、区域和角色配置多个客户公海池；同一客户的不同业务线经营权可分属不同池。', 'RULE']
      ]
    },
    architecture: {
      '*': [
        ['阅读方式', '左侧按系统全景、业务闭环、对象关系、应用模块、Agent 与集成依次介绍；图中可点节点会跳到对应原型。', 'GUIDE'],
        ['一个业务工作台', '销售和主管共用业务对象与左侧菜单；manager.html 只是静态演示主管扩展视图，不代表正式产品存在独立主管端。', 'ARCH'],
        ['边界优先', '0.1 优先打通客户、线索、商机、销售活动、任务、日报、Agent 和看板闭环；复杂下游集成和完整知识库后置。', '0.1']
      ]
    }
  };

  const p = (position, ...features) => ({ position, features });
  const f = (title, description, type = 'FUNCTION') => [title, description, type];
  const profiles = {
    index: {
      '/entry': p('瑞赢的统一业务入口，用于识别当前身份和可用角色，并进入与角色权限一致的工作台。',
        f('角色识别', '展示当前登录人、组织和可切换角色；切换只改变授权视图，不改变业务数据。', 'PERM'),
        f('端入口', '进入销售／主管业务工作台、配置中心或架构说明，保持离线原型间可相互跳转。', 'NAV')),
      '/home/today': p('销售每日工作的首页，把今日优先事项、待执行任务、Agent 候选和日报收口到一条可行动的闭环中。',
        f('今日重点', '聚合即将到期、长期未跟进和高优先级事项，点击可进入对应客户、线索、商机或任务。'),
        f('每日闭环导航', '按“看重点—安排任务—执行活动—确认候选—提交日报—接收反馈”进入对应操作。', 'NAV'),
        f('角色工作台', '销售和主管共用业务工作台；主管按权限增加团队管理入口。', 'PERM')),
      '/customer/list': p('客户中心的检索与经营入口，用于找到唯一客户主档，并快速判断客户当前由谁经营、在哪些业务线存在机会。',
        f('客户检索与筛选', '支持按名称、信用代码、客户类型、价值等级、业务线和负责人查找客户。'),
        f('客户摘要', '列表直接展示价值等级、业务线经营关系、进行中商机、下次跟进和数据质量状态。'),
        f('建档与治理入口', '发起客户建档、查看疑似重复和待治理记录，并进入客户详情。', 'GOV')),
      '/customer/detail': p('客户唯一主档的聚合详情页，是客户身份、工商资料、经营关系及围绕客户发生业务事实的统一查看入口。',
        f('客户概览', '先展示当前经营判断和今日下一步，再集中查看商机、关键联系人、区域业务线责任和正式数据摘要。'),
        f('业务线经营', '以“区域＋业务线”为一条经营关系，展示优先级、负责人、公海归属、保护期和最近有效活动。'),
        f('责任边界', '客户主体允许没有公司级负责人；销售归属由区域业务线经营关系承载，客户主档不随经营权流转。', 'RULE'),
        f('客户关联门店', '门店较多时使用汇总、筛选列表和单店详情的主从视图；通过客户—门店关系保存经营方、服务方等角色。'),
        f('门店检索与批量维护', '支持按门店名称、编号、区域、业务线和经营状态筛选，分页查看十几家以上门店，并提供批量维护入口。'),
        f('门店资方关系', '在门店业务线下维护多个资方及主资方、备用资方、有效期和适用区域，不把资方直接挂在商机上。', 'RULE'),
        f('关系与动态', '查看集团／股权关系、联系人、地址、下游映射和客户时间线。'),
        f('工商刷新', '获取外部工商候选并形成差异，确认后再更新正式主档。', 'GOV')),
      '/customer/value': p('客户价值分级的维护页，用于由销售或负责人记录当前价值判断，并保留调整依据。',
        f('价值分级', '维护当前客户价值等级、判断依据和生效时间。'),
        f('调整记录', '查看历史等级、调整人、调整时间与原因，后续可接入系统推荐。', 'AUDIT')),
      '/customer/address': p('客户地址的专属维护页，统一管理注册地址、办公地址、收发货地址和拜访地点。',
        f('地址分类', '按注册地址、办公、收货、发货和其他用途分别维护。'),
        f('默认与有效性', '设置默认地址、有效期和可见范围，避免已失效地址继续被业务引用。'),
        f('地图与拜访', '为拜访、导航和定位校验提供标准化地址；定位异常只提示，不直接形成绩效结论。')),
      '/customer/pool': p('客户公海经营权工作台，流转的是客户在某条业务线上的经营权，而不是客户主档本身。',
        f('多公海查看', '按区域、业务线和角色查看有权访问的客户经营权池。'),
        f('认领与分派', '按领取上限、保护期和角色权限执行主动认领或管理分派。'),
        f('回收与释放', '展示规则回收、主动释放和退回原因，客户主档始终保留在客户中心。', 'RULE')),
      '/contact/list': p('联系人中心列表，用于跨客户检索自然人，并从人员视角查看其任职客户、决策角色和最近互动。',
        f('联系人检索', '按姓名、手机号、客户、部门、职务和决策角色筛选联系人。'),
        f('关系摘要', '展示一个联系人关联的多个客户及其在不同客户中的角色。'),
        f('互动摘要', '展示最近电话、消息、会议或拜访记录，并进入联系人详情。')),
      '/contact/detail': p('联系人的聚合详情页，维护人员基础资料，并串联其客户关系、联系方式、地址和销售互动。',
        f('基础与联系方式', '维护姓名、称谓、手机、电话、企微、邮箱及敏感字段的可见范围。'),
        f('客户关系', '通过联系人关系关联一个或多个客户，分别保存部门、职务和决策角色。'),
        f('互动时间线', '查看电话、消息、会议和拜访记录，包括通话时间、结果和后续动作。'),
        f('联系人地址', '独立维护个人联系或拜访地址，不与客户地址混为一条记录。')),
      '/contact/relation': p('联系人关系维护页，用于表达“某个人在某个客户中是什么角色”，而不是复制联系人。',
        f('多对多关联', '同一联系人可关联多个客户，同一客户也可有多个联系人。'),
        f('关系属性', '维护任职部门、职务、决策角色、主联系人标识和关系有效期。'),
        f('关系变更', '离职或角色变化时终止旧关系并保留历史，不删除联系人基础档案。', 'AUDIT')),
      '/lead/list': p('线索工作列表，用于接收、筛选、分派和跟踪尚未完成资格判断的原始销售信号。',
        f('线索筛选', '按状态、来源、线索池、持有人、业务线候选和跟进时效筛选。'),
        f('批量分派', '管理人员可批量分派、回收或转入线索池，并记录操作原因。', 'PERM'),
        f('快速跟进', '从列表直接进入详情、记录销售活动或发起转换。')),
      '/lead/new': p('线索快速录入页，用最少信息保存尚未确认客户主体的销售线索。',
        f('最小建档', '公司名称、个人姓名、手机号等信息可按实际掌握程度录入，客户关联不是必填。'),
        f('来源与归属', '记录线索来源、候选业务线、持有人或目标线索池。'),
        f('重复提示', '根据手机号、企业名称和已有线索给出疑似重复提示，但不擅自合并。', 'GOV')),
      '/lead/detail': p('单条线索的资格判断与跟进工作台，用于逐步确认需求、联系人和客户主体，并决定培育、无效或转换。',
        f('线索概览', '查看来源、状态、持有人、候选业务线、客户关联和最近跟进。'),
        f('跟进记录', '新增电话、消息、会议、拜访等销售活动；客户尚未识别时仍可记录。'),
        f('资格处理', '将线索继续跟进、转入培育、标记无效或发起转换。'),
        f('转换追溯', '查看由该线索创建或关联的客户、联系人和商机。')),
      '/lead/assign': p('线索分派与认领处理页，用于把线索的处理责任交给合适销售，并控制领取上限和保护期。',
        f('管理分派', '按区域、业务线、角色和负载选择负责人，可批量操作。', 'PERM'),
        f('主动认领', '符合权限和领取上限的销售可从线索池认领。'),
        f('回收与转派', '超时未跟进或组织调整时回收、转派，并完整记录责任变化。', 'AUDIT')),
      '/lead/convert': p('线索转换向导，用于保留原线索的同时，新建或关联客户、联系人及一个或多个商机。',
        f('目标对象选择', '分别选择新建或关联客户、联系人和商机；转换不要求必须产生所有对象。'),
        f('客户与查重', '创建客户前执行主体查重；商机创建仍必须关联客户。', 'GATE'),
        f('转换结果', '逐项保存成功或失败结果，支持失败项修正后幂等重试。', 'AUDIT')),
      '/opp/list': p('商机管道列表，用于从金额、阶段、成交时间、业务线和负责人维度管理正在推进的合作机会。',
        f('商机筛选', '按统一阶段、主业务线、销售场景、负责人、预计成交时间和风险筛选。'),
        f('管道摘要', '展示金额、阶段停留时间、下一步、团队和数据完整度。'),
        f('创建与推进', '进入商机创建、详情和阶段推进，并查看关闭或拆分记录。')),
      '/opp/new': p('商机建档页，用于明确主客户、业务范围和流程模板，形成可正式推进的合作机会。',
        f('主客户与场景', '选择主客户、主业务线和销售场景，并匹配唯一已发布流程模板。'),
        f('业务线及产品明细', '至少维护一条主业务线，可增加协同业务线及其产品、数量和金额。'),
        f('负责人团队', '设置商机负责人及协作成员，预计成交时间创建时可暂空。'),
        f('创建校验', '特殊商机可使用公共占位客户，但不能绕过后续经营实体门槛。', 'GATE')),
      '/opp/detail': p('商机推进的主工作台，聚合阶段、客户角色、业务线与产品明细、负责人团队、活动和关闭结果。',
        f('阶段推进', '按统一五阶段展示当前位置、阶段要求、完成情况、免办依据和下一阶段门槛。'),
        f('业务范围', '维护主业务线、协同业务线及产品明细，金额按口径逐级汇总。'),
        f('客户与团队', '维护主客户、签约／付款／使用等客户角色，以及负责人和协作团队。'),
        f('活动与关闭', '记录跟进、任务和关键动态；按赢单、输单或终止关闭，必要时拆分后续范围。')),
      '/act/new': p('销售活动记录页，用于沉淀已经发生的电话、企微、会议、拜访或手工纪要，成为任务和日报的事实基础。',
        f('事实分段录入', '按“发生了什么—关联谁—下一步做什么”记录活动类型、时间、结果、客户承诺和销售行动。'),
        f('业务对象关联', '至少关联客户、联系人、线索、商机或任务中的一个。', 'GATE'),
        f('写入预览', '保存前说明本次活动会进入哪些客户、商机动态和日报事实，并可同步创建后续任务。'),
        f('不同创建场景', '支持从商机、客户或无线索客户场景创建，并按规则继承或留空客户。')),
      '/activity/field': p('外勤拜访记录页，用于记录计划地点、实际签到、拜访内容和后续动作。',
        f('拜访签到', '记录计划地址、实际定位、签到时间及偏差提示。'),
        f('拜访回执', '填写参与人、沟通结果、附件和下一步任务。'),
        f('异常处理', '定位或设备异常允许说明原因并进入主管复核，不自动判定违规。', 'GOV')),
      '/task': p('统一任务工作台，用于管理销售自建、领导指派、规则生成和 Agent 建议任务的接收、执行、延期及验收。',
        f('任务队列', '按待确认、待接收、进行中、待验收、已完成等状态查看任务。'),
        f('执行回执', '记录开始、完成、取消、拒绝和成果，并关联销售活动。'),
        f('延期申请', '超过或临近截止时间可申请延期；逾期标识与主状态分开计算。'),
        f('条件验收', '领导指派、协作型和成果型任务按配置进入主管验收。', 'STATE')),
      '/calendar': p('销售日程视图，用时间维度展示已有计划时间的任务，并支持同步到企业微信日历。',
        f('日历视图', '按日、周查看任务、会议和拜访安排；日程是任务视图而非独立业务对象。'),
        f('冲突提示', '创建或调整计划时间时提示时间冲突和临期事项。'),
        f('企微同步', '0.1 仅对瑞赢应用创建且有外部 ID 的日程受限双向；个人企微日程不纳入，失败不改变源对象状态。', 'INTEGRATION')),
      '/ai': p('瑞赢 AI 的统一入口，用于从销售输入和已授权上下文中生成工作记录、任务推进或销售总结候选。',
        f('三类 AI 模式', '支持工作记录、任务推进和销售总结，按意图进入不同候选结构。'),
        f('来源与对象匹配', '展示引用来源，并匹配客户、联系人、线索或商机；存在歧义时要求人工选择。'),
        f('候选而非事实', 'AI 输出先进入候选，销售确认后才通过受控业务能力写入正式数据。', 'GATE')),
      '/agent/confirm': p('Agent 候选确认页，用于核对来源、事实、推断、缺失项和对象归属，再决定写入或拒绝。',
        f('候选工作队列', '集中展示来自通话、企微、拜访和规则的活动、任务、联系人补充与商机提醒候选。'),
        f('来源核对', '查看来源摘录、时间、权限状态及与候选字段的对应关系。'),
        f('候选编辑', '修改候选字段、补充缺失信息，并处理重复或对象匹配冲突。'),
        f('逐条或批量处理', '可逐条确认、忽略或选择多条确认；已处理候选可切换查看。'),
        f('确认写入', '确认后重新校验权限和业务规则；失败保留候选并可安全重试。', 'AUDIT')),
      '/report/daily': p('销售日报编辑与提交页，用于在 AI 底稿基础上确认当天事实、补充判断，并一步提交给主管。',
        f('日报底稿', '基于已确认销售活动和任务生成底稿，底稿与销售提交内容分版本保存。'),
        f('编辑与提交', '销售核对、补充后一步提交，不额外增加“待本人确认”业务状态。'),
        f('反馈与重提', '查看主管反馈；被退回后修订并重新提交，历史版本始终可追溯。', 'STATE'))
    },
    manager: {
      '/dashboard/team': p('主管团队经营看板，用于查看团队客户、商机、任务、日报和数据质量的总体情况，并定位需要介入的问题。',
        f('经营指标', '展示客户价值、业务线覆盖、商机阶段、任务闭环、日报确认、到期提醒和数据完整度。'),
        f('筛选与下钻', '按区域、团队、业务线、负责人和时间筛选，点击指标进入同口径明细。'),
        f('管理动作', '从异常项创建跟进任务或反馈，不以 AI 评分替代主管判断。')),
      '/dashboard/drill': p('管理指标的明细下钻页，用于解释看板数字由哪些业务记录组成，并执行必要的管理跟进。',
        f('口径明细', '展示指标定义、筛选条件和构成记录，汇总与明细使用同一权限和口径。'),
        f('责任定位', '查看负责人、停滞时间、下一步和缺失字段。'),
        f('转为任务', '主管可把需要处理的问题转为正式跟进任务。')),
      '/task/acceptance': p('主管任务验收队列，用于验收领导指派、协作型和成果型任务的完成结果。',
        f('验收队列', '只汇总启用验收的已提交成果，普通任务完成后不进入。'),
        f('验收处理', '查看任务目标、执行活动和成果后，选择通过或退回补充。'),
        f('记录反馈', '验收意见与任务状态变化留痕，主管不改写销售回执。', 'AUDIT')),
      '/report/list': p('主管团队日报工作台，按“提交覆盖—异常定位—明细审阅”组织信息，帮助主管先判断团队完成情况，再处理具体日报。',
        f('提交覆盖', '同时展示应提交人员数、已提交人数与实际日报份数，避免把人数和报告数混为同一口径。'),
        f('待关注事项', '集中定位待修订和未提交人员；它是异常工作队列，不是人员绩效排名。'),
        f('日报明细', '展示销售工号与团队、日报状态、提交版本、活动和任务事实、风险摘要及审阅入口。'),
        f('筛选定位', '支持按团队、状态、姓名或 ZR 工号筛选；风险文字可跳到对应 CRM 业务对象。'),
        f('未提交口径', '未提交由应提交人员清单派生，只展示人员和状态，不生成空日报正文。', 'RULE')),
      '/report/review': p('主管日报查看页，用于查看销售已提交日报、原始 AI 底稿和相关业务事实，维护本人读状态并追加建议。',
        f('日报查看', '查看销售提交版本、事实引用和提交时间。'),
        f('底稿追溯', '必要时打开 AI 原始底稿，比较销售修改内容。'),
        f('反馈或退回', '可添加反馈；只有退回才要求销售修订，主管不能直接修改原文。', 'RULE')),
      '/visit/review': p('主管拜访复核页，用于查看需要人工判断的外勤异常、拜访结果和佐证。',
        f('异常队列', '汇总定位偏差、缺少回执或规则命中的拜访记录。'),
        f('证据复核', '对照计划地点、实际定位、时间、附件和销售说明。'),
        f('复核结论', '记录通过、退回补充或转为跟进任务，不自动形成绩效处罚。', 'GOV'))
    },
    admin: {
      '/template': p('商机流程模板配置列表，用于按主业务线和销售场景管理流程版本及生效状态。',
        f('模板列表', '查看适用业务线、销售场景、版本、状态和使用中的商机数量。'),
        f('新建与复制', '基于标准阶段库创建或复制模板草稿。'),
        f('发布治理', '校验唯一匹配和关键门槛后发布；历史商机继续使用冻结版本。', 'GOV')),
      '/template/view': p('商机流程模板只读详情页，用于核对阶段、门槛、字段要求、免办和自动动作。',
        f('阶段结构', '查看详细阶段及其与五个统一阶段的映射。'),
        f('规则明细', '查看进入／退出条件、必填字段、提醒、统计和免办条件。'),
        f('版本影响', '查看当前版本适用范围和已绑定商机，不在只读页直接修改。')),
      '/template/edit': p('商机流程模板编辑器，用于配置阶段要求并在发布前完成冲突校验。',
        f('阶段编排', '选择标准阶段、顺序及统一阶段映射。'),
        f('字段与门槛', '配置阶段字段、提醒、统计和经正式确认的阻断门槛。'),
        f('免办与自动动作', '按客户或业务条件配置环节免办、字段更新和任务生成，并保留依据。'),
        f('校验发布', '检查模板唯一性、死路和不可关闭门槛后发布新版本。', 'GOV')),
      '/rules': p('线索池和基础经营参数配置页，用于定义线索进入、分派、认领、保护和回收规则。',
        f('线索池配置', '按区域、业务线、来源和角色定义可见范围。'),
        f('分派与认领', '设置管理员分派、主动认领权限、领取上限和保护期。'),
        f('回收规则', '配置超时未跟进等回收条件，规则先用于提醒和统计。')),
      '/customer-pool': p('客户公海池配置页，用于管理客户—业务线经营权的多池归属、认领和回收规则。',
        f('多公海定义', '按区域、业务线、客户类型等配置多个公海及访问角色。'),
        f('经营权规则', '设置准入、认领上限、保护期、释放和回收条件。'),
        f('冲突校验', '同一经营权不能同时命中多个有效池，发布前必须消除冲突。', 'GATE')),
      '/task-rules': p('任务规则配置页，用于分别定义任务类型、来源、验收和延期规则并冻结版本。',
        f('任务类型', '配置接收、拒绝、验收、完成说明和成果凭证。'),
        f('来源与生成方式', '业务展示来源和生成方式分别保存，并约束触发对象或来源活动。'),
        f('验收与延期', '定义验收人、退回路径、延期申请和审批；逾期不改变主状态。'),
        f('配置边界', '日报模板本期固定，个人提醒只在手机端设置，PC 不配置。', 'BOUNDARY')),
      '/report-rules': p('该旧链接只说明迁移边界，不再提供日报模板或个人提醒配置。',
        f('固定模板', '0.1 使用固定日报模板，PC 不开放模板编辑。'),
        f('个人提醒', '由销售或主管本人在手机端设置，PC 管理员不代配。')),
      '/visit-rules': p('拜访与原件治理页，用于分开配置拜访事实、异常复核和原件生命周期。',
        f('拜访规则', '按场景设置对象、地址、时间、定位、凭证和复核；支持未匹配对象拜访。'),
        f('原件策略', '按渠道和原件类型配置查看、下载、保全、期限与到期处置。'),
        f('异常与审计', '异常只提示并人工复核；普通用户不能改写或删除原件。', 'GOV')),
      '/org-people': p('组织人员管理页，用于查看从公司用户中心同步的组织人员，并维护企微身份映射和瑞赢角色。',
        f('ZR 工号', 'ZR 工号是唯一人员业务标识；姓名、组织、岗位和在离职状态来自用户中心。'),
        f('人员名册', '按组织树、工号、姓名、状态和企微映射筛选，打开人员详情查看完整身份链。'),
        f('企微映射', 'userid/openid 只用于登录、消息和日历，不替代工号。'),
        f('同步治理', '映射异常与同步记录分别成页签，支持定位异常、重试和审计。', 'INTEGRATION')),
      '/roles': p('角色与数据权限页，用于分离配置角色能力和数据范围，并预览最终有效权限。',
        f('能力矩阵', '配置对象、字段、动作、报表、Agent 和接口权限。'),
        f('数据范围', '配置本人、协作、团队、组织、区域、业务线、公海和显式共享。'),
        f('有效权限', '选择人员和对象后解释命中规则、字段掩码和最终允许或拒绝。', 'PERM')),
      '/dictionary': p('字典与字段库页面，用于版本化管理业务枚举和字段元数据。',
        f('字典版本', '历史值只停用不删除改义，发布前校验引用影响。'),
        f('字段元数据', '管理对象、编码、类型、敏感级别、必填和搜索导出属性。'),
        f('核心状态', '任务、日报和商机过程主状态只读，不开放自由扩展。', 'GOV')),
      '/quality': p('数据质量工作台，用于把规则检测结果转成有责任人、有状态的人工治理队列。',
        f('质量发现', '识别重复、缺失、孤立关系、同步失败和汇总明细不一致。'),
        f('责任闭环', '支持认领、处理、确认、忽略到期和关闭。'),
        f('不自动覆盖', '系统只给修复建议，高影响业务事实仍由有权人员确认。', 'GOV')),
      '/metrics': p('报表与指标口径页，用于维护看板汇总和明细下钻共同使用的指标定义。',
        f('完整口径', '定义公式、粒度、时间字段、过滤、去重、范围、刷新和下钻。'),
        f('版本一致', '汇总和明细引用同一版本，历史报表保留当时口径。'),
        f('未知值', '未知数据单独展示，不以 0 代替；0.1 不建设自由报表设计器。', 'RULE')),
      '/ai-ops': p('AI 操作与审计中心，用于追溯每次候选生成、人工修改、确认写入和失败重试。',
        f('操作检索', '按人员、时间、能力模式、业务对象、结果和风险筛选记录。'),
        f('来源与差异', '查看输入来源、模型候选、人工修改及最终写入差异。'),
        f('失败与重试', '定位权限、来源、校验或写入失败，并使用原幂等键安全重试。', 'AUDIT')),
      '/integration': p('外部集成配置页，用于维护业务线、工商、企微、大圆和迁移接口的连接状态与数据边界。',
        f('连接配置', '维护授权、接口地址、服务身份和可用状态，不在前端暴露密钥。'),
        f('同步策略', '配置读取方向、频率、字段映射、失败重试和降级方式。'),
        f('运行监控', '查看最近同步、错误、积压和对账结果。', 'OPS')),
      '/platform': p('旧平台聚合页已拆分为五个独立治理页面，本页只提供迁移入口。',
        f('独立页面', '组织人员、角色权限、字典字段、数据质量和指标口径分别进入。'),
        f('页面契约', '旧聚合页不再承担配置能力。', 'BOUNDARY'))
    },
    architecture: {
      '/overview': p('面向开发的系统全景页，用于先统一瑞赢服务对象、0.1 边界、外部协作系统和各端职责。',
        f('系统上下文', '展示销售、主管、运营、数据管理员与瑞赢及外部系统的关系。'),
        f('0.1 范围边界', '区分本期闭环、后续集成和不属于瑞赢事实源的能力。'),
        f('原型入口', '从架构节点直接进入销售、主管和配置端对应页面。', 'NAV')),
      '/business': p('面向开发的业务流程页，用于按正常主链、关键门槛和异常分支解释销售闭环。',
        f('六类流程图', '覆盖客户建档、公海经营权、线索转换、商机推进、每日工作和 Agent 候选。'),
        f('门槛与异常', '区分可恢复异常、必须阻断和人工确认点。'),
        f('页面追溯', '每张流程图连接对应原型与 PRD 规则文件。', 'TRACE')),
      '/application': p('面向开发的功能与应用架构页，用于说明体验入口、业务能力、公共平台和外部集成的分层。',
        f('应用分层', '从入口、业务能力、平台能力到外部系统展示逻辑依赖。'),
        f('端职责', '明确销售／主管业务工作台和 PC 配置治理端的职责边界。'),
        f('非技术部署图', '该页用于产品逻辑对齐，不预设微服务数量或物理部署。', 'BOUNDARY')),
      '/domain': p('面向开发的业务对象关系页，以 assets/business-object-model.md 为事实源，用于确认对象归属、关系对象、关键基数和实现边界。',
        f('六张关系图', '覆盖核心对象总图、客户组织关系、门店与资方、商机结构、任务／活动／日报、平台治理对象。'),
        f('经营关系粒度', '明确客户—门店、客户—门店—业务线、门店资方合作关系及公海经营权的边界。'),
        f('关系基数与约束', '在图下列出 M:N、1:N、0..1 等基数和不得自动推断、不得互相覆盖的实现规则。'),
        f('文档与原型追溯', '可跳转完整对象模型和对应业务原型；本页不是最终数据库 ER 图。', 'TRACE')),
      '/domain-new': p('面向产品与开发的连接线式概念对象关系图；在保留原对象关系页的基础上，用节点、关系线和基数展示对象网络。',
        f('六张连接线图', '覆盖核心对象、客户组织、门店与资方、商机、任务活动日报、平台治理。'),
        f('节点分类', '蓝色表示业务实体，绿色表示需要独立保存的关系对象，黄色虚线表示外部或下游对象。'),
        f('关系语义与基数', '连接线同时标注关系名称和 1:N、M:N、0..1 等产品约束。'),
        f('节点查看', '点击任一节点，右侧展示对象定义、关键约束和对应原型入口。', 'INTERACTION')),
      '/agent': p('面向开发的 Agent 可信执行架构页，用于说明 AI 从获授权输入到候选、人工确认和正式写入的控制链。',
        f('可信执行链', '展示权限、最小读取、对象匹配、候选生成、确认、写入和审计。'),
        f('失败语义', '定义歧义、来源失效、权限变化和写入失败时的处理方式。'),
        f('硬边界', 'AI 不能未经确认改变关键业务事实或对外发送。', 'GATE')),
      '/integration': p('面向开发的数据与集成边界页，用于确认每个外部系统的数据方向、0.1 用途和瑞赢责任。',
        f('集成清单', '列出业务线、工商、企微、大圆、纷享销客及后续业务系统。'),
        f('数据责任', '明确谁是事实源、瑞赢保存什么以及失败是否影响业务状态。'),
        f('分期边界', '区分 0.1 必需连接、待确认数据契约和后续复杂集成。'))
    }
  };

  function kind() {
    if (file.startsWith('manager')) return 'manager';
    if (file.startsWith('admin')) return 'admin';
    if (file.startsWith('architecture')) return 'architecture';
    return 'index';
  }

  function routeNotes() {
    const group = notes[kind()] || {};
    return [...(group['*'] || []), ...(group[route()] || [])];
  }

  function currentProfile() {
    const profile = profiles[kind()]?.[route()];
    if (profile) return profile;
    const title = document.querySelector('#view h1, #content h1, .content h1')?.textContent?.trim() || '当前页面';
    return p(`${title}用于承接当前角色在瑞赢中的对应业务操作；具体数据范围和可用动作由角色权限决定。`,
      f('页面信息查看', `查看${title}相关的业务信息、状态和关联对象。`),
      f('页面操作', `执行${title}提供的新增、编辑、筛选或处理动作，关键操作需通过服务端权限和规则校验。`));
  }

  function detailNotes(profile) {
    const seen = new Set();
    return [...profile.features, ...routeNotes()].filter(item => {
      if (seen.has(item[0])) return false;
      seen.add(item[0]);
      return true;
    });
  }

  function injectStyle() {
    const style = document.createElement('style');
    style.textContent = `
      :root{--review-ink:#14283f;--review-blue:#2864e8;--review-amber:#e4a13a;--review-paper:#fffdf8}
      body{--review-panel-width:390px}main.main{width:100%;transition:width .24s ease}body.review-open main.main{width:calc(100% - var(--review-panel-width))}
      .review-trigger{position:static;z-index:6;display:flex;flex:none;align-items:center;gap:9px;margin-left:12px;padding:8px 12px;border:1px solid #d8b36f;border-radius:10px;background:#fff8e8;color:#704a11;box-shadow:0 5px 16px #1734511c;font-weight:800;white-space:nowrap;cursor:pointer;transition:background .18s ease,border-color .18s ease,box-shadow .18s ease}
      .review-trigger b{display:grid;place-items:center;min-width:24px;height:24px;padding:0 7px;border-radius:20px;background:#e6a13b;color:#fff;font-size:11px}.review-trigger:hover{transform:translateY(-1px);box-shadow:0 18px 44px #17345138}.review-trigger:focus-visible,.review-close:focus-visible{outline:3px solid #82a9f5;outline-offset:2px}
      .review-trigger[aria-expanded="true"]{background:#f7e8c7;border-color:#c9902f;box-shadow:0 3px 10px #17345116}
      .review-drawer{position:fixed;inset:0 0 0 auto;z-index:899;width:var(--review-panel-width);padding:22px 20px 90px;border-left:1px solid #e2cfaa;background:var(--review-paper);color:var(--review-ink);box-shadow:-10px 0 28px #1734511f;overflow:auto;transform:translateX(105%);transition:transform .24s ease}.review-drawer.open{transform:none}
      .review-head{display:flex;align-items:flex-start;gap:12px;padding-bottom:16px;border-bottom:1px solid #eadfc8}.review-head>div{flex:1}.review-kicker{color:#9a681c;font-size:11px;font-weight:900;letter-spacing:.12em}.review-head h2{margin:5px 0 4px;font-size:22px}.review-head p{margin:0;color:#748194;font-size:12px}.review-close{width:34px;height:34px;border:1px solid #dfd7c8;border-radius:9px;background:#fff;cursor:pointer}
      .review-section{margin-top:18px}.review-section-title{display:flex;align-items:center;justify-content:space-between;margin:0 0 10px;color:#263b51;font-size:13px}.review-section-title span{color:#8793a2;font-size:10px;font-weight:600}.review-position{padding:14px;border-left:3px solid #d89a32;border-radius:0 11px 11px 0;background:#fff7e7;color:#5f4a27;font-size:12px;line-height:1.7}.review-position b{display:block;margin-bottom:5px;color:#805611;font-size:11px;letter-spacing:.06em}.review-function-list{display:flex;flex-direction:column;gap:0;margin:0;padding:0;border:1px solid #e7ddcb;border-radius:11px;background:#fff;list-style:none;overflow:hidden}.review-function-list li{display:flex;align-items:center;gap:9px;padding:9px 11px;border-bottom:1px solid #f0e8d9;color:#475a70;font-size:12px}.review-function-list li:last-child{border:0}.review-function-list i{display:grid;place-items:center;width:20px;height:20px;flex:none;border-radius:6px;background:#edf3ff;color:#315db3;font-style:normal;font-size:10px;font-weight:900}.review-list{display:flex;flex-direction:column;gap:10px}.review-note{position:relative;padding:14px 14px 14px 44px;border:1px solid #eadfc8;border-radius:12px;background:#fff}.review-note:before{content:attr(data-index);position:absolute;left:13px;top:13px;display:grid;place-items:center;width:22px;height:22px;border-radius:7px;background:#fff0d2;color:#8b5a10;font-weight:900;font-size:11px}.review-note strong{display:block;margin-bottom:6px;color:var(--review-ink)}.review-note p{margin:0;color:#59697b;line-height:1.62;font-size:12px}.review-type{display:inline-block;margin-top:9px;padding:3px 7px;border-radius:20px;background:#edf3ff;color:#315db3;font-size:10px;font-weight:800}.review-boundary{margin-top:18px;padding-top:14px;border-top:1px dashed #ddcfb5}.review-boundary summary{color:#74664f;font-size:11px;font-weight:800;cursor:pointer}.review-boundary .review-note{margin-top:9px;background:#fffdfa}
      .review-head h2,.review-close{color:var(--review-ink)}
      .review-inline{margin:12px 0;padding:11px 13px;border:1px dashed #dbaf60;border-radius:10px;background:#fff9eb;color:#77501a;font-size:12px;line-height:1.6}.review-inline b{margin-right:5px}.review-changed{border-color:#e4a13b!important;box-shadow:0 0 0 3px #e4a13b18}
      .review-segments{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 14px}.review-segments button{padding:8px 11px;border:1px solid #d8e1eb;border-radius:9px;background:#fff;color:#54657a;font-weight:700;cursor:pointer}.review-segments button.on{border-color:#2864e8;background:#eaf1ff;color:#2457ba}
      .review-empty{padding:30px 12px;text-align:center;color:#718095}.review-backdrop{display:none;pointer-events:none}
      @media(max-width:900px){body.review-open main.main{width:100%}.review-drawer{width:min(390px,94vw)}.review-trigger{padding:7px 10px;margin-left:8px}.review-trigger span{display:none}}
      @media(prefers-reduced-motion:reduce){.review-drawer,.review-backdrop,.review-trigger{transition:none!important}}
      @media print{.review-trigger,.review-drawer,.review-backdrop{display:none!important}}
    `;
    document.head.appendChild(style);
  }

  function createLayer() {
    const backdrop = document.createElement('div');
    backdrop.className = 'review-backdrop';
    const drawer = document.createElement('aside');
    drawer.className = 'review-drawer';
    drawer.setAttribute('aria-label', '原型评审注释');
    const trigger = document.createElement('button');
    trigger.className = 'review-trigger';
    trigger.type = 'button';
    trigger.innerHTML = '<span>查看注释</span><b>0</b>';
    document.body.append(backdrop, drawer);
    const topbar = document.querySelector('.top');
    (topbar || document.body).appendChild(trigger);
    const setOpen = value => {
      state.open = value;
      drawer.classList.toggle('open', value);
      backdrop.classList.toggle('open', value);
      document.body.classList.toggle('review-open', value);
      trigger.setAttribute('aria-expanded', String(value));
      trigger.querySelector('span').textContent = value ? '收起注释' : '查看注释';
    };
    trigger.onclick = () => setOpen(!state.open);
    backdrop.onclick = () => setOpen(false);
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') setOpen(false);
      if (event.key === '?' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) setOpen(!state.open);
    });
    return { drawer, trigger, setOpen };
  }

  let layer;
  function renderNotes() {
    const profile = currentProfile();
    const items = detailNotes(profile);
    const labels = { index: '业务工作台', manager: '主管扩展视图', admin: 'PC 配置治理', architecture: '开发架构导览' };
    const pageTitle = document.querySelector('#view h1, #content h1, .content h1')?.textContent?.trim() || labels[kind()];
    layer.trigger.querySelector('b').textContent = items.length;
    layer.drawer.innerHTML = `<div class="review-head"><div><div class="review-kicker">PAGE REVIEW</div><h2>${pageTitle}</h2><p>${labels[kind()]} · ${route()} · 按 ? 快速开关</p></div><button class="review-close" aria-label="关闭注释">×</button></div>
      <section class="review-section"><div class="review-position"><b>页面定位</b>${profile.position}</div></section>
      <section class="review-section"><h3 class="review-section-title">页面功能点 <span>共 ${items.length} 项</span></h3><ol class="review-function-list">${items.map((item, index) => `<li><i>${index + 1}</i><span>${item[0]}</span></li>`).join('')}</ol></section>
      <section class="review-section"><h3 class="review-section-title">功能点详细说明 <span>规则 · 状态 · 权限 · 异常</span></h3><div class="review-list">${items.length ? items.map((item, index) => `<article class="review-note" data-index="${index + 1}"><strong>${item[0]}</strong><p>${item[1]}</p><span class="review-type">${item[2]}</span></article>`).join('') : '<div class="review-empty">该页暂无特定注释。</div>'}</div></section>
      <details class="review-boundary"><summary>查看原型评审边界</summary>${common.map(item => `<article class="review-note"><strong>${item[0]}</strong><p>${item[1]}</p><span class="review-type">${item[2]}</span></article>`).join('')}</details>`;
    layer.drawer.querySelector('.review-close').onclick = () => layer.setOpen(false);
  }

  function showFeedback(message) {
    if (typeof toast === 'function') return toast(message);
    let node = document.querySelector('.prototype-review-toast');
    if (!node) {
      node = document.createElement('div');
      node.className = 'prototype-review-toast';
      node.style.cssText = 'position:fixed;left:50%;bottom:24px;z-index:1000;transform:translateX(-50%);padding:12px 16px;border-radius:10px;background:#102b49;color:#fff;box-shadow:0 10px 30px #102b4940';
      document.body.appendChild(node);
    }
    node.textContent = message;
    node.hidden = false;
    clearTimeout(node._timer);
    node._timer = setTimeout(() => { node.hidden = true; }, 2200);
  }

  function enhanceSearch(root) {
    root.querySelectorAll('input.search, .filters input, .listbar input').forEach(input => {
      if (input.dataset.reviewSearch) return;
      input.dataset.reviewSearch = '1';
      input.addEventListener('input', () => {
        const table = input.closest('.card')?.querySelector('table');
        if (!table) return;
        const key = input.value.trim().toLowerCase();
        let visible = 0;
        table.querySelectorAll('tbody tr').forEach(row => {
          const show = !key || row.textContent.toLowerCase().includes(key);
          row.hidden = !show;
          if (show) visible += 1;
        });
        const count = input.closest('.card')?.querySelector('.resultcount');
        if (count) count.textContent = `共 ${visible} 条`;
      });
    });
  }

  function enhanceFields(root) {
    root.querySelectorAll('input,textarea,select').forEach(control => {
      if (control.dataset.reviewField) return;
      control.dataset.reviewField = '1';
      control.addEventListener('change', () => control.classList.add('review-changed'));
    });
  }

  function enhanceOpportunityNew(root) {
    if (kind() !== 'index' || route() !== '/opp/new' || root.querySelector('[data-review-close-date]')) return;
    const firstCard = root.querySelector('.card');
    const grid = firstCard?.querySelector('.grid');
    if (!grid) return;
    const label = document.createElement('label');
    label.className = 's6';
    label.dataset.reviewCloseDate = '1';
    label.innerHTML = '<span class="sub">预计成交时间（创建可空）</span><input type="date" style="width:100%;margin-top:6px" aria-label="预计成交时间">';
    grid.appendChild(label);
    firstCard.insertAdjacentHTML('beforeend', '<div class="review-inline"><b>阶段门槛：</b>当前可留空创建；推进到需求确认前必须补齐，且流程模板不能关闭该校验。</div>');
  }

  function updateActivityFields(root) {
    const card = root.querySelector('[data-review-activity-card]');
    if (!card) return;
    const customer = card.querySelector('[data-review-customer]');
    const lead = card.querySelector('[data-review-lead]');
    const opportunity = card.querySelector('[data-review-opportunity]');
    card.querySelectorAll('[data-review-mode]').forEach(button => button.classList.toggle('on', button.dataset.reviewMode === state.activityMode));
    if (state.activityMode === 'lead') {
      customer.value = '';
      customer.placeholder = '可空：不自动创建模糊客户';
      customer.disabled = true;
      lead.value = '王先生个人用车服务 · XS-202609-0192';
      opportunity.value = '';
      opportunity.disabled = true;
    } else if (state.activityMode === 'customer') {
      customer.value = '上海澜途汽车服务有限公司';
      customer.disabled = false;
      lead.value = '';
      opportunity.value = '';
      opportunity.disabled = true;
    } else {
      customer.value = '上海澜途汽车服务有限公司';
      customer.disabled = true;
      lead.value = '';
      opportunity.value = '澜途车队服务合作 · SJ-202609-0088';
      opportunity.disabled = false;
    }
  }

  function enhanceActivity(root) {
    if (kind() !== 'index' || route() !== '/act/new' || root.querySelector('[data-review-activity-card]')) return;
    const card = root.querySelector('.card');
    if (!card) return;
    card.dataset.reviewActivityCard = '1';
    const grid = card.querySelector('div[style*="grid-template-columns"]') || card.querySelector('.grid');
    if (!grid) return;
    card.insertAdjacentHTML('afterbegin', '<div class="review-segments" aria-label="销售活动关联场景"><button type="button" data-review-mode="opportunity">从商机记录</button><button type="button" data-review-mode="lead">无客户线索</button><button type="button" data-review-mode="customer">从客户记录</button></div>');
    grid.innerHTML = `
      <label><span class="sub">销售活动类型</span><select style="width:100%;margin-top:6px"><option>电话沟通</option><option>企微消息</option><option>会议</option><option>拜访</option><option>手工纪要</option></select></label>
      <label><span class="sub">发生时间</span><input style="width:100%;margin-top:6px" value="2026-09-14 10:20"></label>
      <label><span class="sub">关联客户</span><input data-review-customer style="width:100%;margin-top:6px"></label>
      <label><span class="sub">关联线索</span><input data-review-lead style="width:100%;margin-top:6px"></label>
      <label><span class="sub">关联商机</span><input data-review-opportunity style="width:100%;margin-top:6px"></label>
      <label><span class="sub">主要联系人</span><input style="width:100%;margin-top:6px" value="周明远 · 决策人"></label>
      <label style="grid-column:1/-1"><span class="sub">沟通结果</span><textarea rows="3" style="margin-top:6px">确认 100 辆车试点，关注 10 月上线和接口费用。</textarea></label>
      <label style="grid-column:1/-1"><span class="sub">下一步</span><input style="width:100%;margin-top:6px" value="与产品确认上线排期"></label>`;
    const save = card.querySelector('[data-act="saveActivity"]');
    if (save) save.dataset.reviewSaveActivity = '1';
    card.insertAdjacentHTML('beforeend', '<div class="review-inline"><b>WORK-12：</b>至少关联一个业务对象。切换上方场景，可演示无客户线索和商机主客户继承。</div>');
    updateActivityFields(root);
  }

  function enhancePage() {
    const root = document.querySelector('#view, #content, .content') || document.body;
    enhanceSearch(root);
    enhanceFields(root);
    enhanceOpportunityNew(root);
    enhanceActivity(root);
  }

  document.addEventListener('click', event => {
    const mode = event.target.closest('[data-review-mode]');
    if (mode) {
      state.activityMode = mode.dataset.reviewMode;
      updateActivityFields(document.querySelector('#view') || document.body);
      const message = state.activityMode === 'lead' ? '已切换：线索未识别客户，客户留空且不创建模糊客户' : state.activityMode === 'customer' ? '已切换：从客户直接记录，客户必填' : '已切换：关联商机并继承、锁定商机主客户';
      showFeedback(message);
      return;
    }
    const saveActivity = event.target.closest('[data-review-save-activity]');
    if (saveActivity) {
      event.preventDefault();
      event.stopImmediatePropagation();
      showFeedback(state.activityMode === 'lead' ? '销售活动已保存：关联线索，客户仍为空' : '销售活动已保存并进入对象时间线与日报事实');
      setTimeout(() => { location.hash = state.activityMode === 'lead' ? '#/lead/detail' : '#/opp/detail'; }, 500);
      return;
    }
    const button = event.target.closest('button.btn, .btn');
    if (!button || button.disabled || button.closest('.review-drawer') || button.matches('[data-go],[data-act],[data-cfg],[data-mgr],[data-role-url],[data-view],[data-diagram]') || button.id) return;
    showFeedback(`注释版：“${button.textContent.trim() || '该操作'}”将在正式页面打开对应筛选、导出或详情能力。`);
  }, true);

  injectStyle();
  layer = createLayer();
  renderNotes();
  layer.setOpen(false);
  enhancePage();

  let queued = false;
  const observer = new MutationObserver(() => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => { queued = false; enhancePage(); });
  });
  observer.observe(document.body, { childList: true, subtree: true });
  window.addEventListener('hashchange', () => setTimeout(() => { renderNotes(); enhancePage(); }, 0));
})();
