/* ==========================================================================
 * 瑞赢 0.1 · PC 原型跨页演示状态（prototype-store.js）
 * --------------------------------------------------------------------------
 * 职责：
 *  1. 以 sessionStorage 保存跨页演示状态：当前模拟角色、样例对象变更结果、
 *     列表作用域与筛选、批量选中、处理记录、消息已读状态。
 *  2. 提供对象级变更方法（新建、编辑、转换、阶段推进／回退、休眠、关闭、拆分、
 *     公海认领／分派／回收、批量与导入导出结果落库），保证跨页数据一致。
 *  3. 提供「重置演示数据」。
 *
 * 边界：本文件只负责演示状态与数据变更，不渲染任何业务页面，也不承担权限判定
 *       （权限判定见 permissions.js）。
 *
 * 说明：本原型不连接任何真实接口；所有「工商查询」「异步执行」「并发冲突」
 *       均为可预期的演示模拟，用于呈现交互和状态表达，不代表生产技术实现。
 * ========================================================================== */
window.RY = window.RY || {};

RY.store = (function () {
  'use strict';

  var KEY = RY.seed.meta.storeKey;
  var SEQ_START = { CUS: 20, CON: 12, LED: 150, OPP: 60, OBL: 20, CBL: 20, CPH: 10, ORGREL: 10, ADR: 20, OUT: 10, CR: 10, TSK: 90, ACT: 100, VH: 10, EXC: 10, JOB: 10, MSG: 300, AUD: 10, CRQ: 1,
    /* 0.1 全量原型新增对象序列 */
    SCH: 10, RPT: 10, RUN: 10, CAND: 10, KB: 10, MT: 10, MD: 10, EXT: 10, SYNC: 10, QI: 10, QR: 10, PP: 10, HO: 10, PSY: 10 };

  var db = null;

  function now() {
    var d = new Date();
    function p(n) { return n < 10 ? '0' + n : '' + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }

  function today() { return now().slice(0, 10); }

  function addDays(dateStr, n) {
    var d = dateStr ? new Date(dateStr.replace(/-/g, '/')) : new Date();
    d.setDate(d.getDate() + n);
    function p(x) { return x < 10 ? '0' + x : '' + x; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }

  function fresh() {
    var s = RY.cloneSeed();
    s.runtime = {
      role: 'R1',
      userId: 'U-001',
      seq: JSON.parse(JSON.stringify(SEQ_START)),
      listState: {},
      selection: {},
      uiState: {},
      lastImport: null
    };
    return s;
  }

  function load() {
    if (db) return db;
    var raw = null;
    try { raw = window.sessionStorage.getItem(KEY); } catch (e) { raw = null; }
    if (raw) {
      try { db = JSON.parse(raw); } catch (e2) { db = null; }
    }
    if (!db || !db.runtime || !db.customers) db = fresh();
    return db;
  }

  function save() {
    try { window.sessionStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { /* 隐私模式下降级为内存态 */ }
    return db;
  }

  function reset() {
    db = fresh();
    save();
    return db;
  }

  function month() { return RY.seed.meta.demoDate.slice(0, 7).replace('-', ''); }

  function nextId(prefix, pad) {
    load();
    var n = (db.runtime.seq[prefix] || 0) + 1;
    db.runtime.seq[prefix] = n;
    var s = '' + n;
    while (s.length < (pad || 4)) s = '0' + s;
    return prefix + '-' + month() + '-' + s;
  }

  /* --------------------------------------------------------------- 角色 */

  function role() { return load().runtime.role; }
  /* 原型演示身份：切换角色时同步切换到该角色的代表性演示用户，
     使「我的／团队」范围、日报归属和权限结果自洽。生产系统没有身份切换。 */
  var ROLE_REP = { R1: 'U-001', R2: 'U-003', R3: 'U-004', R4: 'U-005', R5: 'U-006' };
  function setRole(r) {
    load().runtime.role = r;
    if (ROLE_REP[r]) load().runtime.userId = ROLE_REP[r];
    save();
  }
  function setUser(id) { load().runtime.userId = id; save(); }
  function currentUser() {
    var st = load().runtime;
    var byId = db.users.filter(function (u) { return u.id === st.userId; })[0];
    if (byId) return byId;
    var candidates = db.users.filter(function (u) { return u.role === st.role; });
    return candidates[0] || db.users[0];
  }
  function user(id) {
    load();
    for (var i = 0; i < db.users.length; i++) if (db.users[i].id === id) return db.users[i];
    return null;
  }
  function userName(id) { var u = user(id); return u ? u.name : '—'; }

  /* --------------------------------------------------------------- 查询 */

  function find(list, id) {
    load();
    var arr = db[list] || [];
    for (var i = 0; i < arr.length; i++) if (arr[i].id === id) return arr[i];
    return null;
  }
  function all(list) { load(); return db[list] || []; }

  function customer(id) { return find('customers', id); }
  function contact(id) { return find('contacts', id); }
  function store(id) { return find('stores', id); }
  function lead(id) { return find('leads', id); }
  function opp(id) { return find('opportunities', id); }
  function job(id) { return find('jobs', id); }
  function template(code, version) {
    var ts = all('templates');
    for (var i = 0; i < ts.length; i++) {
      if (ts[i].code === code && (!version || ts[i].version === version)) return ts[i];
    }
    return null;
  }
  function templateByKey(code, version) {
    return template(code, version);
  }
  function customField(code) {
    var fs = all('customFields');
    for (var i = 0; i < fs.length; i++) if (fs[i].code === code) return fs[i];
    return null;
  }
  function regionName(code) {
    var rs = all('regions');
    for (var i = 0; i < rs.length; i++) if (rs[i].code === code) return rs[i].name;
    return code || '—';
  }
  function businessLineName(code) {
    var bs = all('businessLines');
    for (var i = 0; i < bs.length; i++) if (bs[i].code === code) return bs[i].name;
    return code || '—';
  }
  function scenarioByLine(line, scene) {
    var ss = all('scenarios');
    for (var i = 0; i < ss.length; i++) if (ss[i].businessLine === line && ss[i].name === scene) return ss[i];
    return null;
  }
  function scenarioOptions(line) {
    return all('scenarios').filter(function (s) { return s.businessLine === line; });
  }

  /** 模板唯一匹配：主业务线 + 销售场景 → 恰一个生效模板。返回 {state, template, candidates} */
  function matchTemplate(lineCode, sceneCode, opts) {
    opts = opts || {};
    if (opts.forceServiceError) return { state: 'service-error', candidates: [] };
    var ts = all('templates').filter(function (t) {
      return t.businessLine === lineCode && t.scene === sceneCode && t.status === '生效';
    });
    if (ts.length === 1) return { state: 'ok', template: ts[0], candidates: ts };
    if (ts.length === 0) return { state: 'missing', template: null, candidates: ts };
    return { state: 'multi', template: null, candidates: ts };
  }

  /* --------------------------------------------------------- 客户与关系 */

  function pendingGovernance(customerId) {
    var es = all('exceptions').filter(function (e) {
      return e.objectId === customerId && e.status !== '已完成' && e.status !== '不采纳';
    });
    return es.length > 0;
  }

  function relationsOf(customerId) {
    return all('businessRelations').filter(function (r) { return r.customerId === customerId; });
  }

  function createCustomer(input) {
    load();
    var id = nextId('CUS');
    var c = {
      id: id, name: input.name, alias: input.alias || '', type: input.type, status: '正常',
      identity: input.identity || '未核验', creditCode: input.creditCode || '',
      creditMissing: !input.creditCode && input.type !== '自然人客户',
      value: '', valueReview: '', valueAdjustedAt: '', valueReviewer: '',
      legalPerson: input.legalPerson || '', regCapital: input.regCapital || '', foundDate: input.foundDate || '',
      industry: input.industry || '', businessScope: input.businessScope || '',
      source: input.source || '人工录入', remark: input.remark || '',
      createdAt: now(), updatedAt: now(),
      industrySource: input.industrySource || '工商查询服务', industryQueriedAt: now(),
      industryState: input.industryState || '正常成功',
      contactsCount: 0, storesCount: 0, oppsCount: 0
    };
    db.customers.unshift(c);
    if (c.creditMissing && c.type !== '自然人客户') {
      db.exceptions.unshift({
        id: nextId('EXC'), objectType: '客户', objectId: id, target: '统一社会信用代码',
        type: '完整度缺失', status: '待处理', handler: '', source: '系统',
        createdAt: now(), updatedAt: now(),
        note: '建档时缺统一社会信用代码；不阻断经营，由客户数据管理补全。'
      });
    }
    audit('客户', id, '新建客户', '—', c.name + '（' + c.type + '）');
    save();
    return c;
  }

  function activeRelationsOf(customerId) {
    return relationsOf(customerId).filter(function (r) { return r.status === '有效' && !!r.owner; });
  }

  function ownerRegionOptions(ownerId) {
    var u = user(ownerId || currentUser().id);
    return u ? (u.region || []).slice() : [];
  }

  /* 建档统一入口：客户主档与初始经营关系同一事务创建。
     0.1 不按角色改写默认负责人，也不以区域／业务线资格阻断提交。 */
  function createCustomerWithInitialRelation(customerInput, relationInput, idempotencyKey) {
    load();
    db.runtime.idempotency = db.runtime.idempotency || {};
    if (idempotencyKey && db.runtime.idempotency[idempotencyKey]) return db.runtime.idempotency[idempotencyKey];
    relationInput = relationInput || {};
    var owner = relationInput.owner || currentUser().id;
    var region = relationInput.region;
    var line = relationInput.businessLine;
    if (!customerInput || !String(customerInput.name || '').trim()) return { ok: false, reason: '请填写客户名称。' };
    if (!user(owner)) return { ok: false, reason: '负责人不存在或已失效。' };
    if (!region || !all('regions').some(function (x) { return x.code === region; })) return { ok: false, reason: '请选择有效经营区域。' };
    if (!line || !all('businessLines').some(function (x) { return x.code === line && x.status === '启用'; })) return { ok: false, reason: '请选择有效业务线。' };
    var snapshot = JSON.parse(JSON.stringify(db));
    try {
      var c = createCustomer(customerInput);
      var rel = {
        id: nextId('CBL'), customerId: c.id, customerName: c.name,
        region: region, businessLine: line, status: '有效', owner: owner,
        collaborators: [], poolRecordId: '', protectUntil: '', lastActivityAt: today(), createdAt: today()
      };
      db.businessRelations.unshift(rel);
      audit('客户经营关系', rel.id, '创建初始经营关系', '—', c.name + '｜' + regionName(region) + '｜' + businessLineName(line) + '｜主负责人：' + userName(owner));
      var result = { ok: true, customer: c, relation: rel };
      if (idempotencyKey) db.runtime.idempotency[idempotencyKey] = result;
      save();
      return result;
    } catch (e) {
      db = snapshot;
      save();
      return { ok: false, reason: '创建失败，客户主档与初始经营关系均未创建。' };
    }
  }

  function updateCustomer(id, patch, actionName) {
    load();
    var c = customer(id);
    if (!c) return null;
    var before = [];
    Object.keys(patch).forEach(function (k) {
      if (c[k] !== patch[k]) before.push(k + '：' + (c[k] || '—'));
      c[k] = patch[k];
    });
    c.updatedAt = now();
    if (before.length) audit('客户', id, actionName || '普通字段编辑', before.join('；'), Object.keys(patch).map(function (k) { return k + '：' + (patch[k] || '—'); }).join('；'));
    save();
    return c;
  }

  function createContact(input) {
    load();
    var id = nextId('CON');
    var plain = input.phonePlain || '';
    var c = {
      id: id, name: input.name, phone: input.phone || maskPhone(plain), phonePlain: plain,
      wechat: input.wechat || '', email: input.email || '', title: input.title || '',
      org: input.org || '', addressId: '', createdAt: now(), lastContactAt: ''
    };
    db.contacts.unshift(c);
    audit('联系人', id, '新建联系人', '—', c.name);
    save();
    return c;
  }

  function maskPhone(p) {
    if (!p || p.length < 7) return p || '';
    return p.slice(0, 3) + '****' + p.slice(7);
  }

  function addContactRelation(contactId, customerId, roles, dept, title, primary) {
    load();
    var id = nextId('CR');
    var r = { id: id, contactId: contactId, customerId: customerId, roles: roles, dept: dept || '', title: title || '', primary: !!primary, status: '有效', from: today() };
    db.contactRelations.unshift(r);
    var c = customer(customerId);
    if (c) c.contactsCount = all('contactRelations').filter(function (x) { return x.customerId === customerId && x.status === '有效'; }).length;
    audit('联系人关系', id, '新增联系人客户关系', '—', customerId);
    save();
    return r;
  }

  function createStore(input) {
    load();
    var id = nextId('OUT');
    var s = {
      id: id, name: input.name, customerId: input.customerId,
      addressText: input.addressText || '', status: '正常', businessLines: input.businessLines || [],
      createdAt: now(), updatedAt: now()
    };
    db.stores.unshift(s);
    var c = customer(input.customerId);
    if (c) c.storesCount = all('stores').filter(function (x) { return x.customerId === input.customerId; }).length;
    audit('门店', id, '新建门店', '—', s.name);
    save();
    return s;
  }

  function updateStore(id, patch) {
    load();
    var s = store(id);
    if (!s) return null;
    Object.keys(patch).forEach(function (k) { s[k] = patch[k]; });
    s.updatedAt = now();
    audit('门店', id, '门店编辑', '—', Object.keys(patch).join('、'));
    save();
    return s;
  }

  function createAddress(input) {
    load();
    var id = nextId('ADR');
    var a = {
      id: id, ownerType: input.ownerType, ownerId: input.ownerId, type: input.type,
      region: input.region, detail: input.detail, source: input.source || '人工录入', createdAt: now()
    };
    db.addresses.unshift(a);
    audit('地址', id, '新增地址', '—', a.type + ' ' + a.detail);
    save();
    return a;
  }

  function removeAddress(id, reason) {
    load();
    var idx = db.addresses.findIndex(function (x) { return x.id === id; });
    if (idx < 0) return { ok: false, reason: '地址不存在或已被移除。' };
    var a = db.addresses[idx];
    if (a.type === '注册地址') return { ok: false, reason: '注册地址属于高影响字段，请走资料变更申请。' };
    db.addresses.splice(idx, 1);
    audit('地址', id, '移除当前地址', a.type + '｜' + a.region + '｜' + a.detail, '已移除｜说明：' + (reason || '—'));
    save();
    return { ok: true, address: a };
  }

  function setCustomerIdentity(customerId, value, note) {
    load();
    var c = customer(customerId);
    if (!c) return { ok: false, reason: '客户不存在。' };
    if (['未核验', '已核验', '需复核'].indexOf(value) < 0) return { ok: false, reason: '核验状态不合法。' };
    var from = c.identity;
    c.identity = value;
    c.updatedAt = now();
    audit('客户', customerId, '身份核验调整', from, value + (note ? '｜说明：' + note : ''));
    save();
    return { ok: true, customer: c };
  }

  function submitGroupCandidate(input) {
    load();
    var id = nextId('GC');
    db.exceptions.unshift({
      id: id, objectType: '客户候选', objectId: id, target: '集团客户建档', type: '高影响建档',
      status: '待处理', handler: '', source: '销售', createdAt: now(), updatedAt: now(),
      note: '集团名称：' + input.name + '｜其他名称：' + (input.alias || '—') + '｜申请说明：' + (input.note || '—'), values: input
    });
    audit('客户候选', id, '提交集团客户候选', '—', input.name);
    save();
    return db.exceptions[0];
  }

  function confirmGroupCandidate(exceptionId, relationInput) {
    load();
    var e = find('exceptions', exceptionId);
    if (!e || e.type !== '高影响建档' || e.status === '已完成') return { ok: false, reason: '集团候选不存在或已处理。' };
    var v = e.values || {};
    var made = createCustomerWithInitialRelation({ name: v.name, alias: v.alias || '', type: '集团客户', creditCode: v.creditCode || '', source: v.source || '销售提交', remark: v.note || '' }, relationInput || v.initialRelation, 'group-confirm:' + exceptionId);
    if (!made.ok) return made;
    e.status = '已完成'; e.handler = currentUser().id; e.updatedAt = now(); e.createdCustomerId = made.customer.id;
    audit('客户候选', exceptionId, '正式确认集团客户', '候选', made.customer.id + '｜' + made.relation.id);
    save();
    return made;
  }

  function setCustomerValue(customerId, value, reason) {
    load();
    var c = customer(customerId);
    if (!c) return null;
    var from = c.value;
    c.value = value;
    c.valueReview = '待复核';
    c.valueAdjustedAt = today();
    c.valueReviewer = '';
    db.valueHistory.unshift({
      id: nextId('VH'), customerId: customerId, action: from ? '调整' : '设置', from: from, to: value,
      reason: reason, operator: currentUser().name, at: now()
    });
    save();
    return c;
  }

  function reviewCustomerValue(customerId, agree, reason) {
    load();
    var c = customer(customerId);
    if (!c) return null;
    c.valueReview = '已复核';
    c.valueReviewer = currentUser().name;
    c.valueAdjustedAt = today();
    db.valueHistory.unshift({
      id: nextId('VH'), customerId: customerId, action: agree ? '复核确认' : '复核退回',
      from: c.value, to: c.value, reason: reason || (agree ? '同意销售判断' : '退回销售重新判断'),
      operator: currentUser().name, at: now()
    });
    save();
    return c;
  }

  function submitHighImpact(customerId, payload) {
    load();
    var id = nextId('EXC');
    var e = {
      id: id, objectType: '客户', objectId: customerId, target: payload.target, type: '高影响字段变更',
      status: '待处理', handler: '', source: '销售', createdAt: now(), updatedAt: now(),
      note: payload.note,
      submitted: payload.values
    };
    db.exceptions.unshift(e);
    audit('客户', customerId, '提交高影响资料变更', payload.from || '—', payload.to || '—');
    save();
    return e;
  }

  function handleException(id, action) {
    load();
    var e = find('exceptions', id);
    if (!e) return null;
    if (action === 'claim') { e.status = '处理中'; e.handler = currentUser().id; }
    if (action === 'return') { e.status = '待处理'; e.handler = ''; }
    if (action === 'done') { e.status = '已完成'; e.handler = e.handler || currentUser().id; }
    if (action === 'reject') { e.status = '不采纳'; e.handler = e.handler || currentUser().id; }
    e.updatedAt = now();
    if (action === 'done' && e.submitted && e.objectId) {
      var c = customer(e.objectId);
      if (c && e.submitted.name) c.name = e.submitted.name;
      if (c && e.submitted.creditCode) { c.creditCode = e.submitted.creditCode; c.creditMissing = false; }
    }
    audit('异常事项', id, '资料治理·' + action, e.status, e.status);
    save();
    return e;
  }

  /* ----------------------------------------------------------- 全国公海 */

  function poolRecords() {
    return all('poolRecords').filter(function (p) { return p.status === '有效'; });
  }

  function claimPool(recordId, actorId, input) {
    load();
    input = input || {};
    var p = find('poolRecords', recordId);
    if (!p || p.status !== '有效') return { ok: false, reason: '该公海记录已不在池内。' };
    if (p.claimedBy) return { ok: false, reason: '该客户已被' + userName(p.claimedBy) + '认领，请刷新后重试。' };
    if (activeRelationsOf(p.customerId).length) return { ok: false, reason: '该客户已存在有效经营关系，不能从全国公海认领或分派。' };
    if (!input.region || !input.businessLine) return { ok: false, reason: '认领时必须选择经营区域和业务线。' };
    p.claimedBy = actorId;
    p.status = '已认领';
    p.claimAt = now();
    var c = customer(p.customerId);
    var rel = { id: nextId('CBL'), customerId: p.customerId, customerName: c.name, region: input.region, businessLine: input.businessLine, status: '有效', owner: actorId, collaborators: [], poolRecordId: '', protectUntil: addDays(today(), 7), lastActivityAt: today(), createdAt: today() };
    db.businessRelations.unshift(rel);
    p.relationId = rel.id;
    audit('客户', p.customerId, '全国公海认领', '无有效经营关系', regionName(input.region) + '｜' + businessLineName(input.businessLine) + '｜主负责人：' + userName(actorId));
    save();
    return { ok: true, record: p, relation: rel };
  }

  function assignPool(recordId, targetId, input) {
    var r = claimPool(recordId, targetId, input);
    if (r.ok) { r.record.status = '已分派'; r.record.assignedTo = targetId; r.record.assignAt = now(); save(); }
    return r;
  }

  /* 停止经营关系；当客户已无其他有效关系时，系统自动将客户主档放入全国公海。 */
  function releasePool(relationId, reason) {
    load();
    var rel = find('businessRelations', relationId);
    if (!rel) return null;
    var prev = rel.owner;
    rel.status = '停止经营';
    rel.stopReason = reason || '停止经营';
    rel.owner = '';
    rel.poolRecordId = '';
    rel.protectUntil = '';
    var c = customer(rel.customerId);
    if (activeRelationsOf(rel.customerId).length) { save(); return rel; }
    var existing = poolRecords().filter(function (p) { return p.customerId === rel.customerId; })[0];
    if (!existing) db.poolRecords.unshift({
      id: nextId('CPH'), customerId: rel.customerId,
      customerName: rel.customerName, customerType: c ? c.type : '—', customerValue: c ? c.value : '',
      status: '有效',
      entryAt: now(), entryReason: '最后一条有效经营关系停止', entryNote: reason || '', lastActivityAt: rel.lastActivityAt,
      claimable: true, prevOwner: prev, prevCollaborators: (rel.collaborators || []).slice(), previousRelationIds: [rel.id]
    });
    rel.collaborators = [];
    audit('客户', rel.customerId, '进入全国公海', '存在有效经营关系', '无有效经营关系');
    save();
    return rel;
  }

  function recyclePool(relationId, reason) {
    return releasePool(relationId, reason || '停止经营');
  }

  function addCollaborator(relationId, userId) {
    load();
    var rel = find('businessRelations', relationId);
    if (!rel) return null;
    rel.collaborators = rel.collaborators || [];
    if (rel.collaborators.indexOf(userId) === -1) rel.collaborators.push(userId);
    audit('客户经营关系', relationId, '新增协作人', '—', userName(userId));
    save();
    return rel;
  }

  function stopOperating(relationId, reason) {
    return releasePool(relationId, reason || '停止经营');
  }

  /* 主动建立额外经营关系（prd/01 §8.2）：
     新建客户已原子创建初始经营关系；本入口用于已有客户增加其他经营关系。
     销售只能在本人同时具备该区域与该业务线资格时建立；默认本人为主负责人，可同时加协作人。
     校验顺序：客户可用 → 区域/业务线 → 资格 → 重复单元 → 公海占用 → 持有上限。
     主动建关系不产生保护期：保护期只由全国公海分派或认领产生。 */
  var RELATION_HOLD_LIMIT = 30;

  function relationHoldCount(userId) {
    var uid = userId || currentUser().id;
    return all('businessRelations').filter(function (r) {
      return r.status === '有效' && r.owner === uid;
    }).length;
  }

  function userQualified(userId, region, businessLine) {
    var u = user(userId || currentUser().id);
    if (!u) return false;
    return (u.region || []).indexOf(region) !== -1 && (u.businessLine || []).indexOf(businessLine) !== -1;
  }

  function relationPrecheck(customerId, region, businessLine) {
    var c = customer(customerId);
    if (!c) return { ok: false, reason: '客户不存在或已被合并，请返回列表重新进入。' };
    if (c.status !== '正常') return { ok: false, reason: '客户当前状态为「' + c.status + '」，不能建立经营关系。' };
    if (!region) return { ok: false, reason: '请选择区域。' };
    if (!businessLine) return { ok: false, reason: '请选择业务线。' };
    if (!userQualified(null, region, businessLine)) {
      return { ok: false, reason: '你在「' + regionName(region) + '／' + businessLineName(businessLine) + '」不具备资格，不能主动建立经营关系。' };
    }
    var same = all('businessRelations').filter(function (r) {
      return r.customerId === customerId && r.region === region && r.businessLine === businessLine;
    });
    /* 公海与有效经营关系互斥：池内客户应通过认领或分派创建初始关系。 */
    var pool = all('poolRecords').filter(function (p) {
      return p.customerId === customerId && p.status === '有效';
    })[0];
    if (pool) {
      return { ok: false, reason: '该客户当前在全国公海（' + pool.id + '），请通过认领或主管分派创建初始经营关系。' };
    }
    var dup = same.filter(function (r) { return r.status === '有效'; })[0];
    if (dup) {
      return { ok: false, reason: '该客户在「' + regionName(region) + '／' + businessLineName(businessLine) + '」已有有效经营关系（' + dup.id + '，主负责人：' + (dup.owner ? userName(dup.owner) : '空') + '）。同一经营单元不能重复建立，如需接手请走公海认领或主管分派。' };
    }
    if (relationHoldCount() >= RELATION_HOLD_LIMIT) {
      return { ok: false, reason: '你当前主负责的有效经营关系已达上限（' + relationHoldCount() + ' / ' + RELATION_HOLD_LIMIT + ' 条）。持有量只统计主负责的有效关系，协作与停止经营不计。请先停止不再经营的关系或由主管转派。' };
    }
    return { ok: true, stopped: same.filter(function (r) { return r.status === '停止经营'; })[0] || null };
  }

  function createRelation(customerId, input) {
    load();
    var pre = relationPrecheck(customerId, input.region, input.businessLine);
    if (!pre.ok) return pre;
    var c = customer(customerId);
    var owner = input.owner || currentUser().id;
    var rel = pre.stopped;
    if (rel) {
      /* 同一单元曾停止经营：恢复原单元，不再建第二个单元，避免重复经营单元。 */
      rel.status = '有效';
      rel.owner = owner;
      rel.collaborators = (input.collaborators || []).slice();
      rel.stopReason = '';
      rel.poolRecordId = '';
      rel.protectUntil = '';
      rel.lastActivityAt = today();
      audit('客户经营关系', rel.id, '恢复经营', '停止经营',
        '有效（主负责人：' + userName(owner) + '｜' + regionName(rel.region) + '｜' + businessLineName(rel.businessLine) + '）');
    } else {
      rel = {
        id: nextId('CBL'), customerId: customerId, customerName: c.name,
        region: input.region, businessLine: input.businessLine, status: '有效',
        owner: owner, collaborators: (input.collaborators || []).slice(),
        poolRecordId: '', protectUntil: '', lastActivityAt: today(), createdAt: today()
      };
      db.businessRelations.unshift(rel);
      audit('客户经营关系', rel.id, '主动建立经营关系', '—',
        c.name + '｜' + regionName(rel.region) + '｜' + businessLineName(rel.businessLine) + '｜主负责人：' + userName(owner));
    }
    save();
    return { ok: true, relation: rel, restarted: !!pre.stopped };
  }

  /* 指派／直接转派主负责人（prd/01 §8.2）：
     主管可直接转派，不经全国公海；目标须通过资格与持有上限校验；
     默认保留协作人，也可同次调整。与主动建关系一样不产生保护期。
     注意：这里既不创建也不清除 protectUntil —— 保护期只由公海认领或分派产生，
     转派时既有保护期属于该经营单元，是否延续不由原型擅自决定。 */
  function relationCandidates(region, businessLine, excludeId) {
    return all('users').filter(function (x) {
      if (x.id === excludeId) return false;
      if (x.role !== 'R1' && x.role !== 'R2') return false;
      return userQualified(x.id, region, businessLine);
    });
  }

  function relationOwnerPrecheck(relationId, targetId) {
    var rel = find('businessRelations', relationId);
    if (!rel) return { ok: false, reason: '经营关系不存在，请返回列表重新进入。' };
    if (rel.status !== '有效') return { ok: false, reason: '该经营关系当前为「' + rel.status + '」，不能调整主负责人。' };
    if (!targetId) return { ok: false, reason: '请选择目标主负责人。' };
    if (rel.owner === targetId) return { ok: false, reason: '目标已是该经营关系的主负责人，无需调整。' };
    if (!userQualified(targetId, rel.region, rel.businessLine)) {
      return { ok: false, reason: userName(targetId) + '不具备「' + regionName(rel.region) + '／' + businessLineName(rel.businessLine) + '」的经营资格，不能作为主负责人。' };
    }
    var n = relationHoldCount(targetId);
    if (n >= RELATION_HOLD_LIMIT) {
      return { ok: false, reason: userName(targetId) + ' 当前主负责的有效经营关系已达上限（' + n + ' / ' + RELATION_HOLD_LIMIT + ' 条），不能承接新的经营单元。' };
    }
    return { ok: true, relation: rel };
  }

  function setRelationOwner(relationId, targetId, opts) {
    load();
    opts = opts || {};
    var pre = relationOwnerPrecheck(relationId, targetId);
    if (!pre.ok) return pre;
    var rel = pre.relation;
    var before = rel.owner ? userName(rel.owner) : '空（待分配）';
    var keep = opts.collaborators === undefined || opts.collaborators === null;
    var cols = keep ? (rel.collaborators || []) : (opts.collaborators || []);
    /* 新主负责人不应同时是自己的协作人。 */
    rel.collaborators = cols.filter(function (x) { return x !== targetId; });
    rel.owner = targetId;
    rel.poolRecordId = '';
    rel.lastActivityAt = today();
    audit('客户经营关系', rel.id, opts.action || '直接转派主负责人', '主负责人：' + before,
      '主负责人：' + userName(targetId) + '（原因：' + (opts.reason || '—') + '）'
      + (keep ? '｜协作人保留' : '｜协作人同次调整为：' + (rel.collaborators.length ? rel.collaborators.map(userName).join('、') : '无')));
    save();
    return { ok: true, relation: rel };
  }

  function assignRelationOwner(relationId, targetId, reason) {
    return setRelationOwner(relationId, targetId, { reason: reason, action: '指派主负责人' });
  }

  function transferRelation(relationId, targetId, opts) {
    return setRelationOwner(relationId, targetId, opts);
  }

  /* ----------------------------------------------------------------- 线索 */

  function createLead(input) {
    load();
    var id = nextId('LED');
    var l = {
      id: id, raw: input.raw, source: input.source, sourceRecord: input.sourceRecord || '人工录入',
      status: '待处理', customerId: input.customerId || '', contactId: input.contactId || '',
      phone: input.phone || '', candidateLines: input.candidateLines || [], candidateProducts: [],
      currentPool: input.currentPool || '', sourcePool: input.sourcePool || '', owner: input.owner || '',
      protectUntil: '', nextAction: '', nextFollowUp: '', lastFollowUpAt: '',
      idempotencyKey: input.idempotencyKey || '',
      createdAt: now(), createdBy: currentUser().id
    };
    if (l.owner) {
      var pool = poolOf(l.sourcePool);
      l.protectUntil = pool && pool.protectEnabled ? addDays(today(), pool.protectDays) + ' 22:00' : '';
    } else if (l.currentPool && !l.owner) {
      l.currentPool = l.currentPool;
    }
    db.leads.unshift(l);
    audit('线索', id, '新建线索', '—', l.raw.slice(0, 30));
    save();
    return l;
  }

  function poolOf(code) {
    var ps = all('leadPools');
    for (var i = 0; i < ps.length; i++) if (ps[i].code === code) return ps[i];
    return null;
  }

  function updateLead(id, patch, actionName) {
    load();
    var l = lead(id);
    if (!l) return null;
    Object.keys(patch).forEach(function (k) { l[k] = patch[k]; });
    audit('线索', id, actionName || '线索编辑', '—', Object.keys(patch).join('、'));
    save();
    return l;
  }

  function leadAction(id, action, payload) {
    load();
    var l = lead(id);
    if (!l) return { ok: false, reason: '线索不存在。' };
    payload = payload || {};
    var pool = poolOf(l.sourcePool) || poolOf(l.currentPool);

    if (action === 'claim') {
      if (l.status === '已转化' || l.status === '无效') return { ok: false, reason: '终态线索不允许认领。' };
      if (!l.currentPool) return { ok: false, reason: '该线索当前不在池内，无法认领。' };
      var p = poolOf(l.currentPool);
      if (!p || !p.allowClaim) return { ok: false, reason: '当前池未开放主动认领。' };
      if (l.claimLocked) return { ok: false, reason: '该线索已被他人认领，请刷新后查看最新归属。' };
      if (payload.holdCount >= p.holdLimit) return { ok: false, reason: '你当前持有的线索已达该池上限（' + p.holdLimit + ' 条）。' };
      l.owner = currentUser().id;
      l.currentPool = '';
      l.status = l.status === '待处理' ? '跟进中' : l.status;
      l.protectUntil = p.protectEnabled ? addDays(today(), p.protectDays) + ' 22:00' : '';
    }
    if (action === 'assign') {
      if (l.status === '已转化' || l.status === '无效') return { ok: false, reason: '终态线索不允许分派。' };
      if (!payload.target) return { ok: false, reason: '请选择目标负责人。' };
      l.owner = payload.target;
      l.currentPool = '';
      l.status = l.status === '待处理' ? '跟进中' : l.status;
      l.protectUntil = pool && pool.protectEnabled ? addDays(today(), pool.protectDays) + ' 22:00' : '';
    }
    if (action === 'transfer') {
      if (!payload.target) return { ok: false, reason: '请选择受让人。' };
      l.owner = payload.target;
      l.protectUntil = pool && pool.protectEnabled ? addDays(today(), pool.protectDays) + ' 22:00' : '';
    }
    if (action === 'returnPool') {
      l.currentPool = payload.pool || l.sourcePool;
      l.owner = '';
      l.protectUntil = '';
      l.status = l.status === '跟进中' ? '待处理' : l.status;
    }
    if (action === 'recycle') {
      l.currentPool = payload.pool || l.sourcePool;
      l.owner = '';
      l.protectUntil = '';
      l.status = l.status === '跟进中' ? '待处理' : l.status;
    }
    if (action === 'nurture') {
      l.status = '待培育';
      l.cultivateReason = payload.reason;
      l.cultivateReview = payload.review;
      l.cultivateMethod = payload.method || '';
      l.protectUntil = '';
    }
    if (action === 'nurtureReview') {
      l.status = '跟进中';
      l.cultivateReview = addDays(today(), paramDays('LEAD_NURTURE_REVIEW', 30));
      l.lastFollowUpAt = now();
    }
    if (action === 'invalid') {
      l.status = '无效';
      l.invalidReason = payload.reason;
      l.invalidNote = payload.note || '';
      l.owner = '';
      l.currentPool = '';
      l.protectUntil = '';
    }
    if (action === 'correctInvalid') {
      l.status = l.statusBeforeInvalid || '跟进中';
      l.owner = l.ownerBeforeInvalid || currentUser().id;
      l.protectUntil = l.protectUntilBeforeInvalid || '';
      l.currentPool = l.poolBeforeInvalid || '';
      l.correctNote = payload.reason;
      l.correctedBy = currentUser().id;
      l.correctedAt = now();
      l.invalidReason = '';
    }
    l.updatedAt = now();
    audit('线索', id, '线索动作·' + action, '—', payload.note || action);
    save();
    return { ok: true, lead: l };
  }

  function paramDays(key, dft) {
    var params = all('params') || [];
    for (var i = 0; i < params.length; i++) if (params[i].key === key) return params[i].value;
    return dft;
  }

  function convertLead(id, payload) {
    load();
    var l = lead(id);
    if (!l) return { ok: false, reason: '线索不存在。' };
    if (l.status === '已转化') return { ok: false, reason: '该线索已转化，不允许重复转换。' };
    if (l.status === '无效') return { ok: false, reason: '无效线索需先由主管或有权限人员纠错后才能转换。' };

    var result = { customer: null, contact: null, opportunities: [], created: [] };

    if (payload.customerMode === 'create') {
      var initial = createCustomerWithInitialRelation({
        name: payload.customer.name, type: payload.customer.type,
        creditCode: payload.customer.creditCode || '', alias: payload.customer.alias || '',
        source: '线索转换', remark: '由线索 ' + id + ' 转换创建'
      }, {
        region: payload.customer.region, businessLine: payload.customer.businessLine,
        owner: payload.customer.owner || currentUser().id
      }, 'lead-convert:' + id);
      if (!initial.ok) return initial;
      result.customer = initial.customer;
      result.relation = initial.relation;
      result.created.push({ type: '客户', id: result.customer.id, name: result.customer.name });
      result.created.push({ type: '经营关系', id: result.relation.id, name: regionName(result.relation.region) + '｜' + businessLineName(result.relation.businessLine) });
    } else if (payload.customerMode === 'link') {
      result.customer = customer(payload.customerId);
    }

    // 转换同时维护「客户＋区域＋业务线」经营关系：同组合已存在则沿用/承接，否则新建一条有效关系。
    if (payload.customerMode !== 'create' && result.customer && payload.customer && payload.customer.region && payload.customer.businessLine) {
      var rels = all('businessRelations').filter(function (r) {
        return r.customerId === result.customer.id && r.region === payload.customer.region && r.businessLine === payload.customer.businessLine;
      });
      if (!rels.length) {
        var rel = {
          id: nextId('CBL'), customerId: result.customer.id, customerName: result.customer.name,
          region: payload.customer.region, businessLine: payload.customer.businessLine, status: '有效',
          owner: currentUser().id, collaborators: [], poolRecordId: '', protectUntil: '',
          lastActivityAt: today(), createdAt: today()
        };
        db.businessRelations.unshift(rel);
        result.relation = rel;
        result.created.push({ type: '经营关系', id: rel.id, name: regionName(rel.region) + '｜' + businessLineName(rel.businessLine) });
        audit('经营关系', rel.id, '转换创建经营关系', '—', result.customer.name + '｜' + regionName(rel.region) + '｜' + businessLineName(rel.businessLine));
      } else {
        result.relation = rels[0];
        if (rels[0].status === '有效' && !rels[0].owner) {
          audit('经营关系', rels[0].id, '转换承接经营关系', '无负责人', currentUser().id);
          rels[0].owner = currentUser().id;
          rels[0].poolRecordId = '';
          rels[0].lastActivityAt = today();
        }
      }
    }

    if (payload.contactMode === 'create' && payload.contact && payload.contact.name) {
      result.contact = createContact({
        name: payload.contact.name, phonePlain: payload.contact.phone || '',
        title: payload.contact.title || '', org: result.customer ? result.customer.name : ''
      });
      if (result.customer) addContactRelation(result.contact.id, result.customer.id, payload.contact.roles || ['其他'], payload.contact.dept, payload.contact.title, true);
      result.created.push({ type: '联系人', id: result.contact.id, name: result.contact.name });
    } else if (payload.contactMode === 'link' && payload.contactId) {
      result.contact = contact(payload.contactId);
      if (result.contact && result.customer) addContactRelation(result.contact.id, result.customer.id, payload.contactRoles || ['其他'], payload.contactDept, payload.contact.title, false);
    }

    (payload.opportunities || []).forEach(function (o) {
      var opp = createOpportunity({
        name: o.name, customerId: result.customer ? result.customer.id : '',
        businessLine: o.businessLine, scene: o.scene, predictedClose: o.predictedClose || '',
        scope: o.scope || '', source: '线索转换', sourceLead: id
      });
      if (opp.ok) {
        result.opportunities.push(opp.opportunity);
        result.created.push({ type: '商机', id: opp.opportunity.id, name: opp.opportunity.name });
      }
    });

    l.status = '已转化';
    l.convertAt = now();
    l.convertBy = currentUser().id;
    l.convertTargets = result.created.map(function (x) { return x.id; });
    if (result.customer) l.customerId = result.customer.id;
    if (result.contact) l.contactId = result.contact.id;
    l.currentPool = '';
    l.owner = currentUser().id;
    audit('线索', id, '整条转换', payload.fromStatus || '跟进中', '已转化');
    save();
    return { ok: true, result: result, lead: l };
  }

  /* ----------------------------------------------------------------- 商机 */

  function createOpportunity(input) {
    load();
    var m = matchTemplate(input.businessLine, input.scene);
    if (m.state !== 'ok') return { ok: false, match: m, reason: matchReason(m, input) };
    if (!input.customerId || !customer(input.customerId)) {
      return { ok: false, match: m, reason: '正式商机必须关联有效客户。' };
    }
    if (!input.name) return { ok: false, match: m, reason: '商机名称必填。' };
    var id = nextId('OPP');
    var tpl = m.template;
    var o = {
      id: id, name: input.name, customerId: input.customerId, owner: currentUser().id,
      processStatus: '进行中', templateCode: tpl.code, templateVersion: tpl.version,
      currentStageCode: tpl.stages[0].code, predictedClose: input.predictedClose || '',
      nextAction: '', nextActionAt: '',
      lines: [{ code: nextId('OBL'), businessLine: input.businessLine, role: '主业务线', scene: input.scene, scope: input.scope || '', status: '当前参与' }],
      team: [{ userId: currentUser().id, role: '主负责人' }],
      custom: {}, stageHistory: [{ from: '', to: tpl.stages[0].code, at: now(), by: currentUser().id, note: '创建商机，自动进入首个详细阶段' }],
      stageEnteredAt: now(), source: input.source || '直接创建', sourceLead: input.sourceLead || '',
      closeResult: '', closeBasis: '', closeReason: '', closeNote: '', closedAt: '', closedBy: '',
      createdAt: now(), updatedAt: now()
    };
    db.opportunities.unshift(o);
    generateStageTasks(o, tpl.stages[0]);
    var c = customer(input.customerId);
    if (c) c.oppsCount = all('opportunities').filter(function (x) { return x.customerId === input.customerId; }).length;
    audit('商机', id, '新建商机', '—', o.name + '｜模板 ' + tpl.name + ' ' + tpl.version);
    save();
    return { ok: true, opportunity: o, match: m };
  }

  function matchReason(m, input) {
    var line = businessLineName(input.businessLine);
    if (m.state === 'missing') return '未找到「' + line + ' ＋ ' + input.scene + '」对应的生效流程模板，商机无法创建。请确认主业务线与销售场景，或联系销售运营补齐模板配置。';
    if (m.state === 'multi') return '「' + line + ' ＋ ' + input.scene + '」匹配到多条生效模板，无法唯一确定使用哪一条，商机无法创建。';
    if (m.state === 'service-error') return '流程模板校验服务暂时不可用，商机无法创建。已保留当前页面填写内容，可稍后重试。';
    return '商机创建失败。';
  }

  function currentTemplate(o) {
    var t = template(o.templateCode, o.templateVersion);
    return t;
  }

  function currentStage(o) {
    var t = currentTemplate(o);
    if (!t) return null;
    for (var i = 0; i < t.stages.length; i++) if (t.stages[i].code === o.currentStageCode) return t.stages[i];
    return null;
  }

  function stageIndex(o) {
    var t = currentTemplate(o);
    if (!t) return -1;
    for (var i = 0; i < t.stages.length; i++) if (t.stages[i].code === o.currentStageCode) return i;
    return -1;
  }

  function generateStageTasks(o, stage) {
    if (!stage || !stage.tasks || !stage.tasks.length) return [];
    var created = [];
    stage.tasks.forEach(function (tk) {
      var dup = all('stageTasks').some(function (x) {
        return x.oppId === o.id && x.stageCode === stage.code && x.title === tk.title && x.status !== '已失效';
      });
      if (dup) return;
      var id = nextId('TSK');
      db.stageTasks.unshift({
        id: id, oppId: o.id, templateVersion: o.templateCode + '-' + o.templateVersion,
        stageCode: stage.code, title: tk.title, desc: tk.desc, must: !!tk.must,
        due: addDays(today(), tk.dueDays || 7) + ' 23:59', status: '进行中', owner: o.owner,
        generatedBy: '阶段进入事件 ' + stage.code + ' / ' + now(), enteredAt: now(), assigneeChanged: false
      });
      created.push(id);
    });
    return created;
  }

  /** 门槛校验：预计成交时间系统固定门槛 + 模板必填字段 + 必须完成的阶段任务 */
  function gateCheck(o, direction) {
    var t = currentTemplate(o);
    var stage = currentStage(o);
    var problems = [];
    if (!t || !stage) return { pass: false, problems: [{ kind: 'template', text: '当前商机未匹配到有效模板版本。' }] };

    if (direction === 'forward') {
      if (stage.unified === '机会确认' && !o.predictedClose) {
        problems.push({ kind: 'system', text: '预计成交时间：离开「机会确认」前必须填写（系统固定门槛，不可由模板或角色关闭）。' });
      }
      (stage.requiredFields || []).forEach(function (cf) {
        if (!o.custom || !o.custom[cf]) {
          var f = customField(cf);
          problems.push({ kind: 'field', code: cf, text: '必填字段未填写：' + (f ? f.name : cf) });
        }
      });
      all('stageTasks').filter(function (x) {
        return x.oppId === o.id && x.stageCode === stage.code && x.must && x.status !== '已完成' && x.status !== '已失效';
      }).forEach(function (x) {
        problems.push({ kind: 'task', id: x.id, text: '必须完成的阶段任务未完成：' + x.title });
      });
      if (o.processStatus === '休眠') problems.push({ kind: 'dormant', text: '商机处于休眠状态，不能推进阶段。请先恢复。' });
      if (o.closeResult) problems.push({ kind: 'closed', text: '商机已关闭（' + o.closeResult + '），关闭后不再推进阶段。如需继续跟进，必须先重开并填写原因。' });
    }
    return { pass: problems.length === 0, problems: problems };
  }

  function advanceStage(o, note, force) {
    load();
    var t = currentTemplate(o);
    var idx = stageIndex(o);
    if (!t || idx < 0) return { ok: false, reason: '当前阶段不存在。' };
    if (idx >= t.stages.length - 1) return { ok: false, reason: '已处于最后阶段，无后续阶段可推进。' };
    if (o.processStatus === '休眠') return { ok: false, reason: '休眠商机不允许推进阶段。' };
    if (o.closeResult) return { ok: false, reason: '商机已关闭（' + o.closeResult + '），需先重开后再推进阶段。' };
    var g = gateCheck(o, 'forward');
    if (!g.pass && !force) return { ok: false, gate: g, reason: '阶段门槛未通过，不能推进。' };
    var next = t.stages[idx + 1];
    o.stageHistory.push({ from: o.currentStageCode, to: next.code, at: now(), by: currentUser().id, note: note || '' });
    o.currentStageCode = next.code;
    o.stageEnteredAt = now();
    o.updatedAt = now();
    generateStageTasks(o, next);
    audit('商机', o.id, '阶段推进', t.stages[idx].name, next.name);
    save();
    return { ok: true, stage: next };
  }

  function rollbackStage(o, targetCode, note) {
    load();
    var t = currentTemplate(o);
    var idx = stageIndex(o);
    var target = -1;
    for (var i = 0; i < t.stages.length; i++) if (t.stages[i].code === targetCode) target = i;
    if (target < 0) return { ok: false, reason: '目标阶段不存在。' };
    if (target >= idx) return { ok: false, reason: '只能回退到历史阶段（当前阶段之前的阶段）。' };
    if (o.processStatus === '休眠') return { ok: false, reason: '休眠商机不允许回退阶段。' };
    if (o.closeResult) return { ok: false, reason: '商机已关闭（' + o.closeResult + '），需先重开后再回退阶段。' };
    o.stageHistory.push({ from: o.currentStageCode, to: targetCode, at: now(), by: currentUser().id, note: note || '历史回退' });
    o.currentStageCode = targetCode;
    o.stageEnteredAt = now();
    o.updatedAt = now();
    audit('商机', o.id, '阶段回退', t.stages[idx].name, t.stages[target].name);
    save();
    return { ok: true, stage: t.stages[target] };
  }

  function changeMainLine(o, newLine, newScene, note) {
    load();
    var m = matchTemplate(newLine, newScene);
    if (m.state !== 'ok') return { ok: false, match: m, reason: matchReason(m, { businessLine: newLine, scene: newScene }) };
    var t = currentTemplate(o);
    var idx = stageIndex(o);
    var nextTpl = m.template;
    var targetIdx = Math.min(idx, nextTpl.stages.length - 1);
    var target = nextTpl.stages[targetIdx];
    var main = o.lines.filter(function (l) { return l.role === '主业务线'; })[0];
    var oldTplName = t ? t.name + ' ' + t.version : '—';
    if (main) main.businessLine = newLine;
    if (main) main.scene = newScene;
    o.templateCode = nextTpl.code;
    o.templateVersion = nextTpl.version;
    o.currentStageCode = target.code;
    o.stageEnteredAt = now();
    o.stageHistory.push({ from: '', to: target.code, at: now(), by: currentUser().id, note: '主业务线变更导致模板迁移：' + oldTplName + ' → ' + nextTpl.name + ' ' + nextTpl.version + '；' + (note || '') });
    // 上下文变化使原阶段任务失效（不取消）
    all('stageTasks').forEach(function (x) {
      if (x.oppId === o.id && (x.status === '进行中' || x.status === '待开始')) x.status = '已失效';
    });
    generateStageTasks(o, target);
    o.updatedAt = now();
    audit('商机', o.id, '模板迁移', oldTplName, nextTpl.name + ' ' + nextTpl.version);
    save();
    return { ok: true, template: nextTpl, stage: target };
  }

  function sleepOpp(o, reason, reviewAt) {
    o.processStatus = '休眠';
    o.sleepReason = reason;
    o.sleepReviewAt = reviewAt;
    o.sleepAt = now();
    o.sleepBy = currentUser().id;
    o.stageHistory.push({ from: o.currentStageCode, to: o.currentStageCode, at: now(), by: currentUser().id, note: '休眠：' + reason });
    save();
    return o;
  }

  function resumeOpp(o, note) {
    o.processStatus = '进行中';
    o.stageHistory.push({ from: o.currentStageCode, to: o.currentStageCode, at: now(), by: currentUser().id, note: '恢复：' + (note || '') });
    save();
    return o;
  }

  function closeOpp(o, result, payload) {
    o.closeResult = result;
    o.closeBasis = payload && payload.basis || '';
    o.closeReason = payload && payload.reason || '';
    o.closeNote = payload && payload.note || '';
    o.closedAt = now();
    o.closedBy = currentUser().id;
    o.processStatus = '已关闭';
    audit('商机', o.id, '关闭商机', '进行中', result);
    save();
    return o;
  }

  function reopenOpp(o, reason) {
    o.processStatus = '进行中';
    o.closeResult = '';
    o.closedAt = '';
    o.closedBy = '';
    o.closeReason = '';
    o.closeNote = '';
    o.closeBasis = '';
    o.reopenReason = reason;
    o.reopenAt = now();
    o.reopenBy = currentUser().id;
    o.stageHistory.push({ from: o.currentStageCode, to: o.currentStageCode, at: now(), by: currentUser().id, note: '重开：' + reason });
    audit('商机', o.id, '重开商机', '已关闭', '进行中');
    save();
    return o;
  }

  function splitLine(o, lineCode, payload) {
    load();
    var line = o.lines.filter(function (l) { return l.code === lineCode; })[0];
    if (!line) return { ok: false, reason: '协同业务线不存在。' };
    if (line.role === '主业务线') return { ok: false, reason: '主业务线不能拆分为新商机。' };
    var res = createOpportunity({
      name: payload.name, customerId: o.customerId, businessLine: line.businessLine,
      scene: payload.scene, predictedClose: payload.predictedClose || '', scope: line.scope,
      source: '由商机 ' + o.id + ' 拆分协同业务线'
    });
    if (!res.ok) return res;
    line.status = '已拆分为新商机';
    line.splitTo = res.opportunity.id;
    res.opportunity.stageHistory[0].note = '由商机 ' + o.id + ' 拆分协同业务线创建';
    audit('商机', o.id, '拆分协同业务线', line.businessLine, res.opportunity.id);
    save();
    return res;
  }

  function addTeamMember(o, userId, roleName) {
    load();
    if (o.team.some(function (m) { return m.userId === userId; })) return { ok: false, reason: '该成员已在商机团队中。' };
    o.team.push({ userId: userId, role: roleName });
    o.updatedAt = now();
    audit('商机', o.id, '新增团队成员', '—', userName(userId) + '／' + roleName);
    save();
    return { ok: true };
  }

  function removeTeamMember(o, userId) {
    load();
    var m = o.team.filter(function (x) { return x.userId === userId; })[0];
    if (!m) return { ok: false, reason: '该成员不在商机团队中。' };
    if (m.role === '主负责人') return { ok: false, reason: '主负责人不能被移除，请先转派主负责人。' };
    o.team = o.team.filter(function (x) { return x.userId !== userId; });
    o.updatedAt = now();
    audit('商机', o.id, '移除团队成员', userName(userId), '—');
    save();
    return { ok: true };
  }

  function reassignOwner(o, userId, reason) {
    load();
    var before = o.owner;
    o.owner = userId;
    o.team = o.team.map(function (m) {
      if (m.userId === before && m.role === '主负责人') m.role = '协同销售';
      return m;
    });
    if (!o.team.some(function (m) { return m.userId === userId; })) o.team.push({ userId: userId, role: '主负责人' });
    else o.team = o.team.map(function (m) { if (m.userId === userId) m.role = '主负责人'; return m; });
    o.updatedAt = now();
    audit('商机', o.id, '转派主负责人', userName(before), userName(userId) + '（原因：' + (reason || '—') + '）');
    save();
    return o;
  }

  function updateStageTask(taskId, patch) {
    load();
    var t = find('stageTasks', taskId);
    if (!t) return null;
    Object.keys(patch).forEach(function (k) { t[k] = patch[k]; });
    audit('阶段任务', taskId, '更新阶段任务', '—', Object.keys(patch).join('、'));
    save();
    return t;
  }

  /* -------------------------------------------------- 处理记录 / 批量 / 导入导出 */

  function addJob(job) {
    load();
    var id = job.id || nextId('JOB');
    var j = {
      id: id, type: job.type, action: job.action, object: job.object, status: job.status || '处理中',
      submittedAt: now(), operator: currentUser().id, total: job.total || 0, success: job.success || 0,
      failed: job.failed || 0, expiresAt: addDays(today(), 7) + ' ' + now().slice(11),
      processId: job.processId || ('JOB-' + month() + '-' + id.slice(-4)),
      items: job.items || [], fileName: job.fileName || '', fields: job.fields || [], sourceFile: job.sourceFile || '',
      retryOf: job.retryOf || ''
    };
    db.jobs.unshift(j);
    audit('处理记录', id, j.action, '—', j.status + '｜总数 ' + j.total + '，成功 ' + j.success + '，失败 ' + j.failed);
    save();
    return j;
  }

  function updateJob(id, patch) {
    load();
    var j = find('jobs', id);
    if (!j) return null;
    Object.keys(patch).forEach(function (k) { j[k] = patch[k]; });
    save();
    return j;
  }

  function retryFailed(jobId) {
    load();
    var j = find('jobs', jobId);
    if (!j) return null;
    var items = (j.items || []).filter(function (x) { return x.result === '失败'; });
    var nj = addJob({
      type: j.type, action: j.action + '（只重试失败项）', object: j.object, status: '部分成功',
      total: items.length, success: Math.max(0, items.length - 1), failed: Math.min(1, items.length),
      retryOf: j.id,
      items: items.map(function (x, i) {
        return { key: x.key, name: x.name, result: i === items.length - 1 && items.length > 1 ? '失败' : '成功', reason: i === items.length - 1 && items.length > 1 ? x.reason : '' };
      })
    });
    return nj;
  }

  function markMessageRead(id, read) {
    load();
    var m = find('messages', id);
    if (m) { m.read = read === undefined ? true : read; save(); }
    return m;
  }

  function markAllMessagesRead() {
    load();
    db.messages.forEach(function (m) { m.read = true; });
    save();
  }

  function audit(objectType, objectId, action, from, to) {
    load();
    db.audits.unshift({
      id: 'AUD-' + (1000 + db.audits.length), at: now(), actor: currentUser().name, source: 'PC（原型）',
      objectType: objectType, objectId: objectId, action: action, result: '成功', from: from, to: to
    });
  }

  /* --------------------------------------------------- 列表作用域与选中态 */

  function listState(key, patch) {
    load();
    if (!db.runtime.listState[key]) db.runtime.listState[key] = { page: 1, size: 10, filters: {}, sort: null, columns: null, scope: null, keyword: '' };
    if (patch) { Object.keys(patch).forEach(function (k) { db.runtime.listState[key][k] = patch[k]; }); save(); }
    return db.runtime.listState[key];
  }

  function selection(key, ids) {
    load();
    if (ids !== undefined) { db.runtime.selection[key] = ids; save(); }
    return db.runtime.selection[key] || [];
  }

  function uiState(key, patch) {
    load();
    if (!db.runtime.uiState[key]) db.runtime.uiState[key] = {};
    if (patch) { Object.keys(patch).forEach(function (k) { db.runtime.uiState[key][k] = patch[k]; }); save(); }
    return db.runtime.uiState[key];
  }

  /* ==========================================================================
     以下为 0.1 全量原型新增域：任务、销售活动、正式拜访、统一日程、日报、
     Agent 候选、知识、消息投递、集成与同步、异常事项、数据质量、指标、
     业务配置、人员权限与移交。
     所有函数只读写「已确认正式规则」允许的字段与状态，不在前端创造新规则；
     演示态（身份切换、注入失败）都记为原型演示手段，不是生产行为。
     ========================================================================== */

  function arr(list) { load(); return db[list] || []; }
  function stamp() { return now(); }
  function hist(o, actor, action, from, to, note) {
    if (!o.history) o.history = [];
    o.history.push({ at: stamp(), actor: actor, action: action, from: from, to: to, note: note || '' });
  }
  function me() { return currentUser(); }
  function isTeamScope(scope) { return scope === 'team'; }
  function inTeamOf(ownerId, leaderId) {
    if (!leaderId) return false;
    var u = user(ownerId);
    if (!u) return false;
    var lead = user(leaderId);
    if (!lead) return false;
    /* 演示口径：主管的团队＝同一部门内除本人外的成员，或区域资格被主管覆盖的成员。 */
    return u.dept === lead.dept || (u.region || []).some(function (r) { return (lead.region || []).indexOf(r) >= 0; });
  }

  /* ============================================================ 任务（04 §2） */

  /* 逾期是依据有效截止时间派生的时间标识，不是状态；任务不建「延期中」状态。 */
  function taskOverdue(t) {
    if (!t || !t.dueAt) return false;
    if (t.status === '已完成' || t.status === '已取消' || t.status === '已失效' || t.status === '已拒绝') return false;
    return t.dueAt.replace(/-/g, '/') < now().replace(/-/g, '/');
  }
  function taskDaysLeft(t) {
    if (!t || !t.dueAt) return null;
    var a = new Date(t.dueAt.replace(/-/g, '/')), b = new Date(now().replace(/-/g, '/'));
    return Math.round((a - b) / 86400000);
  }
  function taskRemindWindow() { return 3; }
  function taskSoon(t) {
    var d = taskDaysLeft(t);
    return d !== null && d >= 0 && d <= taskRemindWindow() && ['待接收', '进行中', '待验收'].indexOf(t.status) >= 0;
  }
  function tasks(scope) {
    var list = arr('tasks');
    if (!scope || scope === 'all') return list;
    var u = me();
    if (scope === 'mine') return list.filter(function (t) { return t.owner === u.id || (t.collaborators || []).indexOf(u.id) >= 0; });
    return list.filter(function (t) { return t.owner === u.id || inTeamOf(t.owner, u.id); });
  }
  function task(id) { return find('tasks', id); }

  /* 验收人解析优先级（04 §2）：①规则／创建时显式指定 ②主管指派默认为指派人
     ③自建／沟通提炼／普通规则生成默认为责任人唯一主直属主管 ④阶段任务默认为商机负责人直属主管。 */
  function taskAcceptor(ownerId) {
    var u = user(ownerId);
    if (!u) return { acceptor: '', rule: '责任人不存在，无法解析验收人' };
    var leaders = db.users.filter(function (x) { return x.role === 'R2' && inTeamOf(ownerId, x.id); });
    if (leaders.length === 1) return { acceptor: leaders[0].id, rule: '责任人唯一主直属主管：' + leaders[0].name };
    if (leaders.length === 0) return { acceptor: '', rule: '责任人的唯一主直属主管未配置，验收入无法唯一解析' };
    return { acceptor: '', rule: '责任人的主直属主管不唯一，验收入无法唯一解析' };
  }

  function createTask(p) {
    load();
    var id = nextId('TSK');
    var a = p.needAccept ? taskAcceptor(p.owner) : { acceptor: '', rule: '无需验收' };
    var t = {
      id: id, name: p.name, source: p.source || '自建任务', bizType: p.bizType || '客户跟进',
      owner: p.owner, collaborators: p.collaborators || [], needAccept: !!p.needAccept,
      acceptor: p.acceptor || a.acceptor, acceptorRule: a.rule,
      status: (p.source === '主管指派') ? '待接收' : '进行中',
      dueAt: p.dueAt || '', doneAt: '', related: p.related || { type: '', id: '', name: '' },
      flowSnapshot: { needAccept: !!p.needAccept, acceptor: p.acceptor || a.acceptor, ruleCode: 'TR-MANUAL-V1', ruleVersion: 'V1', frozenAt: stamp() },
      stageTask: false, ruleVersion: '', createdAt: stamp(), createdBy: me().id, history: []
    };
    hist(t, me().name, t.source + '创建', '', t.status);
    db.tasks.unshift(t);
    audit('任务', id, '创建任务', '—', t.name + '｜' + t.status);
    save();
    return t;
  }

  /* 任务动作：接收／完成／提交验收／验收通过／验收退回／延期／取消／失效。
     完成≠自动推进阶段；阶段推进必须由商机详情上的正式动作发起。 */
  function taskAct(id, action, p) {
    load();
    var t = find('tasks', id); if (!t) return { ok: false, msg: '任务不存在' };
    p = p || {};
    var u = me(), before = t.status;
    if (action === '接收') {
      if (t.status !== '待接收') return { ok: false, msg: '仅待接收状态可以接收' };
      t.status = '进行中';
    } else if (action === '完成') {
      if (['进行中', '待接收'].indexOf(t.status) < 0) return { ok: false, msg: '当前状态不可完成任务' };
      if (t.needAccept) { t.status = '待验收'; } else { t.status = '已完成'; }
      t.doneAt = stamp(); t.result = p.result || '';
    } else if (action === '提交验收') {
      if (t.status !== '进行中') return { ok: false, msg: '仅进行中状态可以提交验收' };
      t.status = '待验收'; t.doneAt = stamp(); t.result = p.result || '';
    } else if (action === '验收通过') {
      if (t.status !== '待验收') return { ok: false, msg: '仅待验收状态可以验收' };
      /* 验收人解析不出来时不允许验收，避免绕过「唯一主直属主管」约束。 */
      if (!t.acceptor) return { ok: false, msg: '验收入无法唯一解析，不能验收' };
      if (t.acceptor !== u.id && u.role !== 'R5') return { ok: false, msg: '当前用户不是该任务的验收人' };
      t.status = '已完成'; t.acceptedAt = stamp(); t.acceptedBy = u.id;
    } else if (action === '验收退回') {
      if (t.status !== '待验收') return { ok: false, msg: '仅待验收状态可以退回' };
      if (t.acceptor !== u.id && u.role !== 'R5') return { ok: false, msg: '当前用户不是该任务的验收人' };
      if (!p.reason) return { ok: false, msg: '退回必须填写原因' };
      t.status = '进行中'; t.rejectReason = p.reason; t.rejectedAt = stamp();
    } else if (action === '延期') {
      if (['已完成', '已取消', '已失效', '已拒绝'].indexOf(t.status) >= 0) return { ok: false, msg: '终态任务不能延期' };
      if (!p.dueAt) return { ok: false, msg: '延期必须填写新的截止时间' };
      t.originalDueAt = t.originalDueAt || t.dueAt; t.dueAt = p.dueAt; t.extendedAt = stamp(); t.extendReason = p.reason || '';
    } else if (action === '取消') {
      if (['已完成', '已取消', '已失效'].indexOf(t.status) >= 0) return { ok: false, msg: '当前状态不可取消' };
      t.status = '已取消'; t.cancelReason = p.reason || '';
    } else if (action === '失效') {
      /* 「已失效」只由上下文变化（阶段回退、模板迁移等）产生，禁止人工把必做阶段任务置为已失效。 */
      if (t.stageTask) return { ok: false, msg: '阶段任务不能人工置为已失效，只能在流程上下文变化时由系统处理' };
      t.status = '已失效'; t.invalidReason = p.reason || '';
    } else if (action === '拒绝指派') {
      if (t.source !== '主管指派') return { ok: false, msg: '仅正式指派任务可以拒绝' };
      if (t.status !== '待接收') return { ok: false, msg: '仅待接收状态可以拒绝' };
      if (!p.reason) return { ok: false, msg: '拒绝必须填写原因' };
      t.status = '已拒绝'; t.rejectReason = p.reason;
    } else { return { ok: false, msg: '未知动作' }; }
    hist(t, u.name, action, before, t.status, p.reason || '');
    audit('任务', id, action, before, t.status);
    save();
    return { ok: true, task: t, msg: '已完成「' + action + '」' };
  }

  /* 批量验收通过：逐条重检，允许部分成功，已成功项不重复。 */
  function batchTaskAccept(ids) {
    load();
    var results = [];
    ids.forEach(function (id) {
      var t = find('tasks', id);
      if (!t) { results.push({ id: id, ok: false, msg: '任务不存在或已不可用' }); return; }
      if (t.status !== '待验收') { results.push({ id: id, ok: false, msg: '当前状态不是待验收，跳过' }); return; }
      if (!t.acceptor) { results.push({ id: id, ok: false, msg: '验收入无法唯一解析' }); return; }
      var r = taskAct(id, '验收通过', {});
      results.push({ id: id, ok: r.ok, msg: r.ok ? '验收通过' : r.msg });
    });
    return results;
  }

  /* ==================================================== 销售活动（04 §3） */

  /* 销售活动必须至少关联一个有效业务对象，否则不能保存；销售活动不改写正式事实。 */
  function activityList(scope) {
    var list = arr('activities');
    if (!scope || scope === 'all') return list;
    var u = me();
    if (scope === 'mine') return list.filter(function (a) { return a.owner === u.id; });
    return list.filter(function (a) { return a.owner === u.id || inTeamOf(a.owner, u.id); });
  }
  function activity(id) { return find('activities', id); }
  function createActivity(p) {
    load();
    var links = (p.related || []).filter(function (r) { return r && r.id; });
    if (!links.length) return { ok: false, msg: '销售活动至少关联一个有效业务对象' };
    var id = nextId('ACT');
    var a = {
      id: id, channel: p.channel, at: p.at || stamp(), owner: p.owner || me().id,
      target: p.target || '', content: p.content || '', request: p.request || '',
      agreement: p.agreement || '', nextAction: p.nextAction || '',
      related: links, origin: p.origin || '手工录入',
      aiResult: p.aiResult || null, evidence: p.evidence || [],
      corrections: [], createdAt: stamp(), createdBy: me().id, history: []
    };
    hist(a, me().name, '创建销售活动', '', a.channel);
    db.activities.unshift(a);
    audit('销售活动', id, '创建', '—', a.channel + '｜' + a.target);
    save();
    return { ok: true, activity: a };
  }
  function correctActivity(id, p) {
    load();
    var a = find('activities', id); if (!a) return { ok: false, msg: '销售活动不存在' };
    var before = { channel: a.channel, content: a.content, nextAction: a.nextAction };
    a.corrections.push({ at: stamp(), by: me().id, reason: p.reason, before: JSON.parse(JSON.stringify(before)) });
    if (p.channel) a.channel = p.channel;
    if (typeof p.content === 'string') a.content = p.content;
    if (typeof p.nextAction === 'string') a.nextAction = p.nextAction;
    if (typeof p.target === 'string') a.target = p.target;
    a.correctedAt = stamp(); a.correctedBy = me().id;
    hist(a, me().name, '纠错', '', '', p.reason);
    audit('销售活动', id, '纠错', before.channel, a.channel + '｜原因：' + p.reason);
    save();
    return { ok: true, activity: a };
  }

  /* ==================================================== 正式拜访（04 §4） */

  function visitList(scope) {
    var list = arr('visits');
    if (!scope || scope === 'all') return list;
    var u = me();
    if (scope === 'mine') return list.filter(function (v) { return v.owner === u.id; });
    return list.filter(function (v) { return v.owner === u.id || inTeamOf(v.owner, u.id); });
  }
  function visit(id) { return find('visits', id); }
  function createVisit(p) {
    load();
    var id = nextId('VH');
    var c = customer(p.customerId);
    var v = {
      id: id, customerId: p.customerId, storeId: p.storeId || '', owner: p.owner || me().id,
      type: p.type || '实地拜访', status: '计划中', exception: '', reviewStatus: '', checkInIssue: '',
      planAt: p.planAt, planSnapshotAt: '', addressSnapshot: p.addressSnapshot || { region: c ? c.region : '', detail: '' },
      checkInAt: '', checkInLoc: null, checkOutAt: '', checkOutLoc: null,
      summary: null, nextStep: '', evidence: [], exceptionDetail: '',
      review: { by: '', at: '', result: '', reason: '', ruleVersion: 'VR-V1' },
      note: '', createdAt: stamp(), createdBy: me().id, history: []
    };
    hist(v, me().name, '创建正式拜访', '', '计划中');
    db.visits.unshift(v);
    audit('正式拜访', id, '创建', '—', (c ? c.name : p.customerId) + '｜' + v.planAt);
    save();
    return v;
  }
  /* 签到：定位成功进入进行中并冻结计划快照；定位失败允许填写原因后继续进行，不采集连续轨迹。 */
  function visitCheckIn(id, opts) {
    load();
    var v = find('visits', id); if (!v) return { ok: false, msg: '拜访不存在' };
    opts = opts || {};
    if (v.status !== '计划中') return { ok: false, msg: '仅计划中状态可以签到' };
    v.planSnapshotAt = stamp();
    if (opts.ok === false) {
      if (!opts.reason) return { ok: false, msg: '定位失败必须填写原因后才能继续' };
      v.exception = '待复核'; v.reviewStatus = '待复核'; v.checkInIssue = '定位失败';
      v.exceptionDetail = opts.detail || '定位失败，销售填写原因后继续进行';
      v.exceptionReason = opts.reason; v.exceptionNoteBy = me().id; v.exceptionNoteAt = stamp();
      v.status = '进行中';
      hist(v, me().name, '定位失败填写原因继续', '计划中', '进行中', opts.reason);
      audit('正式拜访', id, '异常签到', '计划中', '进行中｜原因：' + opts.reason);
      save();
      return { ok: true, visit: v, msg: '已记录异常签到并继续拜访' };
    }
    v.checkInAt = stamp();
    v.checkInLoc = opts.loc || { lat: 0, lng: 0, addr: '（演示定位）', acc: 20 };
    v.status = '进行中';
    var rule = arr('visitRules')[0];
    if (v.checkInLoc.acc > rule.accuracy) {
      v.exception = '待复核'; v.reviewStatus = '待复核'; v.checkInIssue = '定位精度不足';
      v.exceptionDetail = '签到定位精度 ' + v.checkInLoc.acc + ' 米，超过规则阈值 ' + rule.accuracy + ' 米';
    }
    hist(v, me().name, '签到并冻结计划快照', '计划中', '进行中');
    audit('正式拜访', id, '签到', '计划中', '进行中');
    save();
    return { ok: true, visit: v, msg: '签到成功' };
  }
  /* 完成门槛＝有效签到或已说明的异常签到 + 签退 + 拜访总结；图片不作为阻断项。 */
  function visitCheckOut(id, loc, summary) {
    load();
    var v = find('visits', id); if (!v) return { ok: false, msg: '拜访不存在' };
    if (v.status !== '进行中') return { ok: false, msg: '仅进行中状态可以签退' };
    if (!summary || !summary.nextStep) return { ok: false, msg: '拜访总结与下一步动作必须填写' };
    v.checkOutAt = stamp(); v.checkOutLoc = loc || { lat: 0, lng: 0, addr: '（演示定位）', acc: 20 };
    v.summary = summary; v.nextStep = summary.nextStep;
    v.status = '已完成';
    hist(v, me().name, '签退并提交拜访总结', '进行中', '已完成');
    audit('正式拜访', id, '签退完成', '进行中', '已完成');
    save();
    return { ok: true, visit: v, msg: '拜访已完成' };
  }
  /* 异常复核只改变异常状态，不改变拜访主状态，也不改写拜访事实。 */
  function visitReview(id, result, reason) {
    load();
    var v = find('visits', id); if (!v) return { ok: false, msg: '拜访不存在' };
    if (!v.exception) return { ok: false, msg: '该拜访没有待复核异常' };
    if (['待复核', '待补充'].indexOf(v.exception) < 0) return { ok: false, msg: '当前异常状态不可复核' };
    if (result === '待补充' && !reason) return { ok: false, msg: '要求补充必须填写原因' };
    var before = v.exception;
    v.exception = result; v.reviewStatus = result;
    v.review = { by: me().id, at: stamp(), result: result, reason: reason || '', ruleVersion: 'VR-V1' };
    hist(v, me().name, '异常复核', before, result, reason || '');
    audit('正式拜访', id, '异常复核', before, result);
    save();
    return { ok: true, visit: v };
  }
  /* 批量复核只允许同规则版本、同结论且无需销售补充的记录；逐条重检、允许部分成功。 */
  function batchVisitReview(ids, result, reason) {
    load();
    var results = [];
    ids.forEach(function (id) {
      var v = find('visits', id);
      if (!v) { results.push({ id: id, ok: false, msg: '拜访不存在' }); return; }
      if (['待复核', '待补充'].indexOf(v.exception) < 0) { results.push({ id: id, ok: false, msg: '当前异常状态不可批量复核，跳过' }); return; }
      if (v.review && v.review.ruleVersion && v.review.ruleVersion !== 'VR-V1') { results.push({ id: id, ok: false, msg: '规则版本不一致，需逐条复核' }); return; }
      if (v.exception === '待补充') { results.push({ id: id, ok: false, msg: '需要销售补充的记录不能批量复核' }); return; }
      var r = visitReview(id, result, reason);
      results.push({ id: id, ok: r.ok, msg: r.ok ? ('已复核为「' + result + '」') : r.msg });
    });
    return results;
  }

  /* ==================================================== 统一日程（04 §5） */

  function scheduleList(scope) {
    var list = arr('schedules');
    if (!scope || scope === 'all') return list;
    var u = me();
    if (scope === 'mine') return list.filter(function (s) { return s.owner === u.id; });
    return list.filter(function (s) { return s.owner === u.id || inTeamOf(s.owner, u.id); });
  }
  function sched(id) { return find('schedules', id); }
  function createSchedule(p) {
    load();
    if (!p.title || !p.startAt) return { ok: false, msg: '日程标题与开始时间必填' };
    var id = nextId('SCH');
    var s = {
      id: id, title: p.title, owner: p.owner || me().id, type: p.type || '个人安排',
      startAt: p.startAt, endAt: p.endAt || p.startAt, status: '有效',
      related: p.related || { type: '', id: '', name: '' }, note: p.note || '',
      isConverted: false, convertedTaskId: '', convertedAt: '', convertedBy: '',
      wecomSync: { status: '待同步', at: '', externalId: '', failReason: '', retryCount: 0 },
      createdAt: stamp(), createdBy: me().id, history: []
    };
    hist(s, me().name, '创建独立日程', '', '有效');
    db.schedules.unshift(s);
    audit('独立日程', id, '创建', '—', p.title);
    save();
    return { ok: true, schedule: s };
  }
  function updateSchedule(id, p) {
    load();
    var s = find('schedules', id); if (!s) return { ok: false, msg: '日程不存在' };
    if (s.status !== '有效') return { ok: false, msg: '仅有效日程可以编辑' };
    ['title', 'type', 'startAt', 'endAt', 'note', 'related'].forEach(function (k) { if (p[k] !== undefined) s[k] = p[k]; });
    s.wecomSync.status = '待同步'; s.wecomSync.failReason = '';
    hist(s, me().name, '编辑日程', '', '', '');
    audit('独立日程', id, '编辑', '', s.title);
    save();
    return { ok: true, schedule: s };
  }
  function cancelSchedule(id, reason) {
    load();
    var s = find('schedules', id); if (!s) return { ok: false, msg: '日程不存在' };
    if (s.status !== '有效') return { ok: false, msg: '仅有效日程可以取消' };
    s.status = '已取消'; s.cancelReason = reason || ''; s.wecomSync.status = '已取消';
    hist(s, me().name, '取消日程', '有效', '已取消', reason || '');
    audit('独立日程', id, '取消', '有效', '已取消');
    save();
    return { ok: true, schedule: s };
  }
  function deleteSchedule(id, reason) {
    load();
    var s = find('schedules', id); if (!s) return { ok: false, msg: '日程不存在' };
    if (s.status === '已删除') return { ok: false, msg: '日程已删除' };
    s.status = '已删除'; s.deleteReason = reason || '';
    hist(s, me().name, '删除日程', '', '已删除', reason || '');
    audit('独立日程', id, '删除', '', '已删除');
    save();
    return { ok: true, schedule: s };
  }
  /* 转任务只写派生字段，不新增「已转换」主状态。 */
  function scheduleToTask(id, p) {
    load();
    var s = find('schedules', id); if (!s) return { ok: false, msg: '日程不存在' };
    if (s.status !== '有效') return { ok: false, msg: '仅有效日程可以转为任务' };
    if (s.isConverted) return { ok: false, msg: '该日程已转为任务，请勿重复转换' };
    var r = createTask({
      name: p.name || s.title, source: '自建任务', bizType: p.bizType || '客户跟进',
      owner: s.owner, dueAt: p.dueAt || s.endAt, needAccept: !!p.needAccept,
      related: s.related && s.related.id ? { type: s.related.type, id: s.related.id, name: s.related.name } : { type: '', id: '', name: '' }
    });
    s.isConverted = true; s.convertedTaskId = r.id; s.convertedAt = stamp(); s.convertedBy = me().id;
    hist(s, me().name, '转为任务（派生字段）', '', '有效');
    save();
    return { ok: true, schedule: s, task: r };
  }

  /* 统一日历：独立日程 + 只读投影。
     首批投影白名单仅三项：线索下次跟进、商机下一步行动、商机预计成交日期。
     投影不可在日历上直接修改，点击回到源对象。企微不同步任务。 */
  function calendarEvents(monthStr) {
    load();
    var out = [];
    var m = monthStr || month();
    function inM(d) { return d && d.slice(0, 7) === m; }
    arr('schedules').forEach(function (s) {
      if (s.status !== '有效' || !inM(s.startAt)) return;
      out.push({ date: s.startAt.slice(0, 10), time: s.startAt.slice(11, 16), endTime: (s.endAt || '').slice(11, 16),
        title: s.title, kind: 'schedule', srcType: '独立日程', srcId: s.id, owner: s.owner,
        path: 'schedule/detail.html', editable: true, wecom: s.wecomSync.status });
    });
    arr('tasks').forEach(function (t) {
      if (['已完成', '已取消', '已失效', '已拒绝'].indexOf(t.status) >= 0 || !inM(t.dueAt)) return;
      out.push({ date: t.dueAt.slice(0, 10), time: t.dueAt.slice(11, 16), title: t.name, kind: 'task',
        srcType: '任务', srcId: t.id, owner: t.owner, path: 'task/detail.html', editable: false, project: false });
    });
    arr('visits').forEach(function (v) {
      if (['已取消'].indexOf(v.status) >= 0 || !inM(v.planAt)) return;
      out.push({ date: v.planAt.slice(0, 10), time: v.planAt.slice(11, 16), title: '正式拜访：' + ((customer(v.customerId) || {}).name || v.customerId),
        kind: 'visit', srcType: '正式拜访', srcId: v.id, owner: v.owner, path: 'visit/detail.html', editable: false, wecom: v.status });
    });
    arr('leads').forEach(function (l) {
      if (!l.nextFollowUp || !inM(l.nextFollowUp)) return;
      out.push({ date: l.nextFollowUp.slice(0, 10), time: l.nextFollowUp.slice(11, 16), title: '线索下次跟进：' + (l.raw || '').slice(0, 18) + '…',
        kind: 'lead', srcType: '线索', srcId: l.id, owner: l.owner, path: 'lead/detail.html', editable: false, project: true });
    });
    arr('opportunities').forEach(function (o) {
      if (o.processStatus === '已关闭') return;
      if (o.nextActionAt && inM(o.nextActionAt)) {
        out.push({ date: o.nextActionAt.slice(0, 10), time: '', title: '商机下一步行动：' + o.nextAction,
          kind: 'opp', srcType: '商机', srcId: o.id, owner: o.owner, path: 'opportunity/detail.html', editable: false, project: true, sub: 'nextAction' });
      }
      if (o.predictedClose && inM(o.predictedClose)) {
        out.push({ date: o.predictedClose.slice(0, 10), time: '', title: '商机预计成交：' + o.name,
          kind: 'opp', srcType: '商机', srcId: o.id, owner: o.owner, path: 'opportunity/detail.html', editable: false, project: true, sub: 'predictedClose' });
      }
    });
    out.sort(function (a, b) { return (a.date + a.time).localeCompare(b.date + b.time); });
    return out;
  }

  /* ==================================================== 日报（04 §6） */

  function reportList(scope) {
    var list = arr('reports');
    if (!scope || scope === 'all') return list;
    var u = me();
    if (scope === 'mine') return list.filter(function (r) { return r.userId === u.id; });
    return list.filter(function (r) { return r.userId === u.id || inTeamOf(r.userId, u.id); });
  }
  function report(id) { return find('reports', id); }
  function reportDraftOf(userId, date) {
    return arr('reports').filter(function (r) { return r.userId === userId && r.date === date; })[0] || null;
  }
  function saveReportDraft(id, body) {
    load();
    var r = find('reports', id); if (!r) return { ok: false, msg: '日报不存在' };
    if (r.status === '已提交') return { ok: false, msg: '已提交日报已冻结，不能再编辑' };
    r.draftBody = body;
    audit('日报', id, '保存草稿', '', '草稿');
    save();
    return { ok: true, report: r };
  }
  /* 一次提交：冻结正文、事实快照与来源；提交后不退回、不重提、不编辑。 */
  function submitReport(id, body) {
    load();
    var r = find('reports', id); if (!r) return { ok: false, msg: '日报不存在' };
    if (r.status === '已提交') return { ok: false, msg: '该日报已提交并冻结，不能重复提交' };
    var text = body || r.draftBody;
    if (!text) return { ok: false, msg: '日报正文不能为空' };
    r.draftBody = text; r.submittedBody = text; r.status = '已提交';
    r.submittedAt = stamp(); r.submitIdem = id + '-submit';
    r.frozenSources = JSON.parse(JSON.stringify(r.sources || []));
    hist(r, me().name, '一次提交并冻结快照', '草稿', '已提交');
    audit('日报', id, '提交', '草稿', '已提交');
    save();
    return { ok: true, report: r };
  }
  function addReportAdvice(id, text) {
    load();
    var r = find('reports', id); if (!r) return { ok: false, msg: '日报不存在' };
    if (!text) return { ok: false, msg: '建议内容不能为空' };
    r.advices = r.advices || [];
    r.advices.push({ id: 'ADV-' + (r.advices.length + 1), by: me().id, at: stamp(), text: text });
    /* 新建议不重置他人阅读状态。 */
    audit('日报', id, '追加主管建议', '', text.slice(0, 30));
    save();
    return { ok: true, report: r };
  }
  function markReportRead(id, read) {
    load();
    var r = find('reports', id); if (!r) return { ok: false, msg: '日报不存在' };
    r.readBy = r.readBy || {};
    var u = me();
    r.readBy[u.id] = { read: read !== false, at: read === false ? '' : stamp(), unreadAt: read === false ? stamp() : '' };
    save();
    return { ok: true, report: r };
  }

  /* ==================================================== Agent（05） */

  function candidateList(opts) {
    load();
    opts = opts || {};
    var list = arr('agentCandidates');
    var u = me();
    list = list.filter(function (c) { return c.owner === u.id || u.role === 'R5'; });
    if (opts.age) list = list.filter(function (c) { return c.age === opts.age; });
    if (opts.status) list = list.filter(function (c) { return c.status === opts.status; });
    if (opts.writeFail) list = list.filter(function (c) { return c.writeStatus === '写入失败'; });
    return list;
  }
  function candidate(id) { return find('agentCandidates', id); }
  function candidateConfirm(id, finalValue) {
    load();
    var c = find('agentCandidates', id);
    if (!c) return { ok: false, msg: '候选不存在' };
    if (c.status === '已失效') return { ok: false, msg: '候选已失效（来源版本已更新），不能继续确认' };
    if (c.status === '已确认' && c.writeStatus === '写入成功') return { ok: false, msg: '候选已确认并写入成功，不能重复写入' };
    var v = finalValue || c.aiSuggestion;
    if (!v || !Object.keys(v).length) return { ok: false, msg: '确认前必须有人工确认过的最终值' };
    c.finalValue = v;
    c.status = '已确认'; c.confirmedBy = me().id; c.confirmedAt = stamp();
    /* 写入：以幂等键防重复；失败时保留已确认状态与最终值，允许按原参数重试。 */
    c.writeStatus = '写入中';
    var res = (function () {
      if (c.kind === '候选销售活动') {
        return createActivity({
          channel: v['沟通方式'] || '客户面访', at: v['沟通时间'] || stamp(), owner: c.owner,
          target: v['沟通对象'] || '', content: v['沟通内容'] || '', request: v['客户诉求'] || '',
          agreement: v['共识与承诺'] || '', nextAction: v['下一步动作'] || '',
          related: c.relatedObjects, origin: 'Agent 候选（' + c.origin + '）'
        });
      }
      if (c.kind === '候选任务') {
        var owner = v['责任人'] || c.owner;
        var a = taskAcceptor(owner);
        if (v['需验收'] !== false && !a.acceptor) {
          /* 正式写入失败用例：验收入无法唯一解析时不得降级为「无验收人直接完成」。 */
          return { ok: false, msg: '验收入无法唯一解析：' + a.rule };
        }
        return { ok: true, task: createTask({
          name: v['任务名称'], source: '沟通提炼', bizType: v['业务类型'] || '客户跟进',
          owner: owner, dueAt: v['截止时间'] || '', needAccept: false,
          related: c.relatedObjects.length ? { type: c.relatedObjects[0].type, id: c.relatedObjects[0].id, name: c.relatedObjects[0].name } : { type: '', id: '', name: '' }
        }) };
      }
      return { ok: false, msg: '该候选类型不直接生成正式对象' };
    })();
    if (res.ok) {
      c.writeStatus = '写入成功';
      c.writtenObjectId = (res.activity && res.activity.id) || (res.task && res.task.id) || '';
      c.writtenAt = stamp();
    } else {
      c.writeStatus = '写入失败'; c.failReason = res.msg;
      c.failKind = /验收入|未配置|不唯一/.test(res.msg) ? '业务异常（不可自动重试）' : '技术异常（可重试）';
    }
    audit('Agent 候选', id, '确认并写入', '待确认', c.status + '｜' + c.writeStatus);
    save();
    return { ok: res.ok, candidate: c, msg: res.ok ? '已确认并写入正式对象' : res.msg };
  }
  function candidateIgnore(id, reason) {
    load();
    var c = find('agentCandidates', id); if (!c) return { ok: false, msg: '候选不存在' };
    if (c.status !== '待确认') return { ok: false, msg: '仅待确认候选可以忽略' };
    c.status = '已忽略'; c.ignoreReason = reason || ''; c.ignoredAt = stamp();
    audit('Agent 候选', id, '忽略', '待确认', '已忽略');
    save();
    return { ok: true, candidate: c };
  }
  function candidateBatchConfirm(ids) {
    load();
    var results = [];
    ids.forEach(function (id) {
      var c = find('agentCandidates', id);
      if (!c) { results.push({ id: id, ok: false, msg: '候选不存在' }); return; }
      if (c.status !== '待确认') { results.push({ id: id, ok: false, msg: '候选状态不是待确认，跳过' }); return; }
      var r = candidateConfirm(id, c.finalValue || c.aiSuggestion);
      results.push({ id: id, ok: r.ok, msg: r.ok ? '已确认并写入' : r.msg });
    });
    return results;
  }
  function candidateRetryWrite(id) {
    load();
    var c = find('agentCandidates', id); if (!c) return { ok: false, msg: '候选不存在' };
    if (c.writeStatus !== '写入失败') return { ok: false, msg: '仅写入失败的候选可以重试' };
    if (c.failKind && c.failKind.indexOf('不可自动重试') >= 0 && !c.failResolved) {
      return { ok: false, msg: '该失败为业务异常，需先补齐前提条件，不能直接重试' };
    }
    c.writeStatus = '未写入';
    return candidateConfirm(id, c.finalValue || c.aiSuggestion);
  }
  function agentRunList(filter) {
    var list = arr('agentRuns');
    if (!filter || filter === 'all') return list;
    return list.filter(function (r) { return r.status === filter; });
  }

  /* ==================================================== 知识（08） */

  function knowledgeList(q, opts) {
    load();
    opts = opts || {};
    var list = arr('knowledge');
    var u = me();
    list = list.filter(function (k) { return k.status === '已发布' || u.role === 'R5' || k.owner === u.id; });
    if (opts.includeInactive) { /* 管理端可看全部状态 */ } else {
      list = list.filter(function (k) { return k.status === '已发布'; });
    }
    if (opts.q) {
      var s = opts.q.toLowerCase();
      list = list.filter(function (k) { return (k.title + k.summary + k.code).toLowerCase().indexOf(s) >= 0; });
    }
    return list;
  }
  function kb(id) { return find('knowledge', id); }

  /* 知识发布范围（08 §12）：只有「已发布」且「当前用户处于发布范围内」的知识
     才进入全局搜索与普通浏览。发布范围支持全员、指定角色、指定业务线。
     无法识别的范围一律不放行——与系统其余部分一致，按失败关闭处理。 */
  function knowledgeInPublishScope(k, user) {
    if (!k || k.status !== '已发布') return false;
    var u = user || me();
    var scope = String(k.scope || '');
    if (scope.indexOf('全员') >= 0) return true;
    var mRole = scope.match(/指定角色：([^；]*)/);
    if (mRole) {
      var roles = mRole[1].split(/[、,，]/).map(function (s) { return s.trim(); }).filter(Boolean);
      return roles.indexOf(u.role) >= 0;
    }
    var mLine = scope.match(/指定业务线：([^；]*)/);
    if (mLine) {
      var names = mLine[1].split(/[、,，]/).map(function (s) { return s.trim(); }).filter(Boolean);
      var mine = (u.businessLine || []).map(businessLineName);
      return mine.some(function (n) { return names.indexOf(n) >= 0; });
    }
    return false;
  }
  function knowledgePublish(id, note) {
    load();
    var k = find('knowledge', id); if (!k) return { ok: false, msg: '知识文档不存在' };
    if (k.status === '已发布') return { ok: false, msg: '该文档已是已发布状态' };
    k.status = '已发布'; k.publishedAt = stamp();
    k.history.push({ version: k.version, at: stamp(), by: me().id, note: note || '发布' });
    audit('知识', id, '发布', '', k.version);
    save();
    return { ok: true, doc: k };
  }
  function knowledgeDeactivate(id, reason) {
    load();
    var k = find('knowledge', id); if (!k) return { ok: false, msg: '知识文档不存在' };
    if (k.status !== '已发布') return { ok: false, msg: '仅已发布文档可以停用' };
    k.status = '已停用'; k.deactivatedAt = stamp(); k.deactivateReason = reason || '';
    k.history.push({ version: k.version, at: stamp(), by: me().id, note: '停用：' + (reason || '') });
    /* 停用后不进入普通搜索，也不作为 Agent 新回答来源。 */
    audit('知识', id, '停用', '已发布', '已停用｜' + (reason || ''));
    save();
    return { ok: true, doc: k };
  }

  /* ==================================================== 消息投递（07/08） */

  function deliveryList(filter) {
    var list = arr('messageDeliveries');
    filter = filter || {};
    if (filter.delivery) list = list.filter(function (m) { return m.deliveryStatus === filter.delivery; });
    if (filter.read) list = list.filter(function (m) { return m.readStatus === filter.read; });
    if (filter.channel) list = list.filter(function (m) { return m.channel === filter.channel; });
    return list;
  }
  /* 投递失败不改变来源业务对象；只重投消息，超限时创建「消息投递失败」异常事项。 */
  function retryDelivery(id) {
    load();
    var m = find('messageDeliveries', id); if (!m) return { ok: false, msg: '投递记录不存在' };
    if (m.deliveryStatus === '成功') return { ok: false, msg: '该记录已投递成功，不重复投递' };
    m.retryCount = (m.retryCount || 0) + 1;
    if (m.retryCount > 3) {
      m.deliveryStatus = '失败'; m.failReason = m.failReason || '超过自动重试上限';
      var ex = arr('exceptions').filter(function (e) { return e.sourceMsgId === m.msgId; })[0];
      if (!ex) {
        var eid = nextId('EXC');
        db.exceptions.unshift({ id: eid, type: '消息投递失败', objectType: m.target.type, objectId: m.target.id,
          detail: '消息「' + m.event + '」多次投递失败，需人工处理', status: '待处理', handler: '', sourceMsgId: m.msgId,
          at: stamp(), history: [{ at: stamp(), actor: me().name, action: '系统创建异常事项', from: '', to: '待处理' }] });
        audit('异常事项', eid, '系统创建', '—', '消息投递失败');
      }
      save();
      return { ok: false, msg: '已超过自动重试上限，已创建「消息投递失败」异常事项' };
    }
    m.deliveryStatus = '成功'; m.failReason = '';
    audit('消息投递', id, '手工重试投递', '失败', '成功');
    save();
    return { ok: true, msg: '第 ' + m.retryCount + ' 次重试投递成功' };
  }

  /* ==================================================== 集成与同步（08） */

  function extSystems() { return arr('externalSystems'); }
  function syncList(filter) {
    var list = arr('syncJobs');
    filter = filter || {};
    if (filter.status) list = list.filter(function (s) { return s.status === filter.status; });
    if (filter.system) list = list.filter(function (s) { return s.system === filter.system; });
    return list;
  }
  function retrySync(id) {
    load();
    var s = find('syncJobs', id); if (!s) return { ok: false, msg: '同步任务不存在' };
    if (s.status === '成功') return { ok: false, msg: '该同步任务已成功，不重复执行' };
    s.retryCount = (s.retryCount || 0) + 1;
    if (s.retryCount > s.maxRetry) {
      s.status = '失败';
      save();
      return { ok: false, msg: '已超过最大重试次数，需人工处理' };
    }
    s.executedAt = stamp();
    s.status = '成功'; s.lastSuccessAt = stamp(); s.failReason = '';
    audit('同步任务', id, '重试同步', '', '成功');
    save();
    return { ok: true, msg: '重试成功' };
  }

  /* ==================================================== 异常事项与数据质量（07/08） */

  function exceptionList(filter) {
    var list = arr('exceptions');
    filter = filter || {};
    if (filter.status) list = list.filter(function (e) { return e.status === filter.status; });
    if (filter.type) list = list.filter(function (e) { return e.type === filter.type; });
    return list;
  }
  /* 领取＝原子占用；同一事项同一时间只有一条未完成记录。 */
  function exceptionClaim(id) {
    load();
    var e = find('exceptions', id); if (!e) return { ok: false, msg: '异常事项不存在' };
    if (e.status !== '待处理') return { ok: false, msg: '仅待处理事项可以领取' };
    if (e.handler) return { ok: false, msg: '该事项已被 ' + userName(e.handler) + ' 领取' };
    e.handler = me().id; e.status = '处理中'; e.claimedAt = stamp();
    hist(e, me().name, '领取', '待处理', '处理中');
    audit('异常事项', id, '领取', '待处理', '处理中');
    save();
    return { ok: true, item: e };
  }
  function exceptionReturn(id, reason) {
    load();
    var e = find('exceptions', id); if (!e) return { ok: false, msg: '异常事项不存在' };
    if (e.status !== '处理中') return { ok: false, msg: '仅处理中事项可以退回' };
    if (!reason) return { ok: false, msg: '退回必须填写原因' };
    var old = e.handler;
    e.handler = ''; e.status = '待处理'; e.returnReason = reason; e.returnedAt = stamp();
    hist(e, me().name, '退回', '处理中', '待处理', reason);
    audit('异常事项', id, '退回', '处理中', '待处理｜原因：' + reason);
    save();
    return { ok: true, item: e };
  }
  /* 异常事项不能直接修改正式业务事实，必须跳转源对象使用正式动作。 */
  function exceptionComplete(id, note) {
    load();
    var e = find('exceptions', id); if (!e) return { ok: false, msg: '异常事项不存在' };
    if (e.status !== '处理中' && e.status !== '待处理') return { ok: false, msg: '当前状态不可完成' };
    if (!note) return { ok: false, msg: '完成必须填写处理说明' };
    var before = e.status;
    e.status = '已完成'; e.handler = e.handler || me().id; e.note = note; e.finishedAt = stamp();
    hist(e, me().name, '完成', before, '已完成', note);
    audit('异常事项', id, '完成', before, '已完成');
    save();
    return { ok: true, item: e };
  }
  function exceptionReject(id, reason) {
    load();
    var e = find('exceptions', id); if (!e) return { ok: false, msg: '异常事项不存在' };
    if (['已完成', '不采纳'].indexOf(e.status) >= 0) return { ok: false, msg: '当前状态不可变更' };
    if (!reason) return { ok: false, msg: '不采纳必须填写原因' };
    var before = e.status;
    e.status = '不采纳'; e.rejectReason = reason; e.finishedAt = stamp();
    hist(e, me().name, '不采纳', before, '不采纳', reason);
    audit('异常事项', id, '不采纳', before, '不采纳｜原因：' + reason);
    save();
    return { ok: true, item: e };
  }
  /* 数据质量结果状态：当前存在／已消除／已忽略，不复用异常事项状态。 */
  function qualityIssueList(filter) {
    var list = arr('qualityIssues');
    filter = filter || {};
    if (filter.status) list = list.filter(function (q) { return q.resultStatus === filter.status; });
    if (filter.type) list = list.filter(function (q) { return q.type === filter.type; });
    return list;
  }
  function qualityIgnore(id, reason) {
    load();
    var q = find('qualityIssues', id); if (!q) return { ok: false, msg: '质量问题不存在' };
    if (q.resultStatus !== '当前存在') return { ok: false, msg: '仅当前存在的问题可以忽略' };
    if (!reason) return { ok: false, msg: '忽略必须填写原因' };
    q.resultStatus = '已忽略'; q.ignoredReason = reason; q.ignoredAt = stamp(); q.ignoredBy = me().id;
    audit('数据质量', id, '忽略问题', '当前存在', '已忽略｜原因：' + reason);
    save();
    return { ok: true, item: q };
  }
  /* 修正源对象 → 重新检测 → 问题消失 → 关联异常事项完成。 */
  function qualityRerun() {
    load();
    var now0 = stamp();
    arr('qualityRules').forEach(function (r) { r.lastRunAt = now0; });
    var cleared = 0;
    arr('qualityIssues').forEach(function (q) {
      if (q.resultStatus !== '当前存在') return;
      var gone = false;
      if (q.objectType === '客户') {
        var c = customer(q.objectId);
        if (c && q.missingFields.indexOf('统一社会信用代码') >= 0 && c.creditCode) gone = true;
      }
      if (gone) {
        q.resultStatus = '已消除'; q.clearedAt = now0;
        if (q.exceptionId) {
          var e = find('exceptions', q.exceptionId);
          if (e && e.status !== '已完成') { e.status = '已完成'; e.note = '源对象修正后重新检测，问题消除'; e.finishedAt = now0; }
        }
        cleared++;
      }
    });
    audit('数据质量', '—', '手工重新检测', '', '规则版本 V1／V2｜已消除 ' + cleared + ' 条');
    save();
    return { ok: true, cleared: cleared };
  }

  /* ==================================================== 人员、权限与移交（07） */

  function peopleList() { return arr('users'); }
  function permPendingList(filter) {
    var list = arr('permissionPending');
    if (filter && filter.status) list = list.filter(function (p) { return p.status === filter.status; });
    return list;
  }
  function permPendingAct(id, action, reason) {
    load();
    var p = find('permissionPending', id); if (!p) return { ok: false, msg: '待处理事项不存在' };
    if (p.status === '已完成') return { ok: false, msg: '该事项已完成' };
    if (action === '开始处理') { if (p.status !== '待处理') return { ok: false, msg: '仅待处理可以开始处理' }; p.status = '处理中'; }
    else if (action === '完成') {
      if (!reason) return { ok: false, msg: '完成必须填写处理说明' };
      p.status = '已完成'; p.note = reason; p.finishedAt = stamp(); p.handler = me().id;
    } else return { ok: false, msg: '未知动作' };
    audit('权限待处理', id, action, '', p.status);
    save();
    return { ok: true, item: p };
  }
  function handoverList(filter) {
    var list = arr('handovers');
    if (filter && filter.status) list = list.filter(function (h) { return h.status === filter.status; });
    return list;
  }
  function handover(id) { return find('handovers', id); }
  function handoverPrecheck(id) {
    load();
    var h = find('handovers', id); if (!h) return { ok: false, msg: '移交作业不存在' };
    h.precheckAt = stamp();
    h.items.forEach(function (it) {
      if (!it.receiver) {
        var r = { owner: 'U-001' };
        it.precheck = '需指定接收人';
      } else {
        var u = user(it.receiver);
        it.precheck = u ? '可接收（区域／业务线资格校验通过）' : '接收人不可用';
      }
    });
    h.status = h.status === '待预检' ? '待确认' : h.status;
    audit('人员移交', id, '执行预检', '', h.items.length + ' 项待移交');
    save();
    return { ok: true, handover: h };
  }
  /* 执行支持部分成功与失败重试，成功项不重复；未指定接收人的项保持待移交，不自动进入公海。 */
  function handoverRun(id, items) {
    load();
    var h = find('handovers', id); if (!h) return { ok: false, msg: '移交作业不存在' };
    if (['待预检'].indexOf(h.status) >= 0) return { ok: false, msg: '必须先执行预检' };
    if (['已完成', '已取消', '处理中'].indexOf(h.status) >= 0) return { ok: false, msg: '当前状态不可执行移交' };
    if (items) h.items = items;
    var results = [];
    h.items.forEach(function (it) {
      if (it.result === '成功') { results.push({ id: it.id, ok: true, msg: '已成功，不重复执行' }); return; }
      if (!it.receiver) { it.result = '失败'; it.note = it.note || '未指定接收人，保持待移交'; results.push({ id: it.id, ok: false, msg: '未指定接收人' }); return; }
      var o = find(it.type.indexOf('客户经营责任') >= 0 ? 'businessRelations' : it.type.indexOf('线索') >= 0 ? 'leads' : it.type.indexOf('商机') >= 0 ? 'opportunities' : it.type.indexOf('任务') >= 0 ? 'tasks' : 'businessRelations', it.id);
      if (!o) { it.result = '失败'; results.push({ id: it.id, ok: false, msg: '源对象已不可用' }); return; }
      if (o.status === '已失效' || o.status === '已取消' || o.status === '已转化') { it.result = '失败'; it.note = '源对象状态为 ' + o.status + '，不再需要移交'; results.push({ id: it.id, ok: false, msg: it.note }); return; }
      if (o.owner !== undefined) o.owner = it.receiver;
      it.result = '成功'; it.note = it.note || ('已移交至 ' + userName(it.receiver));
      results.push({ id: it.id, ok: true, msg: it.note });
    });
    var okc = results.filter(function (r) { return r.ok; }).length;
    var fail = results.length - okc;
    h.status = fail === 0 ? '已完成' : (okc === 0 ? '待确认' : '部分成功');
    h.executedAt = stamp();
    audit('人员移交', id, '执行移交', '', '成功 ' + okc + '，失败 ' + fail);
    save();
    return { ok: fail === 0, handover: h, results: results, okc: okc, fail: fail };
  }
  function peopleSyncList(filter) {
    var list = arr('peopleSyncIssues');
    if (filter && filter.status) list = list.filter(function (p) { return p.status === filter.status; });
    return list;
  }
  function peopleSyncAct(id, action, reason) {
    load();
    var p = find('peopleSyncIssues', id); if (!p) return { ok: false, msg: '记录不存在' };
    if (p.status === '已处理') return { ok: false, msg: '该记录已处理' };
    if (action === '标记已处理') { p.status = '已处理'; p.note = reason || p.note; p.handledAt = stamp(); p.handler = me().id; }
    else if (action === '等待用户中心重新推送') { p.status = '处理中'; p.note = '已通知用户中心侧修正后重新推送'; }
    else return { ok: false, msg: '未知动作' };
    audit('人员同步异常', id, action, '', p.status);
    save();
    return { ok: true, item: p };
  }

  /* ==================================================== 指标（06 §4） */

  var METRIC_THEMES = ['客户经营', '商机推进', '商机结果', '执行闭环', '时效异常', '数据质量'];

  function metric(code) { return arr('metrics').filter(function (m) { return m.code === code; })[0] || null; }
  function metricRange(preset) {
    var t = today();
    if (!preset || preset === '本月') return { label: '本月', from: t.slice(0, 7) + '-01', to: t };
    if (preset === '上月') { var d = new Date(t.replace(/-/g, '/')); d.setDate(0); var m = d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2); return { label: '上月', from: m + '-01', to: m + '-' + ('0' + d.getDate()).slice(-2) }; }
    if (preset === '本季度') { var q = Math.floor(new Date(t.replace(/-/g, '/')).getMonth() / 3) * 3 + 1; return { label: '本季度', from: t.slice(0, 4) + '-' + ('0' + q).slice(-2) + '-01', to: t }; }
    if (preset === '近 30 天') { return { label: '近 30 天', from: addDays(t, -29), to: t }; }
    return { label: '本月', from: t.slice(0, 7) + '-01', to: t };
  }
  function inRange(d, r) { return !!d && d.slice(0, 10) >= r.from && d.slice(0, 10) <= r.to; }
  function metricInjectFail(code, on) {
    load();
    var f = db.runtime.uiState.metricFailed || {};
    if (on) f[code] = true; else delete f[code];
    db.runtime.uiState.metricFailed = f; save();
  }
  /* 指标计算：
     — 未知、不可计算、无分母一律显示「—」，只有确定为零才显示 0；
     — 单卡失败只影响该卡，其他卡继续可用；
     — 字段映射未完成的指标显示「暂无可用数据」，不显示 0。 */
  function metricValue(code, filters) {
    load();
    filters = filters || {};
    var r = metricRange(filters.range);
    var m = metric(code);
    if (!m) return { code: code, name: code, status: 'undefined', display: '—', reason: '指标未定义' };
    var failed = (db.runtime.uiState.metricFailed || {})[code];
    var mappingMissing = ['MET-OPP-STALL', 'MET-TSK-SOON'];
    var base = {
      code: code, name: m.name, theme: m.theme, type: m.type, unit: m.unit, version: m.version,
      formula: m.formula, owner: m.owner, refresh: m.refresh, drill: m.drill,
      dataAt: today() + ' ' + now().slice(11, 16), range: r
    };
    if (failed) return Object.assign(base, { status: 'failed', display: '暂无可用数据', reason: '该卡数据获取失败（其他指标不受影响）' });
    if (mappingMissing.indexOf(code) >= 0) return Object.assign(base, { status: 'nomapping', display: '暂无可用数据', reason: '指标字段映射未完成' });

    var custs = arr('customers').filter(function (c) { return !c.mergedInto; });
    var rels = arr('businessRelations');
    var opps = arr('opportunities');
    var tsks = arr('tasks');
    var rpts = arr('reports');
    var v = 0, ok = true, zero = true, extra = {};

    if (code === 'MET-CUS-TOTAL') v = custs.length;
    else if (code === 'MET-CUS-NEW') v = custs.filter(function (c) { return inRange(c.createdAt, r); }).length;
    else if (code === 'MET-CUS-OPERATING') v = custs.filter(function (c) { return rels.some(function (x) { return x.customerId === c.id && x.status === '有效'; }); }).length;
    else if (code === 'MET-CUS-NEWREL') v = custs.filter(function (c) { return rels.some(function (x) { return x.customerId === c.id && x.status === '有效' && inRange(x.createdAt, r); }); }).length;
    else if (code === 'MET-OPP-TOTAL') v = opps.length;
    else if (code === 'MET-OPP-NEW') v = opps.filter(function (o) { return inRange(o.createdAt, r); }).length;
    else if (code === 'MET-OPP-OPEN') v = opps.filter(function (o) { return o.processStatus === '进行中'; }).length;
    else if (code === 'MET-OPP-STAGE') {
      var dist = {}; UNIFIED_STAGE_NAMES().forEach(function (n) { dist[n] = 0; });
      opps.filter(function (o) { return o.processStatus === '进行中'; }).forEach(function (o) {
        var c = currentStageByTemplate(o); if (c) dist[c.stageName] = (dist[c.stageName] || 0) + 1;
      });
      v = opps.filter(function (o) { return o.processStatus === '进行中'; }).length;
      extra.distribution = dist; extra.sleeping = opps.filter(function (o) { return o.processStatus === '休眠'; }).length;
    }
    else if (code === 'MET-OPP-CLOSED') v = opps.filter(function (o) { return o.closedAt && inRange(o.closedAt, r); }).length;
    else if (code === 'MET-OPP-WON') v = opps.filter(function (o) { return o.closeResult === '赢单' && inRange(o.closedAt, r); }).length;
    else if (code === 'MET-OPP-LOST') v = opps.filter(function (o) { return o.closeResult === '输单' && inRange(o.closedAt, r); }).length;
    else if (code === 'MET-OPP-WINRATE') {
      var w = opps.filter(function (o) { return o.closeResult === '赢单' && inRange(o.closedAt, r); }).length;
      var l = opps.filter(function (o) { return o.closeResult === '输单' && inRange(o.closedAt, r); }).length;
      extra.numerator = w; extra.denominator = w + l;
      if (w + l === 0) { ok = false; extra.denominatorZero = true; } else { v = Math.round(w / (w + l) * 1000) / 10; }
    }
    else if (code === 'MET-TSK-SHOULD') v = tsks.filter(function (t) { return inRange(t.dueAt, r) && ['已取消', '已失效'].indexOf(t.status) < 0; }).length;
    else if (code === 'MET-TSK-DONE') v = tsks.filter(function (t) { return inRange(t.dueAt, r) && t.status === '已完成'; }).length;
    else if (code === 'MET-TSK-RATE') {
      var should = tsks.filter(function (t) { return inRange(t.dueAt, r) && ['已取消', '已失效'].indexOf(t.status) < 0; }).length;
      var done = tsks.filter(function (t) { return inRange(t.dueAt, r) && t.status === '已完成'; }).length;
      extra.numerator = done; extra.denominator = should;
      if (!should) { ok = false; } else { v = Math.round(done / should * 1000) / 10; }
    }
    else if (code === 'MET-RPT-RATE') {
      var subs = rpts.filter(function (x) { return inRange(x.date, r); });
      var uniq = {}; subs.forEach(function (x) { uniq[x.userId + '|' + x.date] = { u: x.userId, d: x.date, s: x.status }; });
      var cells = Object.keys(uniq).map(function (k) { return uniq[k]; });
      var shouldN = cells.length, doneN = cells.filter(function (c) { return c.s === '已提交'; }).length;
      extra.numerator = doneN; extra.denominator = shouldN; extra.cells = cells;
      if (!shouldN) { ok = false; } else { v = Math.round(doneN / shouldN * 1000) / 10; }
    }
    else if (code === 'MET-TSK-OVERDUE') v = tsks.filter(function (t) { return taskOverdue(t); }).length;
    else if (code === 'MET-TSK-OVDRATE') {
      var openT = tsks.filter(function (t) { return ['待接收', '进行中', '待验收'].indexOf(t.status) >= 0 && t.dueAt; });
      var od = openT.filter(taskOverdue).length;
      extra.numerator = od; extra.denominator = openT.length;
      if (!openT.length) { ok = false; } else { v = Math.round(od / openT.length * 1000) / 10; }
    }
    else if (code === 'MET-CUS-COMPLETE' || code === 'MET-CUS-MISSING') {
      var key = ['customerName', 'customerType', 'creditCode', 'region'];
      var bad = custs.filter(function (c) { return key.some(function (k) { return !c[k]; }); });
      extra.numerator = custs.length - bad.length; extra.denominator = custs.length;
      if (code === 'MET-CUS-MISSING') v = bad.length;
      else if (!custs.length) { ok = false; } else { v = Math.round((custs.length - bad.length) / custs.length * 1000) / 10; }
    }
    else if (code === 'MET-OPP-COMPLETE' || code === 'MET-OPP-MISSING') {
      var bad2 = opps.filter(function (o) { return !o.customerId || !o.name || !o.lines || !o.lines.length || (o.currentStageCode !== 'ST-CE-01' && !o.predictedClose); });
      extra.numerator = opps.length - bad2.length; extra.denominator = opps.length;
      if (code === 'MET-OPP-MISSING') v = bad2.length;
      else if (!opps.length) { ok = false; } else { v = Math.round((opps.length - bad2.length) / opps.length * 1000) / 10; }
    }
    else { return Object.assign(base, { status: 'undefined', display: '—', reason: '该指标未纳入本期口径' }); }

    /* 环比：仅发生型指标展示；跨版本、无上期或上期为 0 都不计算增长率。 */
    var trend = null;
    if (m.type === '发生型') {
      var prev = metricRange(filters.range === '上月' ? '上月' : '上月');
      var prevVal = null;
      if (code === 'MET-OPP-WON') prevVal = opps.filter(function (o) { return o.closeResult === '赢单' && inRange(o.closedAt, prev); }).length;
      else if (code === 'MET-OPP-NEW') prevVal = opps.filter(function (o) { return inRange(o.createdAt, prev); }).length;
      else if (code === 'MET-CUS-NEW') prevVal = custs.filter(function (c) { return inRange(c.createdAt, prev); }).length;
      else if (code === 'MET-TSK-DONE') prevVal = tsks.filter(function (t) { return inRange(t.dueAt, prev) && t.status === '已完成'; }).length;
      else prevVal = null;
      if (prevVal === null || prevVal === undefined) trend = { display: '—', reason: '无上期对比数据' };
      else if (prevVal === 0) trend = { display: ok ? '新增 ' + v : '—', reason: '上期为 0，不计算增长率' };
      else trend = { display: (v - prevVal >= 0 ? '+' : '') + Math.round((v - prevVal) / prevVal * 1000) / 10 + '%', prev: prevVal };
    }

    if (!ok) return Object.assign(base, { status: 'unknown', display: '—', reason: extra.denominatorZero ? '本期分母为 0，无可计算比率' : '分母不足，无法计算', numerator: extra.numerator, denominator: extra.denominator, trend: trend, extra: extra });
    return Object.assign(base, { status: 'ok', display: m.unit === '%' ? (v + '%') : String(v), value: v, trend: trend, extra: extra, zero: zero && v === 0 });
  }

  function UNIFIED_STAGE_NAMES() { return ['机会确认', '需求确认', '方案验证', '报价与审批', '商务与合同']; }
  function currentStageByTemplate(o) {
    var t = template(o.templateCode, o.templateVersion);
    if (!t) return null;
    var st = (t.stages || []).filter(function (s) { return s.code === o.currentStageCode; })[0];
    /* 模板阶段对象上的统一阶段字段名是 unified（见 demo-data 的 templates 与 gateCheck 的判定）；
       同时兼容 unifiedStage，避免此处静默退化为详细阶段名，导致阶段分布与下钻的「当前阶段」列
       显示 8 个详细阶段而不是 5 个统一阶段。 */
    return st ? { stageName: st.unified || st.unifiedStage || st.name, detail: st.name } : null;
  }

  /* 看板：六个主题分组，不停留在等权平铺。 */
  function metricBoard(filters) {
    var list = arr('metrics').map(function (m) { return metricValue(m.code, filters); });
    return METRIC_THEMES.map(function (th) {
      var items = list.filter(function (x) { return x.theme === th; });
      return {
        theme: th,
        period: items.filter(function (x) { return x.type === '发生型'; }),
        current: items.filter(function (x) { return x.type === '当前状态'; })
      };
    });
  }

  /* 下钻：保留指标、版本、筛选与来源上下文，展示纳入／未纳入原因；比率展示完整分母。 */
  function metricDrill(code, filters) {
    load();
    filters = filters || {};
    var m = metric(code); if (!m) return null;
    var r = metricRange(filters.range);
    var mv = metricValue(code, filters);
    var rows = [], excluded = [], denomRows = [], columns = [];
    var custs = arr('customers');

    if (code.indexOf('MET-CUS') === 0) {
      columns = ['客户名称', '客户类型', '所属区域', '统一社会信用代码', '经营关系', '负责人', '纳入判定', '未纳入原因'];
      custs.forEach(function (c) {
        var rs = arr('businessRelations').filter(function (x) { return x.customerId === c.id; });
        var act = rs.filter(function (x) { return x.status === '有效'; });
        var include = true, why = '';
        if (code === 'MET-CUS-OPERATING') { include = act.length > 0; why = include ? '' : '当前无有效经营关系'; }
        if (code === 'MET-CUS-NEW') { include = inRange(c.createdAt, r); why = include ? '' : '创建时间不在统计周期内'; }
        if (code === 'MET-CUS-NEWREL') { include = rs.some(function (x) { return x.status === '有效' && inRange(x.createdAt, r); }); why = include ? '' : '周期内无新建有效经营关系'; }
        if (code === 'MET-CUS-COMPLETE' || code === 'MET-CUS-MISSING') {
          var miss = ['customerName', 'customerType', 'creditCode', 'region'].filter(function (k) { return !c[k]; });
          include = miss.length === 0; why = include ? '' : ('缺失字段：' + miss.join('、'));
        }
        if (code === 'MET-CUS-MISSING') { include = why !== ''; why = include ? why : '关键字段完整'; }
        var row = [c.customerName, c.customerType || '—', c.region || '—', c.creditCode || '—',
          act.length ? act.map(function (x) { return x.region + '／' + x.businessLine; }).join('；') : '无',
          act.length ? (act.map(function (x) { return userName(x.owner) || '全国公海'; }).join('；')) : '—',
          include ? '纳入' : '未纳入', why || '—'];
        (include ? rows : excluded).push({ cells: row, id: c.id, name: c.customerName, path: 'customer/detail.html' });
      });
      if (code === 'MET-CUS-COMPLETE' || code === 'MET-CUS-MISSING') columns = ['客户名称', '客户类型', '所属区域', '统一社会信用代码', '缺失字段', '纳入判定', '未纳入原因'];
      if (code === 'MET-CUS-COMPLETE' || code === 'MET-CUS-MISSING') {
        rows = custs.map(function (c) {
          var miss = ['customerName', 'customerType', 'creditCode', 'region'].filter(function (k) { return !c[k]; });
          var inc = code === 'MET-CUS-COMPLETE' ? miss.length === 0 : miss.length > 0;
          return { cells: [c.customerName, c.customerType || '—', c.region || '—', c.creditCode || '—', miss.join('、') || '无', inc ? '纳入' : '未纳入', inc ? '—' : '不满足该指标判定'], id: c.id, name: c.customerName, path: 'customer/detail.html' };
        });
        excluded = [];
      }
    } else if (code.indexOf('MET-OPP') === 0) {
      columns = ['商机名称', '客户', '当前阶段', '过程状态', '预计成交时间', '负责人', '纳入判定', '未纳入原因'];
      arr('opportunities').forEach(function (o) {
        var cs = currentStageByTemplate(o);
        var include = true, why = '';
        if (code === 'MET-OPP-OPEN' || code === 'MET-OPP-STAGE') { include = o.processStatus === '进行中'; why = include ? '' : ('过程状态为「' + o.processStatus + '」，不计入推进中'); }
        if (code === 'MET-OPP-WON') { include = o.closeResult === '赢单'; why = include ? '' : ('当前结果为「' + (o.closeResult || '未结束') + '」'); }
        if (code === 'MET-OPP-LOST') { include = o.closeResult === '输单'; why = include ? '' : ('当前结果为「' + (o.closeResult || '未结束') + '」'); }
        if (code === 'MET-OPP-WINRATE') {
          include = o.closeResult === '赢单' || o.closeResult === '输单';
          why = include ? '' : (o.closeResult === '终止' ? '终止不进入分母' : '未结束，不进入分母');
        }
        if (code === 'MET-OPP-NEW') { include = inRange(o.createdAt, r); why = include ? '' : '创建时间不在统计周期内'; }
        if (code === 'MET-OPP-CLOSED') { include = !!o.closedAt && inRange(o.closedAt, r); why = include ? '' : '结果时间不在统计周期内'; }
        if (code === 'MET-OPP-COMPLETE' || code === 'MET-OPP-MISSING') {
          var miss2 = [];
          if (!o.customerId) miss2.push('客户');
          if (!o.name) miss2.push('商机名称');
          if (!o.lines || !o.lines.length) miss2.push('主业务线');
          if (o.currentStageCode !== 'ST-CE-01' && !o.predictedClose) miss2.push('预计成交时间');
          include = miss2.length === 0; why = include ? '' : ('缺失字段：' + miss2.join('、'));
          if (code === 'MET-OPP-MISSING') { include = miss2.length > 0; why = include ? why : '关键字段完整'; }
        }
        if (code === 'MET-OPP-WINRATE') denomRows.push({ cells: [o.name, (customer(o.customerId) || {}).name || o.customerId, cs ? cs.stageName : '—', o.processStatus, o.predictedClose || '待补充', userName(o.owner), o.closeResult === '赢单' ? '赢单（分子）' : '输单（分母）', '—'], id: o.id, name: o.name, path: 'opportunity/detail.html' });
        var row = [o.name, (customer(o.customerId) || {}).name || o.customerId, cs ? cs.stageName : '—', o.processStatus, o.predictedClose || '待补充', userName(o.owner), include ? '纳入' : '未纳入', why || '—'];
        (include ? rows : excluded).push({ cells: row, id: o.id, name: o.name, path: 'opportunity/detail.html' });
      });
    } else if (code.indexOf('MET-TSK') === 0 || code.indexOf('MET-RPT') === 0) {
      if (code.indexOf('MET-TSK') === 0) {
        columns = ['任务名称', '来源', '业务类型', '责任人', '状态', '有效截止时间', '实际完成时间', '是否逾期完成', '纳入判定', '未纳入原因'];
        arr('tasks').forEach(function (t) {
          var include = true, why = '';
          if (['MET-TSK-SHOULD', 'MET-TSK-DONE', 'MET-TSK-RATE'].indexOf(code) >= 0) {
            include = inRange(t.dueAt, r) && ['已取消', '已失效'].indexOf(t.status) < 0;
            why = include ? '' : (['已取消', '已失效'].indexOf(t.status) >= 0 ? ('状态为「' + t.status + '」，整单剔除') : '有效截止时间不在统计周期内');
          }
          if (code === 'MET-TSK-DONE') { include = include && t.status === '已完成'; why = include ? '' : '当前未完成'; }
          if (code === 'MET-TSK-OVERDUE' || code === 'MET-TSK-OVDRATE') {
            include = taskOverdue(t); why = include ? '' : (t.dueAt ? '未逾期' : '无有效截止时间，不进入分母');
          }
          var row = [t.name, t.source, t.bizType, userName(t.owner), t.status, (t.originalDueAt ? t.originalDueAt + ' → ' + t.dueAt : t.dueAt) || '—',
            t.doneAt || '—', (t.status === '已完成' && taskOverdue({ status: '进行中', dueAt: t.dueAt })) ? '是' : (t.status === '已完成' ? '否' : '—'),
            include ? '纳入' : '未纳入', why || '—'];
          (include ? rows : excluded).push({ cells: row, id: t.id, name: t.name, path: 'task/detail.html' });
        });
      } else {
        columns = ['日期', '人员', '团队', '应提交状态', '提交状态', '提交时间', '纳入判定', '未纳入原因'];
        arr('reports').forEach(function (x) {
          var inc = inRange(x.date, r);
          (inc ? rows : excluded).push({ cells: [x.date, userName(x.userId), (user(x.userId) || {}).dept || '—', '应提交', x.status, x.submittedAt || '—', inc ? '纳入' : '未纳入', inc ? '—' : '应提交日期不在统计周期内'], id: x.id, name: x.date + ' ' + userName(x.userId), path: 'report/detail.html' });
        });
      }
    } else if (code.indexOf('MET-OPP-COMPLETE') === 0) { /* 已在上方商机分支处理 */ }

    return {
      metric: m, value: mv, filters: filters, range: r, columns: columns,
      rows: rows, excluded: excluded, denominatorRows: denomRows,
      includedCount: rows.length, excludedCount: excluded.length,
      dataAt: mv.dataAt, version: m.version, source: m.source, canExport: true
    };
  }

  /* ==================================================== 业务配置与指标配置（06） */

  var CONFIG_B = { taskRules: '任务规则', visitRules: '拜访规则' };
  var flowTemplates = function () { return arr('templates'); };

  /* 流程模板按「业务线 ＋ 销售场景」唯一绑定，模板对象没有 id，只能以 code/version 定位，
     因此不走 configBPublish（它按 id 查找）。这里单独实现同一套 B 类语义：
     草稿 → 校验 → 立即原子发布 → 旧版本转历史；发布失败回滚，旧版本继续生效。 */
  function templateKey(code, version) {
    return 'TPL-DRAFT-' + code + '-' + String(version || '').replace(/^v/i, '');
  }
  function templateDraftSave(code, patch) {
    load();
    var list0 = arr('templates');
    /* 新草稿一律以「当前生效版本」为基线；没有生效版本时才退回该编码下的第一条。 */
    var base = list0.filter(function (t) { return t.code === code && t.status === '生效'; })[0] ||
      list0.filter(function (t) { return t.code === code; }).pop();
    if (!base) return { ok: false, msg: '模板不存在，不能基于不存在的版本创建草稿' };
    var list = list0;
    var draft = list.filter(function (t) { return t.code === code && t.status === '草稿'; })[0];
    if (!draft) {
      var next = 'v' + (parseInt(String(base.version || 'v1').replace(/^v/i, ''), 10) + 1);
      draft = {
        code: code, version: next, name: patch && patch.name ? patch.name : base.name,
        businessLine: base.businessLine, scene: base.scene, status: '草稿', publishedAt: '',
        stagnantDays: base.stagnantDays, stages: JSON.parse(JSON.stringify(base.stages || [])),
        note: (patch && patch.note) || '基于已生效版本复制的新草稿', history: []
      };
      list.unshift(draft);
    }
    ['name', 'stagnantDays', 'note'].forEach(function (k) {
      if (patch && patch[k] !== undefined) draft[k] = patch[k];
    });
    draft.history = draft.history || [];
    draft.history.push({ version: draft.version, at: stamp(), by: me().id, action: '保存草稿', note: draft.note || '' });
    audit('业务配置', code + ' ' + draft.version, '保存草稿（B 类）', '', draft.note || '');
    save();
    return { ok: true, draft: draft, msg: '已保存草稿 ' + draft.version };
  }
  function templateValidate(code) {
    load();
    var draft = arr('templates').filter(function (t) { return t.code === code && t.status === '草稿'; })[0];
    if (!draft) return { ok: false, errors: ['没有待发布的草稿版本'], msg: '没有待发布的草稿版本' };
    var errs = [];
    if (!draft.name) errs.push('模板名称必填');
    if (!draft.stages || !draft.stages.length) errs.push('至少保留一个阶段');
    var seen = {}, lastUnified = -1;
    (draft.stages || []).forEach(function (s, i) {
      if (!s.name) errs.push('第 ' + (i + 1) + ' 个阶段缺少阶段名称');
      if (seen[s.code]) errs.push('阶段编码重复：' + s.code);
      seen[s.code] = true;
      var u = s.unified || s.unifiedStage;
      if (!u) { errs.push('阶段「' + (s.name || s.code) + '」缺少统一阶段映射'); return; }
      var idx = UNIFIED_STAGE_NAMES().indexOf(u);
      if (idx < 0) { errs.push('阶段「' + s.name + '」的统一阶段「' + u + '」不在五个统一阶段之内'); return; }
      if (idx < lastUnified) errs.push('阶段「' + s.name + '」的统一阶段顺序回退，流程阶段必须单调推进');
      lastUnified = idx;
    });
    save();
    return { ok: errs.length === 0, errors: errs, msg: errs.length ? errs.join('；') : '校验通过' };
  }
  /* 发布即整版生效或整版不生效；不做「模板 A 用新版本、模板 B 用旧版本」的跨版本替换。 */
  function templatePublish(code) {
    load();
    var v = templateValidate(code);
    if (!v.ok) return { ok: false, msg: '校验未通过：' + v.msg, errors: v.errors, published: false };
    var list = arr('templates');
    var draft = list.filter(function (t) { return t.code === code && t.status === '草稿'; })[0];
    var actives = list.filter(function (t) { return t.code === code && t.status === '生效'; });
    try {
      actives.forEach(function (t) { t.status = '历史'; t.retiredAt = stamp(); });
      draft.status = '生效'; draft.publishedAt = stamp(); draft.publisher = me().id;
      draft.history.push({ version: draft.version, at: stamp(), by: me().id, action: '立即发布', note: '原子发布新版本' });
    } catch (e) {
      actives.forEach(function (t) { t.status = '生效'; t.retiredAt = ''; });
      draft.status = '草稿';
      return { ok: false, msg: '发布失败，已回滚；旧版本继续生效', published: false };
    }
    audit('业务配置', code, '立即发布（B 类）', '旧版本', code + ' ' + draft.version);
    save();
    return { ok: true, published: true, draft: draft, msg: '已原子发布 ' + draft.version + '；历史商机继续按原版本解释' };
  }
  /* 恢复旧版本＝基于旧版本复制出一个新草稿，再用正常发布流程生效；不做版本指针回拨。 */
  function templateRestore(code, version) {
    load();
    var src = template(code, version);
    if (!src) return { ok: false, msg: '目标版本不存在' };
    if (src.status === '生效') return { ok: false, msg: '该版本已是生效版本' };
    if (src.status === '草稿') return { ok: false, msg: '该版本已是草稿，直接编辑即可' };
    var list = arr('templates');
    if (list.filter(function (t) { return t.code === code && t.status === '草稿'; }).length) {
      return { ok: false, msg: '已存在草稿版本，请先发布或删除后再恢复旧版本' };
    }
    var act = list.filter(function (t) { return t.code === code && t.status === '生效'; })[0];
    var next = 'v' + (parseInt(String((act && act.version) || version).replace(/^v/i, ''), 10) + 1);
    var copy = JSON.parse(JSON.stringify(src));
    copy.version = next; copy.status = '草稿'; copy.publishedAt = '';
    copy.note = '由 ' + version + ' 复制生成的新草稿（恢复旧版本）';
    copy.history = [{ version: next, at: stamp(), by: me().id, action: '从 ' + version + ' 复制为新草稿', note: copy.note }];
    list.unshift(copy);
    audit('业务配置', code, '恢复旧版本（复制为新草稿）', version, next);
    save();
    return { ok: true, draft: copy, msg: '已从 ' + version + ' 复制出草稿 ' + next + '，请校验后发布' };
  }

  function configA(key) {
    load();
    if (key === 'cusPool') return db.cusPoolRule;
    if (key === 'regions') return db.regionRules;
    if (key === 'dict') return db.dicts;
    if (key === 'customFields') return db.customFields;
    if (key === 'leadPool') return db.leadPools;
    if (key === 'agentConfig') return db.agentConfig;
    return null;
  }
  /* A 类配置：保存即生效并留历史，不建设审批与未来定时生效。 */
  function configASave(key, patch, reason) {
    load();
    var o = configA(key); if (!o) return { ok: false, msg: '配置不存在' };
    var target = Array.isArray(o) ? o[0] : o;
    var before = JSON.parse(JSON.stringify(patch ? Object.keys(patch).reduce(function (a, k) { a[k] = (Array.isArray(o) ? o[0] : o)[k]; return a; }, {}) : {}));
    Object.keys(patch || {}).forEach(function (k) { if (patch[k] !== undefined) target[k] = patch[k]; });
    target.history = target.history || [];
    target.history.push({ at: stamp(), by: me().id, action: '修改配置', from: JSON.stringify(before), to: JSON.stringify(patch), reason: reason || '' });
    audit('业务配置', key, '保存生效（A 类）', JSON.stringify(before), JSON.stringify(patch));
    save();
    return { ok: true, saved: target };
  }
  /* 数组型 A 类配置（区域规则、自定义字段、线索池）按条目定位保存。
     configASave 只能表达「单对象」型配置；数组型若沿用它会固定改写第 0 条，
     因此这里单独按 code／id 定位到具体条目，并且新增与删除同样留历史。 */
  function configAItem(key, code, patch, reason) {
    load();
    var o = configA(key);
    if (!Array.isArray(o)) return { ok: false, msg: '该配置不是数组型配置，请使用保存生效' };
    var item = code ? o.filter(function (x) { return x.id === code || x.code === code; })[0] : null;
    if (code && !item) return { ok: false, msg: '配置项不存在：' + code };
    var isNew = !item;
    if (isNew) {
      item = {};
      var id = (patch && (patch.id || patch.code)) || code;
      if (id) item.id = id;
      o.push(item);
    }
    var before = {};
    Object.keys(patch || {}).forEach(function (k) { if (!isNew) before[k] = item[k]; });
    Object.keys(patch || {}).forEach(function (k) { if (patch[k] !== undefined) item[k] = patch[k]; });
    item.history = item.history || [];
    item.history.push({
      at: stamp(), by: me().id, action: isNew ? '新增配置项' : '修改配置项',
      from: JSON.stringify(before), to: JSON.stringify(patch), reason: reason || ''
    });
    audit('业务配置', key + '｜' + (code || item.code || ''), isNew ? '新增（A 类）' : '保存生效（A 类）',
      JSON.stringify(before), JSON.stringify(patch));
    save();
    return { ok: true, item: item, isNew: isNew };
  }
  function configARemove(key, code, reason) {
    load();
    var o = configA(key);
    if (!Array.isArray(o)) return { ok: false, msg: '该配置不是数组型配置' };
    var idx = -1;
    o.forEach(function (x, i) { if (x.id === code || x.code === code) idx = i; });
    if (idx < 0) return { ok: false, msg: '配置项不存在：' + code };
    var removed = o.splice(idx, 1)[0];
    audit('业务配置', key + '｜' + code, '删除配置项（A 类）', (removed.name || code), '', reason || '');
    save();
    return { ok: true, removed: removed };
  }
  /* B 类规则草稿保存：只改草稿版本；生效版本与在途对象不受影响。 */
  function configBSaveDraft(key, id, patch, reason) {
    load();
    var item = find(key, id);
    if (!item) return { ok: false, msg: '规则不存在' };
    if (item.status !== '草稿') return { ok: false, msg: '只有草稿版本可以编辑；生效与历史版本只读' };
    var before = {};
    Object.keys(patch || {}).forEach(function (k) { before[k] = item[k]; });
    Object.keys(patch || {}).forEach(function (k) { if (patch[k] !== undefined) item[k] = patch[k]; });
    item.history = item.history || [];
    item.history.push({ version: item.version, at: stamp(), by: me().id, action: '保存草稿', note: reason || '' });
    audit('业务配置', key + '｜' + (item.code || id), '保存草稿（B 类）', JSON.stringify(before), JSON.stringify(patch));
    save();
    return { ok: true, item: item, msg: '草稿已保存，发布后才会生效' };
  }
  function configBList(key) { return arr(key); }
  function configBValidate(key, id) {
    load();
    var item = find(key, id); if (!item) return { ok: false, msg: '规则不存在' };
    var errs = [];
    if (!item.name) errs.push('规则名称必填');
    if (key === 'visitRules') {
      if (!(item.radius > 0)) errs.push('签到半径必须大于 0');
      if (!(item.accuracy > 0)) errs.push('定位精度阈值必须大于 0');
    }
    if (key === 'taskRules') {
      if (!item.sourceRule) errs.push('来源规则必填');
      if (!item.acceptorRule) errs.push('验收人解析规则必填');
    }
    save();
    return { ok: errs.length === 0, errors: errs, msg: errs.length ? errs.join('；') : '校验通过' };
  }
  /* B 类：立即原子发布新版本；发布失败不能部分生效，旧版本继续生效，草稿保留。 */
  function configBPublish(key, id) {
    load();
    var item = find(key, id); if (!item) return { ok: false, msg: '规则不存在' };
    var v = configBValidate(key, id);
    if (!v.ok) return { ok: false, msg: '校验未通过：' + v.msg, errors: v.errors, published: false };
    var list = arr(key);
    var code = item.code.replace(/-V\d+.*$/, '');
    var actives = list.filter(function (x) { return x.code.indexOf(code) === 0 && x.status === '生效'; });
    try {
      actives.forEach(function (x) { x.status = '历史'; x.retiredAt = stamp(); });
      item.status = '生效'; item.publishedAt = stamp(); item.publisher = me().id;
      item.version = item.version.replace('（草稿）', '');
      item.history.push({ version: item.version, at: stamp(), by: me().id, action: '立即发布', note: '原子发布新版本' });
    } catch (e) {
      /* 发布失败：回滚到发布前状态，不允许部分生效。 */
      actives.forEach(function (x) { x.status = '生效'; x.retiredAt = ''; });
      item.status = '草稿';
      return { ok: false, msg: '发布失败，已回滚；旧版本继续生效', published: false };
    }
    audit('业务配置', id, '立即发布（B 类）', code + ' 旧版本', code + ' ' + item.version);
    save();
    return { ok: true, published: true, item: item, msg: '已原子发布 ' + item.version + '；历史对象继续按原版本解释' };
  }
  function metricDefList() { return arr('metrics'); }
  function metricVersionList(code) {
    load();
    var list = arr('metricVersions');
    return code ? list.filter(function (v) { return v.code === code; }) : list;
  }
  function metricDraftSave(code, patch, reason) {
    load();
    var m = metric(code); if (!m) return { ok: false, msg: '指标不存在' };
    var nextV = 'V' + (parseInt((m.version || 'V1').slice(1), 10) + 1);
    var draft = arr('metricVersions').filter(function (v) { return v.code === code && v.status === '草稿'; })[0];
    if (!draft) {
      draft = { id: 'MV-D' + (arr('metricVersions').length + 1), code: code, version: nextV, status: '草稿',
        publishedAt: '', effectiveAt: '', retiredAt: '', publisher: me().id, change: reason || '调整口径', note: '' };
      db.metricVersions.unshift(draft);
    }
    Object.keys(patch || {}).forEach(function (k) { if (patch[k] !== undefined) draft[k] = patch[k]; });
    draft.change = (patch && patch.change) || draft.change;
    audit('指标配置', code, '保存草稿', '', draft.version);
    save();
    return { ok: true, draft: draft, msg: '已保存草稿 ' + draft.version };
  }
  function metricValidate(code) {
    load();
    var draft = arr('metricVersions').filter(function (v) { return v.code === code && v.status === '草稿'; })[0];
    if (!draft) return { ok: false, msg: '没有待发布的草稿版本' };
    var errs = [];
    if (!draft.change) errs.push('变更说明必填');
    save();
    return { ok: errs.length === 0, errors: errs, msg: errs.length ? errs.join('；') : '校验通过' };
  }
  /* 指标轻量 B 类：草稿 → 校验 → 立即发布 → 旧版本转历史；跨版本不计算环比。 */
  function metricPublish(code) {
    load();
    var v = metricValidate(code);
    if (!v.ok) return { ok: false, msg: v.msg, errors: v.errors };
    var draft = arr('metricVersions').filter(function (x) { return x.code === code && x.status === '草稿'; })[0];
    var m = metric(code);
    var old = arr('metricVersions').filter(function (x) { return x.code === code && x.status === '生效'; });
    try {
      old.forEach(function (x) { x.status = '历史'; x.retiredAt = stamp(); });
      draft.status = '生效'; draft.publishedAt = stamp(); draft.effectiveAt = stamp(); draft.publisher = me().id;
      if (m) { m.version = draft.version; m.publishedAt = draft.publishedAt; }
    } catch (e) {
      old.forEach(function (x) { x.status = '生效'; x.retiredAt = ''; });
      draft.status = '草稿';
      return { ok: false, msg: '发布失败，已回滚；旧版本继续生效' };
    }
    audit('指标配置', code, '立即发布', '', draft.version + '｜' + draft.change);
    save();
    return { ok: true, draft: draft, msg: '已发布 ' + draft.version + '；历史数据不自动重算' };
  }

  /* ==================================================== 审计（07/08） */

  function auditList(filter) {
    var list = arr('audits');
    filter = filter || {};
    if (filter.objectType) list = list.filter(function (a) { return a.objectType === filter.objectType; });
    if (filter.source) list = list.filter(function (a) { return a.source === filter.source; });
    if (filter.actor) list = list.filter(function (a) { return a.actor === filter.actor; });
    if (filter.q) {
      var s = filter.q.toLowerCase();
      list = list.filter(function (a) { return (a.action + a.objectType + a.objectId + (a.from || '') + (a.to || '')).toLowerCase().indexOf(s) >= 0; });
    }
    return list;
  }

  return {
    KEY: KEY, load: load, save: save, reset: reset, now: now, today: today, addDays: addDays,
    nextId: nextId, month: month,
    role: role, setRole: setRole, currentUser: currentUser, user: user, userName: userName,
    all: all, find: find, customer: customer, contact: contact, store: store, lead: lead, opp: opp, job: job,
    template: template, templateByKey: templateByKey, currentTemplate: currentTemplate, currentStage: currentStage,
    stageIndex: stageIndex, customField: customField, regionName: regionName, businessLineName: businessLineName,
    scenarioOptions: scenarioOptions, scenarioByLine: scenarioByLine, matchTemplate: matchTemplate, matchReason: matchReason,
    pendingGovernance: pendingGovernance, relationsOf: relationsOf, activeRelationsOf: activeRelationsOf,
    createCustomer: createCustomer, createCustomerWithInitialRelation: createCustomerWithInitialRelation,
    ownerRegionOptions: ownerRegionOptions, updateCustomer: updateCustomer, setCustomerValue: setCustomerValue,
    setCustomerIdentity: setCustomerIdentity, submitGroupCandidate: submitGroupCandidate, confirmGroupCandidate: confirmGroupCandidate,
    reviewCustomerValue: reviewCustomerValue, submitHighImpact: submitHighImpact, handleException: handleException,
    createContact: createContact, addContactRelation: addContactRelation, createStore: createStore, updateStore: updateStore,
    createAddress: createAddress, removeAddress: removeAddress,
    poolRecords: poolRecords, claimPool: claimPool, assignPool: assignPool, releasePool: releasePool,
    recyclePool: recyclePool, addCollaborator: addCollaborator, stopOperating: stopOperating,
    createRelation: createRelation, relationPrecheck: relationPrecheck,
    relationHoldCount: relationHoldCount, userQualified: userQualified, RELATION_HOLD_LIMIT: RELATION_HOLD_LIMIT,
    relationCandidates: relationCandidates, relationOwnerPrecheck: relationOwnerPrecheck,
    assignRelationOwner: assignRelationOwner, transferRelation: transferRelation,
    createLead: createLead, updateLead: updateLead, leadAction: leadAction, convertLead: convertLead, poolOf: poolOf,
    createOpportunity: createOpportunity, gateCheck: gateCheck, advanceStage: advanceStage, rollbackStage: rollbackStage,
    changeMainLine: changeMainLine, sleepOpp: sleepOpp, resumeOpp: resumeOpp, closeOpp: closeOpp, reopenOpp: reopenOpp,
    splitLine: splitLine, addTeamMember: addTeamMember, removeTeamMember: removeTeamMember, reassignOwner: reassignOwner,
    updateStageTask: updateStageTask, generateStageTasks: generateStageTasks,
    addJob: addJob, updateJob: updateJob, retryFailed: retryFailed,
    markMessageRead: markMessageRead, markAllMessagesRead: markAllMessagesRead, audit: audit,
    listState: listState, selection: selection, uiState: uiState,
    setUser: setUser, arr: arr, isTeamScope: isTeamScope, inTeamOf: inTeamOf,
    /* 任务 */
    tasks: tasks, task: task, taskAct: taskAct, taskOverdue: taskOverdue, taskSoon: taskSoon,
    taskDaysLeft: taskDaysLeft, taskRemindWindow: taskRemindWindow, taskAcceptor: taskAcceptor,
    createTask: createTask, batchTaskAccept: batchTaskAccept,
    /* 销售活动 */
    activityList: activityList, activity: activity, createActivity: createActivity, correctActivity: correctActivity,
    /* 正式拜访 */
    visitList: visitList, visit: visit, createVisit: createVisit, visitCheckIn: visitCheckIn,
    visitCheckOut: visitCheckOut, visitReview: visitReview, batchVisitReview: batchVisitReview,
    /* 统一日程 */
    scheduleList: scheduleList, sched: sched, createSchedule: createSchedule, updateSchedule: updateSchedule,
    cancelSchedule: cancelSchedule, deleteSchedule: deleteSchedule, scheduleToTask: scheduleToTask,
    calendarEvents: calendarEvents,
    /* 日报 */
    reportList: reportList, report: report, reportDraftOf: reportDraftOf, saveReportDraft: saveReportDraft,
    submitReport: submitReport, addReportAdvice: addReportAdvice, markReportRead: markReportRead,
    /* Agent */
    candidateList: candidateList, candidate: candidate, candidateConfirm: candidateConfirm,
    candidateIgnore: candidateIgnore, candidateBatchConfirm: candidateBatchConfirm,
    candidateRetryWrite: candidateRetryWrite, agentRunList: agentRunList,
    /* 知识 */
    knowledgeList: knowledgeList, kb: kb, knowledgeInPublishScope: knowledgeInPublishScope,
    knowledgePublish: knowledgePublish, knowledgeDeactivate: knowledgeDeactivate,
    /* 消息投递 */
    deliveryList: deliveryList, retryDelivery: retryDelivery,
    /* 集成与同步 */
    extSystems: extSystems, syncList: syncList, retrySync: retrySync,
    /* 异常事项与数据质量 */
    exceptionList: exceptionList, exceptionClaim: exceptionClaim, exceptionReturn: exceptionReturn,
    exceptionComplete: exceptionComplete, exceptionReject: exceptionReject,
    qualityIssueList: qualityIssueList, qualityIgnore: qualityIgnore, qualityRerun: qualityRerun,
    /* 人员、权限与移交 */
    peopleList: peopleList, permPendingList: permPendingList, permPendingAct: permPendingAct,
    handoverList: handoverList, handover: handover, handoverPrecheck: handoverPrecheck, handoverRun: handoverRun,
    peopleSyncList: peopleSyncList, peopleSyncAct: peopleSyncAct,
    /* 指标与配置 */
    METRIC_THEMES: METRIC_THEMES, metric: metric, metricRange: metricRange, metricValue: metricValue,
    metricBoard: metricBoard, metricDrill: metricDrill, metricInjectFail: metricInjectFail,
    metricDefList: metricDefList, metricVersionList: metricVersionList, metricDraftSave: metricDraftSave,
    metricValidate: metricValidate, metricPublish: metricPublish,
    configA: configA, configASave: configASave, configAItem: configAItem,
    configARemove: configARemove, configBList: configBList, configBSaveDraft: configBSaveDraft,
    configBValidate: configBValidate, configBPublish: configBPublish,
    flowTemplates: flowTemplates, templateDraftSave: templateDraftSave,
    templateValidate: templateValidate, templatePublish: templatePublish, templateRestore: templateRestore,
    /* 审计 */
    auditList: auditList
  };
})();
