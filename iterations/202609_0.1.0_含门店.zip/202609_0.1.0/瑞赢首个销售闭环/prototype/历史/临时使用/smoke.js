/* 冒烟：确认 Chrome + CDP 能打开 file:// 原型页面 */
'use strict';
const { Browser } = require('./cdp.js');
const path = require('path');

(async () => {
  const b = await Browser.launch({});
  console.log('Chrome:', b.version.Browser, '| Protocol', b.version['Protocol-Version']);
  const p = await b.newPage();
  await p.enable();
  await p.goto('file://' + path.resolve(__dirname, '..', 'index.html'), 1500);
  const info = await p.evaluate(
    "return { title: document.title, w: window.innerWidth, h: window.innerHeight, " +
    "bodyText: (document.body.innerText || '').replace(/\\s+/g, ' ').slice(0, 140), " +
    "session: (function(){ try { sessionStorage.setItem('t','1'); return sessionStorage.getItem('t') === '1' ? '可用' : '读写异常'; } catch (e) { return '不可用:' + e.message; } })(), " +
    "ry: typeof window.RY + ' [' + (window.RY ? Object.keys(window.RY).join(',') : '') + ']', " +
    "manifest: (window.RY && window.RY.manifest) ? JSON.stringify(window.RY.manifest.verify()) : '未加载', " +
    "manifestApi: (window.RY && window.RY.manifest) ? Object.keys(window.RY.manifest).join(',') : '', " +
    "storeApi: (window.RY && window.RY.store) ? Object.keys(window.RY.store).length + ' 个' : '', " +
    "permApi: (window.RY && window.RY.perm) ? Object.keys(window.RY.perm).join(',') : '' };"
  );
  console.log(JSON.stringify(info, null, 2));
  console.log('errors:', JSON.stringify(p.errors(), null, 2));
  await b.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
