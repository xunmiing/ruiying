/* ==========================================================================
 * 深链检查：先用遍历收集原型自己渲染出来的每一个 (页面, query) 组合，
 * 再逐个真实打开，检查运行时异常、横向溢出、断链与鉴权降级。
 * 这一步才能覆盖「带参数的详情页/多入口页面」——默认入口往往掩盖了
 * 只在 ?kind=／?id= 分支里才会渲染出来的坏链接。
 * 用法：node 临时使用/deep-check.js
 * ========================================================================== */
'use strict';
const { Browser } = require('./cdp.js');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
const sandbox = { window: {}, RY: {} };
sandbox.window.RY = sandbox.RY;
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(ROOT, 'assets/js/page-manifest.js'), 'utf8'), sandbox, { filename: 'pm.js' });
const ROWS = sandbox.RY.manifest.list;

const COLLECT = `
  var out = [];
  document.querySelectorAll('a[href]').forEach(function (a) {
    var h = a.getAttribute('href');
    if (!h || /^(https?:|mailto:|tel:|javascript:|data:|#)/i.test(h)) return;
    if (/[\\'"+]/.test(h)) return;
    var hash = h.indexOf('#') >= 0 ? h.slice(h.indexOf('#')) : '';
    var noHash = h.split('#')[0];
    var q = noHash.indexOf('?');
    var file = q >= 0 ? noHash.slice(0, q) : noHash;
    var query = q >= 0 ? noHash.slice(q) : '';
    if (!/\\.html$/i.test(file)) return;
    out.push({ file: file, query: query + hash });
  });
  return out;
`;

const PROBE = `
  var out = { text: (document.body.innerText || '').replace(/\\s+/g, ' ').trim() };
  var de = document.documentElement;
  out.docScrollW = de.scrollWidth;
  out.w = window.innerWidth;
  function scrollableAncestor(el) {
    var n = el.parentElement;
    while (n && n !== document.body) {
      var ox = getComputedStyle(n).overflowX;
      if (ox === 'auto' || ox === 'scroll' || ox === 'hidden') return true;
      n = n.parentElement;
    }
    return false;
  }
  var over = [];
  document.querySelectorAll('*').forEach(function (el) {
    var r = el.getBoundingClientRect();
    if (r.width <= 0 && r.height <= 0) return;
    if (r.right > window.innerWidth + 2 && !scrollableAncestor(el)) {
      over.push(el.tagName.toLowerCase() + '.' + String(el.className || '').slice(0, 40) + '(right=' + Math.round(r.right) + ')');
    }
  });
  out.overflow = over.slice(0, 6);
  var bad = [];
  document.querySelectorAll('a[href]').forEach(function (a) {
    var h = a.getAttribute('href');
    if (!h || /^(https?:|mailto:|tel:|javascript:|data:|#)/i.test(h)) return;
    if (/[\\'"+]/.test(h)) return;
    if (!h.split('#')[0].split('?')[0]) return;
    bad.push({ href: h, text: (a.innerText || '').replace(/\\s+/g, ' ').slice(0, 30) });
  });
  out.links = bad;
  out.hasState = !!document.querySelector('.ry-state');
  out.stateTitle = (function () { var e = document.querySelector('.ry-state'); return e ? (e.innerText || '').replace(/\\s+/g, ' ').slice(0, 70) : ''; })();
  return out;
`;

(async () => {
  const browser = await Browser.launch({});
  const page = await browser.newPage();
  await page.enable();

  /* ---------- 第一遍：收集深链 ---------- */
  const pairs = new Map();          /* 'relpath|query' -> true */
  for (const row of ROWS) {
    await page.viewport(row.end === 'H5' ? 430 : 1440, 900);
    await page.goto('file://' + path.join(ROOT, row.path), 650);
    let links;
    try { links = await page.evaluate(COLLECT); } catch (e) { continue; }
    for (const l of links) {
      const clean = l.file.split('?')[0];
      const target = path.resolve(path.dirname(path.join(ROOT, row.path)), clean);
      if (!fs.existsSync(target)) continue;
      const rel = path.relative(ROOT, target);
      if (!/\.html?$/i.test(rel)) continue;
      pairs.set(rel + '|' + l.query, { rel: rel, query: l.query });
    }
    process.stdout.write('.');
  }
  console.log('\n收集到深链 ' + pairs.size + ' 个（不含默认入口）');

  /* ---------- 第二遍：逐个打开 ---------- */
  const problems = [];
  let n = 0;
  for (const p of pairs.values()) {
    n++;
    const isH5 = p.rel.indexOf('h5/') === 0;
    const vps = isH5 ? [{ w: 430, h: 900 }] : [{ w: 1280, h: 800 }, { w: 1440, h: 900 }];
    for (const vp of vps) {
      await page.viewport(vp.w, vp.h);
      let probe;
      try {
        await page.goto('file://' + path.join(ROOT, p.rel) + p.query, 750);
        probe = await page.evaluate(PROBE);
      } catch (e) {
        problems.push({ page: p.rel + p.query, vp: vp.w, kind: 'ERROR', detail: '求值失败：' + e.message });
        continue;
      }
      const errs = page.errors();
      const tag = p.rel + p.query;
      errs.js.forEach(e => problems.push({ page: tag, vp: vp.w, kind: 'ERROR', detail: 'JS 异常：' + String(e.text).split('\n')[0].slice(0, 200) }));
      errs.console.forEach(e => problems.push({ page: tag, vp: vp.w, kind: 'ERROR', detail: 'console.error：' + String(e).slice(0, 180) }));
      if (probe.text.length < 80) problems.push({ page: tag, vp: vp.w, kind: 'ERROR', detail: '可见内容过少（' + probe.text.length + ' 字）：' + probe.text.slice(0, 60) });
      if (probe.overflow.length) problems.push({ page: tag, vp: vp.w, kind: 'ERROR', detail: '横向溢出：' + probe.overflow.join('｜') });
      const bad = [];
      for (const l of probe.links) {
        const clean = l.href.split('#')[0].split('?')[0];
        if (!clean) continue;
        const target = path.resolve(path.dirname(path.join(ROOT, p.rel)), clean);
        if (!fs.existsSync(target)) bad.push(l.href + '（' + l.text + '）');
      }
      if (bad.length) problems.push({ page: tag, vp: vp.w, kind: 'ERROR', detail: '断链：' + bad.slice(0, 4).join('；') });
    }
    if (n % 20 === 0) process.stdout.write('[' + n + ']');
  }
  await browser.close();

  const errs = problems.filter(x => x.kind === 'ERROR');
  console.log('\n\n================ 深链检查结果 ================');
  console.log('深链 ' + pairs.size + ' 个｜断言 ' + problems.length + ' 条｜ERROR ' + errs.length + ' 项');
  const seen = new Set();
  errs.forEach(f => {
    const k = f.page + '|' + f.detail.slice(0, 60);
    if (seen.has(k)) return;
    seen.add(k);
    console.log('  [' + f.vp + '] ' + f.page + '：' + f.detail);
  });
  fs.writeFileSync(path.join(__dirname, 'deep-check-result.json'), JSON.stringify({ pairs: pairs.size, problems }, null, 2));
  console.log('\n明细已写入 临时使用/deep-check-result.json');
  process.exit(errs.length ? 1 : 0);
})().catch(e => { console.error('检查未完成：' + e.message); process.exit(2); });
