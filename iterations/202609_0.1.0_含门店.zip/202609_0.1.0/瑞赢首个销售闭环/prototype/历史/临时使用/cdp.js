/* ==========================================================================
 * 极简 CDP 驱动（零依赖）：用本机 Chrome + Node 内置 WebSocket 打开 file:// 页面
 * 供 browser-check.js 复用。
 * ========================================================================== */
'use strict';

const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

class Browser {
  constructor(port, proc, userDir) {
    this.port = port; this.proc = proc; this.userDir = userDir;
  }

  static async launch(opts) {
    opts = opts || {};
    const port = opts.port || (9200 + Math.floor(Math.random() * 500));
    const userDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ry-cdp-'));
    const args = [
      '--headless=new',
      '--remote-debugging-port=' + port,
      '--user-data-dir=' + userDir,
      '--no-first-run', '--no-default-browser-check',
      '--disable-extensions', '--disable-background-networking',
      '--disable-gpu', '--hide-scrollbars',
      '--allow-file-access-from-files',
      '--window-size=1440,900',
      'about:blank'
    ];
    const proc = spawn(CHROME, args, { stdio: ['ignore', 'ignore', 'pipe'] });
    let stderr = '';
    proc.stderr.on('data', d => { stderr += String(d); });

    /* 等 DevTools 端口就绪 */
    let version = null;
    for (let i = 0; i < 100; i++) {
      await sleep(150);
      try {
        const r = await fetch(`http://127.0.0.1:${port}/json/version`);
        if (r.ok) { version = await r.json(); break; }
      } catch (e) { /* 还没起来 */ }
    }
    if (!version) {
      try { proc.kill('SIGKILL'); } catch (e) {}
      throw new Error('Chrome DevTools 端口未就绪。stderr 片段：' + stderr.slice(-500));
    }
    const b = new Browser(port, proc, userDir);
    b.version = version;
    return b;
  }

  async close() {
    try { await fetch(`http://127.0.0.1:${this.port}/json/close/${this.pageId}`); } catch (e) {}
    try { this.proc.kill('SIGKILL'); } catch (e) {}
    await sleep(200);
    try { fs.rmSync(this.userDir, { recursive: true, force: true }); } catch (e) {}
  }

  async newPage() {
    const r = await fetch(`http://127.0.0.1:${this.port}/json/new?about:blank`, { method: 'PUT' });
    const t = await r.json();
    const page = new Page(this, t.id, t.webSocketDebuggerUrl);
    await page.connect();
    return page;
  }
}

class Page {
  constructor(browser, id, wsUrl) {
    this.browser = browser; this.pageId = id; this.wsUrl = wsUrl;
    this.seq = 0; this.pending = new Map();
    this.events = []; this.listeners = {};
  }

  connect() {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(this.wsUrl);
      this.ws = ws;
      ws.addEventListener('message', ev => {
        let msg;
        try { msg = JSON.parse(ev.data); } catch (e) { return; }
        if (msg.id && this.pending.has(msg.id)) {
          const { resolve: res, reject: rej } = this.pending.get(msg.id);
          this.pending.delete(msg.id);
          if (msg.error) rej(new Error(msg.method + ' → ' + JSON.stringify(msg.error)));
          else res(msg.result);
          return;
        }
        if (msg.method) {
          this.events.push(msg);
          (this.listeners[msg.method] || []).forEach(fn => fn(msg.params));
        }
      });
      ws.addEventListener('error', e => reject(new Error('WebSocket 错误')));
      ws.addEventListener('open', () => resolve());
    });
  }

  on(method, fn) {
    (this.listeners[method] = this.listeners[method] || []).push(fn);
  }

  send(method, params) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params: params || {} }));
      setTimeout(() => {
        if (this.pending.has(id)) {
          this.pending.delete(id);
          reject(new Error(method + ' 超时'));
        }
      }, 30000);
    });
  }

  async enable() {
    this.on('Runtime.exceptionThrown', p => {
      const d = p.exceptionDetails || {};
      this.jsErrors.push({
        text: (d.exception && (d.exception.description || d.exception.value)) || d.text || '未知异常',
        line: d.lineNumber, url: d.url
      });
    });
    this.on('Runtime.consoleAPICalled', p => {
      if (p.type === 'error') {
        this.consoleErrors.push((p.args || []).map(a => a.value !== undefined ? a.value : (a.description || a.type)).join(' '));
      }
    });
    this.on('Log.entryAdded', p => {
      const e = p.entry || {};
      if (e.level === 'error') this.logErrors.push(e.text + (e.url ? ' @' + e.url : ''));
    });
    this.jsErrors = []; this.consoleErrors = []; this.logErrors = [];
    await this.send('Runtime.enable');
    await this.send('Page.enable');
    await this.send('Log.enable');
  }

  async viewport(width, height) {
    await this.send('Emulation.setDeviceMetricsOverride', {
      width, height, deviceScaleFactor: 1, mobile: width < 600
    });
  }

  async goto(url, waitMs) {
    this.jsErrors = []; this.consoleErrors = []; this.logErrors = [];
    await this.send('Page.navigate', { url });
    await this.waitLoad(waitMs || 900);
  }

  waitLoad(ms) {
    return new Promise(resolve => {
      let done = false;
      const finish = () => { if (!done) { done = true; resolve(); } };
      const h = () => finish();
      this.on('Page.loadEventFired', h);
      setTimeout(finish, ms);
    });
  }

  /* 在页面里求值；返回 JSON 化结果 */
  async evaluate(expr) {
    const r = await this.send('Runtime.evaluate', {
      expression: '(function(){' + expr + '})()',
      returnByValue: true, awaitPromise: true
    });
    if (r.exceptionDetails) {
      const d = r.exceptionDetails;
      throw new Error('页面求值异常：' + ((d.exception && d.exception.description) || d.text));
    }
    return r.result.value;
  }

  errors() {
    return {
      js: this.jsErrors.slice(),
      console: this.consoleErrors.slice(),
      log: this.logErrors.slice()
    };
  }
}

module.exports = { Browser, sleep, CHROME };
