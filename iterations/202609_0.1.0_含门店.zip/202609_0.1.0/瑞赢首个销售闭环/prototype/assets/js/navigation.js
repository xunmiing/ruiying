/* ==========================================================================
 * 瑞赢 0.1 · 原型外壳（navigation.js）
 * --------------------------------------------------------------------------
 * 职责：
 *   PC —— 渲染统一 PC 外壳：左侧五组导航、顶部全局入口（搜索、消息、处理记录、
 *         用户头像）、面包屑与页面标题区。
 *   H5 —— 渲染企业微信 H5 外壳：顶部条、底部五个高频入口、演示身份入口。
 *
 * 说明：PC 只有一个统一入口与一套导航，不再区分销售端／主管端／配置端。
 *       H5 与 PC 共用同一业务事实、权限与数据范围，只是执行端不同。
 *       所有相对路径由 data-root 统一解析，保证页面能通过本地 file:// 直接打开。
 * ========================================================================== */
window.RY = window.RY || {};

RY.nav = (function () {
  'use strict';

  var ui = function () { return RY.ui; };

  function root() {
    var a = document.body.getAttribute('data-root');
    return a === null ? '' : a;
  }

  function href(path) { return root() + path; }

  function go(path) { window.location.href = href(path); }

  function isH5() { return document.body.getAttribute('data-end') === 'h5'; }

  /* ====================================================== PC 左侧导航 */

  function navItem(it, activeKey) {
    if (it.disabled) {
      return '<span class="ry-nav__item is-off" title="不在 0.1 范围内">' + ui().esc(it.name) + '<i class="ry-nav__off">不在 0.1 范围</i></span>';
    }
    if (it.allowed === false) {
      return '<span class="ry-nav__item is-off" title="当前身份无该页面权限">' + ui().esc(it.name) + '<i class="ry-nav__off">无页面权限</i></span>';
    }
    return '<a class="ry-nav__item' + (it.key === activeKey ? ' is-on' : '') + '" href="' + href(it.href) + '">' + ui().esc(it.name) + '</a>';
  }

  function sideHtml(activeKey) {
    var tree = RY.perm.visibleNav();
    var groups = tree.map(function (g) {
      var body;
      if (g.groups) {
        body = g.groups.map(function (gr) {
          var hasOn = gr.items.some(function (i) { return i.allowed !== false && !i.disabled; });
          return '<div class="ry-nav__sub' + (hasOn ? '' : ' is-off') + '">' +
            '<div class="ry-nav__subtitle">' + ui().esc(gr.name) + '</div>' +
            gr.items.map(function (i) { return navItem(i, activeKey); }).join('') + '</div>';
        }).join('');
      } else {
        body = g.items.map(function (i) { return navItem(i, activeKey); }).join('');
      }
      return '<div class="ry-nav__group' + (g.allowed === false ? ' is-off' : '') + '">' +
        '<div class="ry-nav__title">' + ui().esc(g.name) + '</div>' + body + '</div>';
    }).join('');

    var u = RY.store.currentUser();
    var role = RY.perm.ROLES[u.role] || RY.perm.ROLES.R1;
    return '<div class="ry-brand"><span class="ry-brand__mark">瑞</span>' +
        '<span class="ry-brand__txt"><b>瑞赢</b><i>0.1 联合评审原型</i></span></div>' +
      '<nav class="ry-nav">' + groups + '</nav>' +
      '<div class="ry-side__foot">' +
        '<div class="ry-side__user"><b>' + ui().esc(u.name) + '</b><span>' + role.name + ' · ' + ui().esc(u.dept) + '</span></div>' +
        '<button class="ry-btn ry-btn--ghost ry-btn--sm" id="ry-switch">切换评审身份 / 演示开关</button>' +
        '<p class="ry-side__note">原型仅用于评审页面结构与业务规则表达，不代表生产实现或技术承诺。</p>' +
      '</div>';
  }

  /* ====================================================== PC 顶部入口 */

  function topHtml() {
    var q = ui().q('q') || '';
    var unread = RY.store.arr('messages').filter(function (m) { return !m.read; }).length;
    var pending = RY.store.arr('jobs').filter(function (j) { return j.status === '处理中' || j.status === '部分成功'; }).length;
    var plain = RY.perm.canViewPlainPhone();
    return '<div class="ry-top__left">' +
        '<a class="ry-top__home" href="' + href('pc.html') + '">工作台首页</a>' +
      '</div>' +
      '<form class="ry-search" id="ry-topsearch" action="' + href('pc/search.html') + '" method="get">' +
        '<input type="search" name="q" placeholder="全局搜索：客户 / 联系人 / 门店 / 线索 / 商机 / 任务 / 正式拜访 / 日报 / 知识" value="' + ui().esc(q) + '">' +
        '<button type="submit" class="ry-search__btn">搜索</button>' +
      '</form>' +
      '<div class="ry-top__right">' +
        '<a class="ry-top__link" href="' + href('index.html') + '">企微 H5</a>' +
        '<a class="ry-top__link" href="' + href('pc/message/list.html') + '">消息' + (unread ? '<i class="ry-badge">' + unread + '</i>' : '') + '</a>' +
        '<a class="ry-top__link" href="' + href('pc/processing/list.html') + '">处理记录' + (pending ? '<i class="ry-badge">' + pending + '</i>' : '') + '</a>' +
        '<span class="ry-top__grant">' + (plain ? ui().tag('已授权查看明文', 'ok') : ui().tag('未授权查看明文', 'muted')) + '</span>' +
        '<button class="ry-avatar" id="ry-avatar" title="当前评审身份与演示开关">' + ui().esc(RY.store.currentUser().name.slice(0, 1)) + '</button>' +
      '</div>';
  }

  /* ====================================================== PC 页面标题 */

  function headHtml(cfg) {
    var crumbs = (cfg.crumbs || []).map(function (c, i) {
      var last = i === (cfg.crumbs.length - 1);
      return last ? '<span>' + ui().esc(c.label) + '</span>'
        : '<a href="' + href(c.href || 'pc.html') + '">' + ui().esc(c.label) + '</a><i>›</i>';
    }).join('');
    return '<div class="ry-head__main">' +
        '<div class="ry-crumbs">' + crumbs + '</div>' +
        '<h1 class="ry-title">' + ui().esc(cfg.title || '') +
          (cfg.titleNote ? '<span class="ry-title__note">' + ui().esc(cfg.titleNote) + '</span>' : '') + '</h1>' +
        (cfg.subtitle ? '<p class="ry-subtitle">' + cfg.subtitle + '</p>' : '') +
      '</div>' +
      '<div class="ry-head__actions" id="ry-head-actions">' + (cfg.actions || '') + '</div>';
  }

  function shell(cfg) {
    var s = ui().qs('#ry-side'), t = ui().qs('#ry-top'), h = ui().qs('#ry-head');
    if (s) s.innerHTML = sideHtml(cfg.nav || '');
    if (t) t.innerHTML = topHtml();
    if (h) h.innerHTML = headHtml(cfg);
    bindGlobal();
    ui().bindDenied(document.body);
    document.title = (cfg.title ? cfg.title + ' · ' : '') + '瑞赢 0.1 PC 原型';
  }

  /* ====================================================== H5 外壳 */

  /* 底部五个高频入口；第五项「更多」是「首页和工作入口」契约内的导航聚合，
     不是新增业务页面。无权限入口置灰并标注原因，不伪造入口。 */
  var H5_TABS = [
    { key: 'home', name: '工作台', href: 'index.html', page: 'h5.home' },
    { key: 'customer', name: '客户', href: 'h5/customer/list.html', page: 'h5.customer.list' },
    { key: 'lead', name: '线索', href: 'h5/lead/list.html', page: 'h5.lead.list' },
    { key: 'opp', name: '商机', href: 'h5/opportunity/list.html', page: 'h5.opp.list' },
    { key: 'more', name: '更多', href: 'h5/more.html', page: 'h5.more' }
  ];

  function tabbarHtml(activeKey) {
    return H5_TABS.map(function (t) {
      var allowed = RY.perm.page(t.page);
      if (!allowed) {
        return '<span class="ry-tabbar__it is-off" title="当前身份无该页面权限">' + ui().esc(t.name) + '</span>';
      }
      return '<a class="ry-tabbar__it' + (t.key === activeKey ? ' is-on' : '') + '" href="' + href(t.href) + '">' + ui().esc(t.name) + '</a>';
    }).join('');
  }

  /**
   * 渲染 H5 页面外壳。
   * cfg = { title, sub, back, nav, actions, tabbar, flush }
   */
  function h5shell(cfg) {
    var bar = ui().qs('#ry-hbar');
    if (bar) {
      var back = cfg.back === false ? '<span class="ry-bar__back is-off"></span>'
        : '<a class="ry-bar__back" href="' + (cfg.back ? href(cfg.back) : 'javascript:history.back()') + '" aria-label="返回">‹</a>';
      bar.innerHTML = back +
        '<div class="ry-bar__main"><div class="ry-bar__title">' + ui().esc(cfg.title || '') + '</div>' +
        (cfg.sub ? '<div class="ry-bar__sub">' + ui().esc(cfg.sub) + '</div>' : '') + '</div>' +
        '<div class="ry-bar__acts">' + (cfg.actions || '') +
          '<button class="ry-bar__ico" id="ry-hdemo" title="当前评审身份与演示开关">身</button></div>';
    }
    var tb = ui().qs('#ry-htabs');
    if (tb) {
      if (cfg.tabbar === false) tb.style.display = 'none';
      else tb.innerHTML = tabbarHtml(cfg.nav || '');
    }
    bindGlobal();
    ui().bindDenied(document.body);
    document.title = (cfg.title ? cfg.title + ' · ' : '') + '瑞赢 0.1 企微 H5 原型';
  }

  /* ====================================================== 全局绑定 */

  function bindGlobal() {
    var sw = ui().qs('#ry-switch');
    if (sw) sw.addEventListener('click', demoPanel);
    var av = ui().qs('#ry-avatar');
    if (av) av.addEventListener('click', demoPanel);
    var hd = ui().qs('#ry-hdemo');
    if (hd) hd.addEventListener('click', demoPanel);
  }

  /* ================================= 评审身份与演示开关（原型演示手段） */

  function demoPanel() {
    var u = RY.store.currentUser();
    var roleKeys = ['R1', 'R2', 'R3', 'R4', 'R5', 'R6'];
    var roles = roleKeys.map(function (k) {
      var r = RY.perm.ROLES[k];
      var users = RY.store.arr('users').filter(function (x) { return x.role === k; });
      var uname = users.length ? users[0].name : '（服务身份，无人工账号）';
      return '<label class="ry-roleopt' + (k === u.role ? ' is-on' : '') + '">' +
        '<input type="radio" name="ry-role" value="' + k + '"' + (k === u.role ? ' checked' : '') + '>' +
        '<span class="ry-roleopt__t"><b>' + r.code + ' ' + r.name + '</b><i>模拟身份：' + uname + '</i><em>' + r.desc + '</em></span>' +
        '</label>';
    }).join('');

    var caps = Object.keys(RY.perm.CAPS).map(function (k) {
      var c = RY.perm.CAPS[k];
      var owned = c.roles.indexOf(u.role) >= 0 || u.role === 'R5';
      return '<label class="ry-switch"><input type="checkbox" id="ry-cap-' + k + '"' +
        (RY.perm.cap(k) ? ' checked' : '') + (owned ? '' : ' disabled') + '>' +
        '<span>' + ui().esc(c.name) + '<i class="ry-hint-inline">' +
        (u.role === 'R5' ? 'R5 固定拥有' : (owned ? '可授予 ' + c.roles.join('／') : '当前身份不可授予')) + '</i></span></label>';
    }).join('');

    ui().drawer({
      title: '评审身份与演示开关',
      subtitle: '原型通过切换评审身份重新模拟授权结果；每次进入页面都会重新鉴权。所有开关仅用于演示状态表达，不代表生产配置。',
      size: 'md',
      body: '<div class="ry-demo">' +
        '<h4>当前数据范围</h4><p class="ry-hint">' + ui().esc(RY.perm.dataScope(u).label) + '</p>' +
        '<h4>评审身份</h4><div class="ry-roles">' + roles + '</div>' +
        '<p class="ry-hint">R6 是 Agent 服务身份，不是人工登录角色；其有效动作是调用用户权限与服务身份权限的交集。原型演示身份切换，不代表生产系统允许冒用身份。</p>' +
        '<h4>分析／配置能力项（permission-model.md §4.1）</h4>' + caps +
        '<p class="ry-hint">角色是默认权限集合，能力项才是服务端授权依据；不得默认 R3 拥有全部配置能力。汇总、下钻、明文、导出分别计算；配置查看、编辑、发布、启停分别计算。</p>' +
        '<h4>独立授权</h4>' +
        '<label class="ry-switch"><input type="checkbox" id="ry-g-plain"' + (RY.perm.grant('plain') ? ' checked' : '') + '><span>授予「联系人敏感信息明文查看」</span></label>' +
        '<label class="ry-switch"><input type="checkbox" id="ry-g-export"' + (RY.perm.grant('export') ? ' checked' : '') + '><span>授予「导出」独立授权</span></label>' +
        '<p class="ry-hint">导出与明文查看为两个互相独立的授权动作，获得其中一个不等于获得另一个。</p>' +
        '<h4>异常与降级演示</h4>' +
        '<label class="ry-switch"><input type="checkbox" id="ry-f-weak"' + (RY.perm.flag('weakNetwork') ? ' checked' : '') + '><span>弱网：首次提交失败、保留输入并可重试</span></label>' +
        '<label class="ry-switch"><input type="checkbox" id="ry-f-svc"' + (RY.perm.flag('serviceError') ? ' checked' : '') + '><span>外部服务不可用：工商查询 / 模板校验 / 同步失败降级</span></label>' +
        '<label class="ry-switch"><input type="checkbox" id="ry-f-conflict"' + (RY.perm.flag('conflict') ? ' checked' : '') + '><span>并发冲突：提交时版本已变化</span></label>' +
        '<h4>演示数据</h4>' +
        '<p class="ry-hint">演示状态保存在当前浏览器会话中（sessionStorage），包含新建、编辑、转换、批量与导入导出的结果。</p>' +
        '<button class="ry-btn ry-btn--danger" id="ry-reset">重置演示数据</button>' +
        '</div>',
      footer: '<button class="ry-btn" data-close>关闭</button>',
      onOpen: function (el) {
        ui().qsa('input[name=ry-role]', el).forEach(function (r) {
          r.addEventListener('change', function () {
            RY.store.setRole(r.value);
            ui().toast('已切换为 ' + RY.perm.ROLES[r.value].name + '，正在重新鉴权…', 'info');
            setTimeout(function () { window.location.reload(); }, 500);
          });
        });
        Object.keys(RY.perm.CAPS).forEach(function (k) {
          var cb = ui().qs('#ry-cap-' + k, el);
          if (!cb || cb.disabled) return;
          cb.addEventListener('change', function () {
            RY.perm.capSet(k, cb.checked);
            ui().toast('能力项「' + RY.perm.CAPS[k].name + '」已' + (cb.checked ? '授予' : '收回') + '，正在重新鉴权…', 'info');
            setTimeout(function () { window.location.reload(); }, 500);
          });
        });
        ['plain', 'export'].forEach(function (k) {
          var cb = ui().qs('#ry-g-' + k, el);
          if (cb) cb.addEventListener('change', function () { RY.perm.grant(k, cb.checked); ui().close(); window.location.reload(); });
        });
        var map = { weak: 'weakNetwork', svc: 'serviceError', conflict: 'conflict' };
        Object.keys(map).forEach(function (k) {
          var cb = ui().qs('#ry-f-' + k, el);
          if (cb) cb.addEventListener('change', function () { RY.perm.flag(map[k], cb.checked); ui().toast('演示开关已更新。', 'info'); });
        });
        ui().qs('#ry-reset', el).addEventListener('click', function () {
          ui().confirm({
            title: '重置演示数据',
            message: '将清除本次会话中所有新建、编辑、转换、批量与导入导出结果，恢复初始样例事实。此操作不可撤销。',
            confirmText: '确认重置',
            danger: true,
            onConfirm: function () {
              RY.store.reset();
              ui().toast('演示数据已重置。', 'success');
              setTimeout(function () { window.location.href = href(isH5() ? 'index.html' : 'pc.html'); }, 500);
            }
          });
        });
      }
    });
  }

  /* ====================================================== 交互小件 */

  /** 页内 Tab：以 hash 定位，便于直接打开指定视图。 */
  function tabs(id, items, onChange) {
    var cur = ui().hash() || items[0].key;
    var host = ui().qs('#' + id);
    if (!host) return cur;
    host.innerHTML = items.map(function (t) {
      return '<a class="ry-tab' + (t.key === cur ? ' is-on' : '') + '" href="#' + t.key + '" data-tab="' + t.key + '">' +
        ui().esc(t.name) + (t.count !== undefined && t.count !== null ? '<i>' + t.count + '</i>' : '') + '</a>';
    }).join('');
    function apply(key) {
      ui().qsa('[data-tab]', host).forEach(function (a) { a.classList.toggle('is-on', a.getAttribute('data-tab') === key); });
      if (onChange) onChange(key);
    }
    host.addEventListener('click', function (e) {
      var a = e.target.closest('[data-tab]');
      if (!a) return;
      e.preventDefault();
      var k = a.getAttribute('data-tab');
      if (window.history && window.history.replaceState) window.history.replaceState(null, '', '#' + k);
      else window.location.hash = k;
      apply(k);
    });
    window.addEventListener('hashchange', function () { apply(ui().hash() || items[0].key); });
    apply(cur);
    return cur;
  }

  /** 列表筛选区：折叠/展开，筛选条件保存在 sessionStorage，返回列表时恢复。 */
  function bindFilterToggle(btnSel, boxSel) {
    var b = ui().qs(btnSel), box = ui().qs(boxSel);
    if (!b || !box) return;
    b.addEventListener('click', function () {
      box.classList.toggle('is-open');
      b.textContent = box.classList.contains('is-open') ? '收起筛选' : '更多筛选';
    });
  }

  /** H5 底部抽屉（筛选、更多动作、选择器）。 */
  function sheet(opts) {
    var id = 'ry-sheet';
    var old = ui().qs('#' + id);
    if (old) old.parentNode.removeChild(old);
    var host = document.createElement('div');
    host.id = id;
    host.className = 'ry-mask ry-mask--h5';
    host.innerHTML = '<div class="ry-sheet"><span class="ry-sheet__grip"></span>' +
      '<div class="ry-layer__head"><b>' + ui().esc(opts.title || '') + '</b>' +
      (opts.sub ? '<span class="ry-layer__sub">' + ui().esc(opts.sub) + '</span>' : '') + '</div>' +
      '<div class="ry-layer__body">' + (opts.body || '') + '</div>' +
      '<div class="ry-layer__foot">' + (opts.footer || '<button class="ry-btn" data-close>关闭</button>') + '</div></div>';
    document.body.appendChild(host);
    host.addEventListener('click', function (e) { if (e.target === host || e.target.closest('[data-close]')) close(); });
    function close() { if (host.parentNode) host.parentNode.removeChild(host); }
    if (opts.onOpen) opts.onOpen(host, close);
    return { el: host, close: close };
  }

  return {
    root: root, href: href, go: go, isH5: isH5,
    shell: shell, h5shell: h5shell, demoPanel: demoPanel,
    tabs: tabs, bindFilterToggle: bindFilterToggle, sheet: sheet,
    sideHtml: sideHtml, topHtml: topHtml, tabbarHtml: tabbarHtml, H5_TABS: H5_TABS
  };
})();
